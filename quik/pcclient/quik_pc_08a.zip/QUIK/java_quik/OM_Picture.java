//  Dummy OM_Picture
package java_quik;

public class OM_Picture {
  public String   url   = null;
  public OM_Point point = null;
  public float    scale = (float)0.0;
}

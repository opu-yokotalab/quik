//  Dummy OM_Move
package java_quik;

public class OM_Move {
  public int      type  = 0;
  public OM_Atom  obj   = null;
  public OM_Point point = null;
}

package java_quik;

import java.io.*;

public class DM_Move implements Serializable {
  public int       type  = 0;
  public DM_Atom   obj   = null;
  public DM_Point  point = null;

  public DM_Move(OM_Move move) {
    if ( move == null )
      return;

    this.type  = move.type;  
    this.obj   = DM_Atom.convert( move.obj );
    this.point = DM_Point.convert( move.point );
  }

  public DM_Move() {}

  public static DM_Move convert( OM_Move move ) {
    if ( move == null )
      return null;

    DM_Move dmove = new DM_Move();

    dmove.type  = move.type;  
    dmove.obj   = DM_Atom.convert( move.obj );
    dmove.point = DM_Point.convert( move.point );

    return dmove;
  }
} 

package java_quik.gui;
import java_quik.*;
import java_quik.commgr.*;

import java.awt.*;
import java.awt.event.*;

import java.io.*;

//  ��\���p Window
public class ansWin extends Frame implements WindowListener,
                                             ActionListener {
  TextArea ta1;
  Button   bt1;
  MenuBar  mb1;
  Menu     mn1;
  MenuItem mi1, mi2, mi3;

  boolean SELF = false;

  WindowListener wl = null;

  //  �R���X�g���N�^(WindowListener)
  public ansWin( WindowListener listener ) {
    wl = listener;
  }

  //  �R���X�g���N�^(�����Ȃ�)
  public ansWin() {
    this( null );
  }

  //  ��������
  public void init() {
    ta1 = new TextArea( 10, 50);
    ta1.setEditable( false );
    bt1 = new Button("CLEAR LOG");
    bt1.addActionListener(this);
    mb1 = new MenuBar();
    mn1 = new Menu("LOG");
    mi1 = new MenuItem("Log save");
    mi1.addActionListener(this);
    mi2 = new MenuItem("Log clear");
    mi2.addActionListener(this);
    mi3 = new MenuItem("exit");
    mi3.addActionListener(this);

    setLayout( new BorderLayout());
    add( "Center", ta1);
    add( "South",  bt1);

    setMenuBar(mb1);
    mb1.add( mn1 );
    mn1.add( mi1 );
    mn1.add( mi2 );
    mn1.addSeparator();
    mn1.add( mi3 );

    setTitle("ANSWER WINDOW");

    if ( wl == null )
      wl = this;
    addWindowListener(wl);
  }

  //  �Ǝ����s�p
  public static void main( String args[] ) {
    ansWin window = new ansWin();
    window.init();
    window.setSelf( true );
    window.pack();
    window.show();
  }

  //  ���b�Z�[�W��\������
  public void showMessage( String mes ) {
    String message = mes;

    if ( !message.endsWith("\n") )
      message += "\n";

    ta1.append( message );
  }

  //  �Ǝ����s���ǂ����̃t���O���Z�b�g
  public void setSelf( boolean flag ) {
    SELF = flag;
  }

  //  �Ǝ����s���ǂ����̃t���O���擾
  public boolean getSelf() {
    return SELF;
  }

  //  �\�����ꂽ���O�̃Z�[�u
  public void logSave() {
    String logs = "",
           dir, file;
    FileDialog dialog;
    BufferedWriter bw;

    //  �ۑ��̂��߂̃t�@�C���_�C�A���O�̕\��
    dialog = new FileDialog(this, "Log Save", FileDialog.SAVE);
    dialog.setDirectory(".");
    dialog.setFile("quik_log.txt");
    dialog.show();
    if ( (dir = dialog.getDirectory()) == null || (file = dialog.getFile()) == null ) {
      showMessage( "Log save is cancel.");
      return;
    }

    try {
      bw = new BufferedWriter(new FileWriter( dir + file ) );
      logs = ta1.getText();

      //  ���O�̏����o��
      bw.write( logs );
      
      bw.close();
    } catch ( FileNotFoundException e ) {
      //  FileNotFoundException �ɑ΂����O����
      showMessage( "Can not open file:" + dir + file );
    } catch ( IOException e ) {
      //  IOException �ɑ΂����O����
      showMessage("IOException:" + e + "\n");
    }
    showMessage( "log is saved." );
  }

  //  Window �̏I������
  public void exit() {
    if ( getSelf() ) {
      dispose();
      System.exit(0);
    } else {
      if ( wl != null ) {
        wl.windowClosing( new WindowEvent( this, WindowEvent.WINDOW_CLOSED));
      } else {
        setVisible( false );
      }
    }
  }

  //  �{�^��, ���j���[�A�N�V�����̏���
  public void actionPerformed( ActionEvent ae ) {
    Object obj = ae.getSource();

    if ( obj == mi1 ) {
      logSave();
    } else if ( obj == bt1 || obj == mi2 ) {
      ta1.replaceRange("", 0, ta1.getText().length());
    } else if ( obj == mi3 ) {
      exit();
    }
  }

  //  Window �C�x���g�̏���
  public void windowClosing( WindowEvent we ) {
    exit();
  }
  public  void windowClosed( WindowEvent we ) {}
  public void windowOpened( WindowEvent we ) {}
  public void windowIconified( WindowEvent we ) {}
  public void windowDeiconified( WindowEvent we ) {}
  public void windowActivated( WindowEvent we ) {}
  public void windowDeactivated( WindowEvent we ) {}
}

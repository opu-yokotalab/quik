package java_quik.gui;
import java_quik.*;
import java_quik.commgr.*;

import java.util.*;

public class sg_make {
  Vector pstk = new Vector();
  int    MY = 0;

  public static void main( String args[] ) {
    SG_Box    sgbox;
    Exec_Tree etree;
    makeTree mt = new makeTree();
    etree = mt.makeSG();
    sg_make sgm = new sg_make();
    sgbox = sgm.makeSGBox( etree );
    sgm.viewSGBox( sgbox );
  }

  public SG_Box makeSGBox( Exec_Tree tree ) {
    SG_Box top;
    int    x = 0, y = 0;

    top = makeBoxTree( tree, x, y);

    return top;
  }

  public SG_Box makeBoxTree( Exec_Tree tree, int x, int y) {
    SG_Box sgbox = new SG_Box();

    if ( tree == null )
      return null;

    sgbox.makebox( tree );
    sgbox.setLocation( x, y);
    sgbox.parent = (SG_Box)peek( pstk );

    if ( MY < y )
      MY = y;
    sgbox.seq     = makeBoxTree( tree.seq,     x + 1, y);
    push( pstk, sgbox );
    sgbox.child   = makeBoxTree( tree.child,   x, MY + 1);
    pop( pstk );
    sgbox.nonoder = makeBoxTree( tree.nonoder, x, MY + 1);
    if ( pstk.size() < 2 )
      MY = y;

    return sgbox;
  }

  public void viewSGBox( SG_Box sgbox ) {
    if ( sgbox == null )
      return;

    System.out.println("name :" + sgbox.name);
    System.out.println("( x, y)=( " + sgbox.x + ", " + sgbox.y + ")");
    System.out.print(  "Parnt:");
    if ( sgbox.parent != null)
      System.out.print( sgbox.parent.name);
    System.out.println();
    System.out.print(  "Child:");
    if ( sgbox.child != null)
      System.out.print( sgbox.child.name);
    System.out.println();
    System.out.print(  "Seq  :");
    if ( sgbox.seq != null)
      System.out.print( sgbox.seq.name);
    System.out.println();
    System.out.print(  "Nonod:");
    if ( sgbox.nonoder != null)
      System.out.print( sgbox.nonoder.name);
    System.out.println();
    System.out.println("Self :" + sgbox.self.name);
    System.out.println();

    viewSGBox( sgbox.child );
    viewSGBox( sgbox.seq );
    viewSGBox( sgbox.nonoder );
  }

  //  Stack �Ƀf�[�^��ޔ�
  public void push( Vector stack, Object obj) {
    stack.insertElementAt( obj, 0);
  }

  //  Stack ����f�[�^�𕜋A
  public Object pop( Vector stack ) {
    Object obj;

    if ( stack.size() == 0 )
      return null;
    obj = stack.elementAt(0);
    stack.removeElementAt(0);
    return obj;
  }

  //  Stack �̈�ԐV�����f�[�^���Q��
  public Object peek( Vector stack ) {
    if ( stack.size() == 0 )
      return null;
    return stack.elementAt(0);
  }
}

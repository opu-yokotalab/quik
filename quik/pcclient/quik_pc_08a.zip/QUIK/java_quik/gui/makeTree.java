package java_quik.gui;
import java_quik.*;
import java_quik.commgr.*;

public class makeTree {
  Exec_Tree top = new Exec_Tree("main"),
            ptr;

  public static void main( String args[] ) {
    Exec_Tree tree;
    makeTree prog = new makeTree();
    tree = prog.makeSG();
    prog.viewTree( tree );
  }

  public Exec_Tree makeSG() {
    Exec_Tree sc1, sc2;
    sc1 = addChild( top, "scene1" );
    sc2 = addSeq( sc1, "scene2" );
    ptr = addSeq( sc2, "scene3" );
    ptr = addChild( sc1, "background" );
    ptr = addSeq( ptr, "speaker1");
    addChild( ptr, "Test");
    ptr = addNon( ptr, "speaker2");
    ptr = addSeq( ptr, "sentence1");
    ptr = addSeq( ptr, "sentence2");
    ptr = addSeq( ptr, "speaker1");
    ptr = addChild( sc2, "background" );
    ptr = addSeq( ptr, "speacker1" );
    ptr = addNon( ptr, "speaker2");
    addChild( ptr, "Test2");
    ptr = addNon( ptr, "speaker3");
    ptr = addSeq( ptr, "foreground" );

    return top;
  }

  public Exec_Tree searchName( String name ) {
    return search( name, top );
  }

  public Exec_Tree search( String name, Exec_Tree tree ) {
    String    n;
    Exec_Tree t;

    if ( tree == null )
      return null;

    n = tree.name;
    if ( n.equals(name) )
      return tree;

    t = search( name, tree.child);
    if ( t == null )
      t = search( name, tree.seq);
    if ( t == null )
      t = search( name, tree.nonoder);

    return t;
  }

  public void viewTree( Exec_Tree tree ) {
    if ( tree == null )
      return;

    System.out.println("Name :" + tree.name);
    System.out.print(  "Child:");
    if ( tree.child != null )
      System.out.print( tree.child.name );
    System.out.println();
    System.out.print(  "Seq  :");
    if ( tree.seq != null )
      System.out.print( tree.seq.name );
    System.out.println();
    System.out.print(  "nonod:");
    if ( tree.nonoder != null )
      System.out.print( tree.nonoder.name );
    System.out.println();
    System.out.println();

    viewTree( tree.child );
    viewTree( tree.seq );
    viewTree( tree.nonoder );
  }

  public Exec_Tree addChild( Exec_Tree tree, String name ) {
    tree.child = new Exec_Tree( name );
    return tree.child;
  }

  public Exec_Tree addSeq( Exec_Tree tree, String name ) {
    tree.seq = new Exec_Tree( name );
    return tree.seq;
  }

  public Exec_Tree addNon( Exec_Tree tree, String name ) {
    tree.nonoder = new Exec_Tree( name );
    return tree.nonoder;
  }
}

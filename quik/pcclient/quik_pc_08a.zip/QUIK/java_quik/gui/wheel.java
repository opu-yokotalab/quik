package java_quik.gui;

import java.awt.*;

public class wheel extends Canvas implements Runnable {
  Image    img = null;                      //  �I�t�X�N���[���o�b�t�@
  Graphics gr  = null;                      //  OSB�`��p

  int th[],                                 //  �J�n�p�x
      dt[],                                 //  �ړ���
      wd[];                                 //  ��

  boolean frame = false;                    //  �O�g��`�悷�邩�ǂ����̃t���O
  boolean inner = false;                    //  ���~��`�悷�邩�ǂ����̃t���O

  public final int MX = 32,
                   MY = 32;

  public static final int OUTER = 0,        //  �O���̈�
                          INNER = 1;        //  �����̈�

  Thread thread = null;

  //  �R���X�g���N�^
  public wheel() {
    th = new int[2];
    dt = new int[2];
    wd = new int[2];
    for ( int i = 0; i < 2; i++) {
      th[i] = 70;
      dt[i] = (i == 1)?10:-10;
      wd[i] = 40;
    }
  }

  //  ��������
  public void init() {
    setSize( MX, MY);
  }

  //  �`�揈��
  public void paint( Graphics g ) {
    if ( img == null ) {
      makeImage();
    }
    update( g );
  }

  //  �ĕ`�揈��
  public void update( Graphics g ) {
    g.drawImage( img, 0, 0, this);
  }

  //  �C���[�W�̍쐬
  public void makeImage() {
    img = createImage( MX, MY);
    gr  = img.getGraphics();

    drawNeedle();
  }

  //  �C���[�W�̕`��
  public void drawNeedle() {
    //  �w�i
    gr.setColor( Color.lightGray );
    gr.fillRect( 0, 0, MX, MY);
    //  �O�~
    gr.setColor( Color.white );
    gr.fillOval( 0, 0, MX - 1, MY - 1);
    //  �O��
    gr.setColor( Color.red );
    gr.fillArc( 0, 0, MX - 1, MY - 1, th[OUTER],       wd[OUTER]);
    gr.fillArc( 0, 0, MX - 1, MY - 1, th[OUTER] + 180, wd[OUTER]);

    if ( inner ) {
      //  ���~
      gr.setColor( Color.white );
      gr.fillOval( 7, 7, MX / 2, MY /2);
    }

    //  ����
    gr.setColor( Color.blue );
    gr.fillArc( 7, 7, MX / 2, MY / 2, th[INNER],       wd[INNER]);
    gr.fillArc( 7, 7, MX / 2, MY / 2, th[INNER] + 180, wd[INNER]);

    if ( frame ) {
      //  �O�g
      gr.setColor( Color.white );
      gr.drawLine( 0, 0, MX, 0);
      gr.drawLine( 0, 0, 0, MY);
      gr.setColor( Color.darkGray );
      gr.drawLine( MX - 1, 1, MX - 1, MY);
      gr.drawLine( 1, MY - 1, MX, MY - 1);
    }

    repaint();
  }

  //  ��̈ړ�
  public void movement( int n ) {
    if ( n < 0 || n > 1 )
      return;

    th[n] += dt[n];
    if ( th[n] >= 360 )
      th[n] -= 360;
    if ( th[n] < 0 )
      th[n] += 360;
    drawNeedle();
  }

  //  movement �̃I�[�o�[���[�h
  public void movement() {
    movement( OUTER );
    movement( INNER );
  }

  //  �O�g�`��t���O�̐ݒ�
  public void setFrame( boolean flag ) {
    frame = flag;
  }

  //  ���~�`��t���O�̐ݒ�
  public void setInner( boolean flag ) {
    inner = flag;
  }

  //  �p�x��ݒ肷��
  public void setAngle( int theta, int n){
    if ( n < 0 || n > 1 )
      return;
    th[n] = theta;
  }

  //  setAngle �̃I�[�o�[���[�h
  public void setAngle( int theta ) {
    setAngle( theta, OUTER );
    setAngle( theta, INNER );
  }

  //  �ړ��ʂ̐ݒ�
  public void setMoveAngle( int dtheta, int n ) {
    if ( n < 0 || n > 1 )
      return;
    dt[n] = dtheta;
  }

  //  setMoveAngle �̃I�[�o�[���[�h
  public void setMoveAngle( int dtheta ) {
    setMoveAngle(  dtheta, OUTER);
    setMoveAngle( -dtheta, INNER);
  }

  //  ���̐ݒ�
  public void setWidth( int width, int n ) {
    if ( n < 0 || n > 1 )
      return;
    wd[n] = width;
  }

  //  setWidth �̃I�[�o�[���[�h
  public void setWidth( int width ) {
    setWidth( width, OUTER);
    setWidth( width, INNER);
  }

  //  ����ȉ��Ǝ����s�p
  public static void main( String args[] ) {
    Frame  frame = new Frame();
    wheel canv = new wheel();
    canv.init();
    canv.setFrame( true );
    frame.add(canv);
    frame.pack();
    frame.show();
    canv.start();
  }

  public void start() {
    if ( thread == null ) {
      thread = new Thread(this);
      thread.start();
    }
  }

  public void stop() {
    if ( thread != null ) {
      thread.stop();
      thread = null;
    }
  }

  public void run() {
    while( true ) {
      repaint();
      try {
        Thread.sleep(100);
      } catch ( InterruptedException ie ) {}
      movement();
    }
  }
}

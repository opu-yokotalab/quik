package java_quik.gui;
import java_quik.*;
import java_quik.commgr.*;

public class SG_Box {
  int x, y;
  int wx, hy;
  
  String    name    = "",
            comment = "";
  SG_Box    parent  = null;
  SG_Box    child   = null;
  SG_Box    seq     = null;
  SG_Box    nonoder = null;
  Exec_Tree self    = null;

  public void makebox( Exec_Tree tree ) {
    name    = tree.name;
    comment = tree.comment;
    self    = tree;
  }

  public void setLocation( int xx, int yy) {
    x = xx;
    y = yy;
  }
}

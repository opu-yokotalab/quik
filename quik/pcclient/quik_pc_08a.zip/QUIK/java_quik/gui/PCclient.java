package java_quik.gui;
import java_quik.*;
import java_quik.commgr.*;
import java_quik.sound.*;

import java.awt.*;
import java.awt.event.*;
import java.util.*;

//  PC ��ł̃N���C�A���g
public class PCclient extends Frame implements WindowListener,
                                               ActionListener,
                                               ItemListener {
  TextArea   ta1;
  Button     bt1, bt2;
  MenuBar    mb1;
  Menu       mn1, mn2, mn3, mn4, mn5;
  MenuItem   mie,
             mic1[], mic2[];
  CheckboxMenuItem cm1, cm2, cm3;
  gButton    gb1;

  String     cmds1[] = { "startup", "activate", "open",
                        "close", "shutdown", "abort" },
             cmds2[] = { "Play", "Pause", "Stop", "Save" };

  //  �V�K�X�^�[�g���R���e�B�j���[���̎��ʃt���O
  boolean Started = false;

  //  Answer window
  ansWin awin;
  //  �r�f�I�p�l��
  videoPanel panel;

  wheel roll;

  SoundPlayer sdplay;

  //  ���݂̐���̏�ԃt���O
  int CtrlState = videoPanel.STOP;

  //  �e�̃N���X�Q�Ɨp
  Main parent = null;

  //  �R���X�g���N�^(Main �N���X)
  public PCclient( Object obj ) {
    parent = (Main)obj;
  }

  //  �R���X�g���N�^(��������)
  public PCclient() {
    this( null );
  }

  //  ��������
  public void init() {
    panel = new videoPanel( true );
    panel.init();
    panel.addActionListener(this);
    roll = new wheel();
    roll.init();
    roll.setFrame( true );
    sdplay = new SoundPlayer();

    ta1 = new TextArea( 10, 40);
    bt1 = new Button("QUERY");
    bt1.addActionListener(this);
    bt2 = new Button("CLEAR");
    bt2.addActionListener(this);
    gb1 = new gButton("save.gif");
    gb1.setImgNoResize( true );
    gb1.addActionListener(this);
    gb1.setEnabled( false );

    mb1 = new MenuBar();
    mn1 = new Menu("Window");
    mn2 = new Menu("Command");
    mn3 = new Menu("Transition");
    mn4 = new Menu("Sequencial");
    mn5 = new Menu("Option");
    cm1 = new CheckboxMenuItem("Answer Window");
    cm1.addItemListener(this);
    cm2 = new CheckboxMenuItem("Text Window");
    cm2.addItemListener(this);
    cm3 = new CheckboxMenuItem("view detail Info.");
    mic1 = new MenuItem[cmds1.length];
    for ( int i = 0; i < cmds1.length; i++ ) {
      mic1[i] = new MenuItem( cmds1[i] );
      mic1[i].addActionListener(this);
    }
    mic2 = new MenuItem[cmds2.length];
    for ( int i = 0; i < cmds2.length; i++ ) {
      mic2[i] = new MenuItem( cmds2[i] );
      mic2[i].addActionListener(this);
    }
    mie = new MenuItem("Exit");
    mie.addActionListener(this);

    setMenuBar(mb1);
    mb1.add(mn1);
    mn1.add(cm1);
    mn1.add(cm2);
    mn1.addSeparator();
    mn1.add(mie);
    mn5.add(cm3);
    mb1.add(mn2);
    mb1.add(mn5);
    mn2.add(mn3);
    mn2.add(mn4);
    for ( int i = 0; i < cmds1.length; i++)
      mn3.add(mic1[i]);
    for ( int i = 0; i < cmds2.length; i++) {
      if ( cmds2[i].equals("Save") )
        mn4.addSeparator();
      mn4.add(mic2[i]);
    }

    awin = new ansWin(this);
    awin.init();

    parent.txtwin.setWindowListener(this);

    setLayout( new BorderLayout());
    add( "Center", ta1);
    Panel pn1 = new Panel();
    pn1.setLayout( new BorderLayout());
    pn1.add( "North", bt1);
    pn1.add( "South", bt2);
    add( "East",   pn1);
    Panel pn2 = new Panel();
    pn2.setLayout( new BorderLayout());
    pn2.add( "West",   panel );
    pn2.add( "Center", gb1);
    pn2.add( "East",   roll  );
    add( "South",  pn2);
    add( "North",  sdplay.getCanvas());

    addWindowListener(this);
  }

  //  �Ǝ��N���p�� main
  public static void main( String args[] ) {
    PCclient window = new PCclient();
    window.init();
    window.setTitle("PC Client");
    window.pack();
    window.show();
  }

  //  ���f�B�A��U�蕪����
  public void receivedMedia( Object obj, int CMDtype ) {
    int state = -99,
        type  = CMDtype - 32;
    String message = "";

    DM_Media media = (DM_Media)obj;
    viewMediaInfo( media, type );

    switch( media.type ) {
      case 1:  //  �摜
      case 2:  //  ����
      case 3:  //  �I�u�W�F�N�g
      case 5:  //  �ړ����
        parent.viewer.transfer( media, type);
        break;
      case 4:  //  �e�L�X�g
        parent.txtwin.PrintText( media );
        if ( !parent.txtwin.isVisible() )
          parent.txtwin.show();
        break;
      case 6:  //  ����
        state = sdplay.SoundPlay( media, type, true);
        break;
      case 7:  //  ���b
        state = parent.utte.UtteranceStart( media, type );
        break;
      default:
    }


//    state = inputStatus();

//  ����I��
    if ( state == -99 )
      state = 0;


    if ( CtrlState == videoPanel.STOP )
      state = 1;
    else if ( CtrlState == videoPanel.PAUSE )
      state = 2;

    parent.dmClient.sendStatus( state );
  }

  //  �����Ă������f�B�A�̏���\��
  public void viewMediaInfo( DM_Media media, int CMDid ) {
    String name, msg;
    int    type;

    if ( media == null ) {
      awin.showMessage( "Media is null." );
      return;
    }

    name = media.atom.name;
    type = media.type;
    //  ���O�ƃ��f�B�A�^�C�v�Ǝ��s�^
    msg = "Name:[" + name + "],\ttype:" + type + ",\t";
    if ( CMDid == 1 )
      msg += "Exec";
    else
      msg += "Erase";

    //  �ڍו\�����[�h�łȂ���΂��ꂾ���ŏI���
    if ( !cm3.getState() ) {
      awin.showMessage( msg );
      return;
    }

    switch( type ) {
      case 1: //  �Î~��
        msg += "PicURL:[" + media.picture.url + "],\t";
        msg += "Scale:" + media.picture.scale + ",\t";
        msg += "Points:" + getPoints( media.picture.point );
        break;
      case 2: //  ����
        break;
      case 3: //  �I�u�W�F�N�g
        msg += "ObjURL:[" + media.object.url + "],\t";
        msg += "Points:" + getPoints( media.object.point );
        break;
      case 4: //  �e�L�X�g
        msg += "TextURL:[" + media.text.str + "],\t";
        msg += "Font:[" + media.text.font + "],\t";
        msg += "Scale:" + media.text.scale + ",\t";
        msg += "Color:( " + media.text.r + ", " + media.text.g + ", "
                          + media.text.b + "),\t";
        msg += "Text:[" + getURLfile( media.text.str ) + "]";
        break;
      case 5: //  �ړ����
        msg += "ObjName:[" + media.move.obj.name + "],\t";
        msg += "Type:" + media.move.type + ",\t";
        msg += "Points:" + getPoints( media.move.point );
        break;
      case 6: //  ����
        msg += "SoundURL:[" + media.sound.url + "],\t";
        msg += "Volume:" + media.sound.volume;
        break;
      case 7: //  ���b
        msg += "UttURL:[" + media.utterance.str + "],\t";
        msg += "Font:[" + media.utterance.font + "],\t";
        msg += "Pitch:" + media.utterance.pitch + ",\t";
        msg += "Loudness:" + media.utterance.loudness + ",\t";
        msg += "Text:[" + getURLfile( media.utterance.str ) + "]";
        break;
    }
    awin.showMessage( msg );
  }

  //  Point�̏����ċA�I�Ɏ擾���郁�\�b�h
  public String getPoints( DM_Point point ) {
    String pts, pt;
    if ( point == null )
      return "";

    pts = "( " + point.point_x + ", " + point.point_y + ", " + point.point_z + ")";
    pt = getPoints( point.next );
    if ( !pt.equals("") )
      pts = pts + " �� " + pt;

    return pts;
  }

  //  �e�L�X�g�┭�b�̓��e��URLFile�������Ă��郁�\�b�h
  public String getURLfile( String location) {
    java.net.URL url;
    java.net.URLConnection uc;
    java.io.BufferedReader br;
    String meg = "", line = "";

    try {
      url = new java.net.URL( location);
      uc  = url.openConnection();
      br = new java.io.BufferedReader(
             new java.io.InputStreamReader( uc.getInputStream()));
      while( (line = br.readLine()) != null) {
        meg += line;
      }
      br.close();
    } catch ( Exception e ) {
      System.out.println("Exception: " + e);
      e.printStackTrace();
      return null;
    }
    return meg;
  }

  //  �e���f�B�A����̋A��l��I������ Dialog �\���� Debug �p�̃��\�b�h
  public int inputStatus() {
    stateDialog dialog = new stateDialog( this, "Status Select Dialog", true );
    dialog.pack();
    dialog.show();

    //  �_�C�A���O��\�������Đ���I�����ُ�I������I��
    return dialog.getStatus();
  }

  //  getTree �̕Ԃ�l�ł��� Exec_Tree �̎󂯌�
  public void setTree( Exec_Tree tree ) {
  }

  //  ���b�Z�[�W���� Window �̃��b�Z�[�W�𑗐M���邽�߂̃��\�b�h
  public void sendMessage( String mes ) {
    if ( parent == null )
      return;

    if ( mes.toLowerCase().indexOf("m_save") != -1 )
      if ( CtrlState != videoPanel.PAUSE ) {
        awin.showMessage( "���݂̏�Ԃł� save ���邱�Ƃ͏o���܂���" );
        return;
      }

    if ( mes.toLowerCase().indexOf("m_start") != -1 )
      if ( CtrlState == videoPanel.PLAY )
        return;
      else {
        Started   = true;
        CtrlState = videoPanel.PLAY;
        panel.setState( videoPanel.PLAY );
      }

    if ( mes.toLowerCase().indexOf("setserver") != -1 ) {
      setServerIP( mes );
    } else {
      parent.dmClient.sendCommand( ta1.getText(), null);
    }
  }

  public void seqControl( int num ) {
    //  SAVE �̏���
    if ( num == 3 )
      return;

    //  PLAY �̏���
    if ( num == 0 ) {
      sc_play();
      panel.setState( videoPanel.PLAY );

    //  PAUSE �̏���
    } else if ( num == 1 ) {
      sc_pause();
      panel.setState( videoPanel.PAUSE );

    //  STOP �̏���
    } else if ( num == 2 ) {
      sc_stop();
      panel.setState( videoPanel.STOP );
    }
  }

  //  Wheel �𓮂���
  public void movement( int n ) {
    roll.movement( n );
  }

  //  �_�~�[�T�[�o�[�� IP ���Z�b�g���郁�\�b�h
  public void setServerIP( String message ) {
    StringTokenizer st = new StringTokenizer( message );
    String token[] = new String[st.countTokens()];
    int n;

    for ( int i = 0; st.hasMoreTokens(); i++ )
      token[i] = st.nextToken();
    for ( n = 0; n < token.length; n++)
      if ( token[n].toLowerCase().equals("setserver") )
        break;
    if ( n == token.length )
      return;

    parent.dmClient.setServer( token[n + 1] );
    awin.showMessage( "Set Server:" + token[n + 1] );
    movement( wheel.INNER );    
  }

  //  �Đ��̏���
  public void sc_play() {
      String command = "";

      if ( CtrlState == videoPanel.PLAY )
        return;

      CtrlState = videoPanel.PLAY;
      if ( Started )
        command = "m_continue";
      else
        command = "m_start";
      parent.dmClient.sendCommand( command, null);
  }

  //  �ꎞ��~�̏���
  public void sc_pause() {
    if ( CtrlState == videoPanel.PAUSE ) {
      sc_play();
      panel.setState( videoPanel.PLAY );
      return;
    } else if ( CtrlState != videoPanel.PLAY )
      return;

    CtrlState = videoPanel.PAUSE;
  }

  //  ��~�̏���
  public void sc_stop() {
    if ( CtrlState != videoPanel.PLAY )
      return;
    Started = false;
    CtrlState = videoPanel.STOP;
  }

  //  Quik �T�[�o�[ ����̏�Ԃ��擾���������郁�\�b�h
  public void getState(int CMDid, Object obj) {
    int cmd = CMDid & QuikStatus.ERRMASK;

    if ( (CMDid & QuikStatus.SUCCESS) != 0 )
      switch( cmd ) {
        case QuikStatus.STARTUP:
          awin.showMessage( (String)obj );
          break;
        case QuikStatus.OM_Media:
          sc_stop();
          panel.setState( videoPanel.STOP );
          awin.showMessage( "Senario finished." );
          break;
      }
  }

  //  �e��A�N�V�����ɑ΂��鏈��
  public void actionPerformed( ActionEvent ae ) {
    Object obj = ae.getSource();

    //  Menu �� Exit �������ꂽ�Ƃ��̏���
    if ( obj == mie ) {
      dispose();
      System.exit(0);

    //  Query �������ꂽ�Ƃ��̏���
    } else if ( obj == bt1 ) {
      String ts1 = ta1.getText().trim();
      if ( ts1.equals("") )
        return;
      sendMessage( ts1 );

    //  Clear �������ꂽ�Ƃ��̏���
    } else if ( obj == bt2 ) {
      ta1.replaceRange( "", 0, ta1.getText().length() );

    //  videoPanel �̃R���|�[�l���g�������ꂽ�Ƃ��̏���
    } else if ( obj == panel ) {
      switch ( panel.getState() ) {
        //  PLAY �̏���
        case panel.PLAY:
          gb1.setEnabled( false );
          sc_play();
          break;

        //  STOP �̏���
        case panel.STOP:
          gb1.setEnabled( false );
          sc_stop();
          break;

        //  PAUSE �̏���
        case panel.PAUSE:
          gb1.setEnabled( true );
          sc_pause();
          break;
      }

    //  SAVE �{�^���������ꂽ�Ƃ��̏���
    } else if ( obj == gb1 ) {
      if ( CtrlState != videoPanel.PAUSE )
        return;
      seqControl( 3 );

    //  Menu �̏�ԑJ�ڃR�}���h���I�����ꂽ�Ƃ��̏���
    } else {
      for ( int i = 0; i < mic1.length; i++)
        if ( obj == mic1[i] ) {
          ta1.append( "&" + cmds1[i] + " " );
          return;
        }

      //  Menu �̐���R�}���h���I�����ꂽ�Ƃ��̏���
      for ( int i = 0; i < mic2.length; i++)
        if ( obj == mic2[i] )
          seqControl( i );
    }
  }

  //  �A�C�e���n�̃A�N�V�����ɑ΂��鏈��
  public void itemStateChanged( ItemEvent ie ) {
    Object obj = ie.getSource();

    //  Menu �� Answer Window �������ꂽ�Ƃ��̏���
    if ( obj == cm1 ) {
      awin.pack();
      awin.setVisible( cm1.getState() );
    } else if ( obj == cm2 ) {
      parent.txtwin.pack();
      parent.txtwin.setVisible( cm2.getState() );
    }
  }

  //  Window �̃C�x���g�ɑ΂��鏈��
  public void windowClosing( WindowEvent we ) {
    Object obj = we.getSource();

    if ( obj == awin ) {
      cm1.setState( false );
      awin.setVisible( false );
    } else if ( obj == parent.txtwin ) {
      cm2.setState( false );
      parent.txtwin.setVisible( false );
    } else {
      dispose();
      System.exit(0);
    }
  }
  public  void windowClosed( WindowEvent we ) {}
  public void windowOpened( WindowEvent we ) {}
  public void windowIconified( WindowEvent we ) {}
  public void windowDeiconified( WindowEvent we ) {}
  public void windowActivated( WindowEvent we ) {}
  public void windowDeactivated( WindowEvent we ) {}
}

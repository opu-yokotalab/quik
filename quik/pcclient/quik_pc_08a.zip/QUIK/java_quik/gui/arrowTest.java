package java_quik.gui;
import java_quik.*;
import java_quik.commgr.*;

import java.awt.*;
import java.awt.event.*;

public class arrowTest extends Frame implements WindowListener,
                                                ActionListener,
                                                MouseListener,
                                                MouseMotionListener {
  Image    img = null;
  Graphics gr;
  int      x1, y1,
           x2, y2;
  Button   bt1;

  public void init() {
    bt1 = new Button("Clear");
    bt1.addActionListener(this);
    bt1.setEnabled(false);

    setLayout( new BorderLayout());
    add("North", bt1);

    setSize( 500, 500);
    addWindowListener(this);
    addMouseListener(this);
    addMouseMotionListener(this);
  }

  public static void main( String args[] ) {
    arrowTest win = new arrowTest();
    win.setTitle("arrowTest");
    win.init();
    win.show();
  }

  public void paint( Graphics g ) {
    if ( img == null )
      makeImage();
    update(g);
  }

  public void update( Graphics g ) {
    g.drawImage( img, 0, 0, this);
    drawArrow( x1, y1, x2, y2, g);
  }

  public void makeImage() {
    img = createImage( 500, 500);
    gr  = img.getGraphics();
    bt1.setEnabled(true);
  }

  public void drawArrow( int x1, int y1, int x2, int y2, Graphics g) {
    double theta = 0.0,
           dx  = (double)x2 - (double)x1,
           dy  = (double)y2 - (double)y1,
           att = (180.0 - 30.0) * Math.PI / 180.0;
    int    mul = 15;
    Polygon pnt = new Polygon();

    if ( dx == 0.0 && dy == 0.0 )
      return;

    if ( dx == 0.0 )
      if ( dy < 0.0)
        theta = Math.PI / 2.0;
      else
        theta = Math.PI / -2.0;
    else
      theta = Math.atan( -dy / dx);
    if ( dx < 0.0 )
      theta += Math.PI;

    g.drawLine(x1, y1, x2, y2);
/**
    pnt.addPoint(x2 + (int)(Math.cos(theta + att) * mul),
                 y2 - (int)(Math.sin(theta + att) * mul));
    pnt.addPoint(x2, y2);
    pnt.addPoint(x2 + (int)(Math.cos(theta - att) * mul),
                 y2 - (int)(Math.sin(theta - att) * mul));
    g.drawPolygon( pnt );
*/
    g.drawLine( x2, y2, x2 + (int)(Math.cos(theta + att) * mul), 
                        y2 - (int)(Math.sin(theta + att) * mul));
    g.drawLine( x2, y2, x2 + (int)(Math.cos(theta - att) * mul),
                        y2 - (int)(Math.sin(theta - att) * mul));
  }

  public void actionPerformed( ActionEvent ae ) {
    Object obj = ae.getSource();

    if ( obj == (Object)bt1 ) {
      gr.setColor( Color.white);
      gr.fillRect( 0, 0, 500, 500);
      gr.setColor( Color.black);
      repaint();
    }
  }

  //  MouseListener �̏���
  //  �}�E�X�̃{�^���������ꂽ�Ƃ��̏���
  public void mousePressed( MouseEvent me ) {
    x1 = me.getX();
    y1 = me.getY();
    x2 = x1;
    y2 = y1;
    repaint();
  }
  public void mouseReleased( MouseEvent me ) {
    drawArrow( x1, y1, x2, y2, gr);
    x1 = y1 = x2 = y2 = 0;
    repaint();
  }

  public void mouseClicked( MouseEvent me ) {}
  public void mouseExited( MouseEvent me ) {}
  public void mouseEntered( MouseEvent me ) {}

  //  MouseMotionListener �̏���
  //  �}�E�X���h���b�O���ꂽ�Ƃ��̏���
  public void mouseDragged( MouseEvent me ) {
    x2 = me.getX();
    y2 = me.getY();
    repaint();
  }
  public void mouseMoved( MouseEvent me ) {}

  public void windowClosing( WindowEvent we ) {
    dispose();
    System.exit(0);
  }
  public  void windowClosed( WindowEvent we ) {}
  public void windowOpened( WindowEvent we ) {}
  public void windowIconified( WindowEvent we ) {}
  public void windowDeiconified( WindowEvent we ) {}
  public void windowActivated( WindowEvent we ) {}
  public void windowDeactivated( WindowEvent we ) {}
}

package java_quik.gui;
import java_quik.*;
import java_quik.commgr.*;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;

import java.io.Serializable;
import java.util.*;  // Date

public class UIClient extends Frame implements ActionListener,
                                                  WindowListener {
  static TextField tf1, tf2;
  Button    bt1, bt2;
  Label     lb1, lb2;

  int    hosts;                      //  �t�@�C���ɏ����Ă���T�[�o�[�̐�
  String hostname[],                 //  �z�X�g�̖��O(�֋X��)
         hostaddr[];                 //  �z�X�g�̃A�h���X
  final String SEPA = "\t";          //  �Z�p���[�g����

  String Address[];                  //  �w�肳�ꂽ�A�h���X�ۑ��p

  static String ag[];

  //  �I�u�W�F�N�g�͈�l
  GridBagLayout gblayout = new GridBagLayout();
  GridBagConstraints gbc = new GridBagConstraints();

  //  �R���X�g���N�^
  UIClient(String url) {
    
  }
  //  �R���X�g���N�^
  UIClient() {}


  public void init() {
    bt1 = new Button("Get Message");
    bt1.addActionListener(this);
    bt2 = new Button("bt2");
    bt2.addActionListener(this);

    lb1 = new Label("Message:", Label.CENTER);
    lb2 = new Label("Destination:", Label.CENTER);
    tf1 = new TextField( 32 );
    tf2 = new TextField( 32 );

    //  �I�u�W�F�N�g�̔z�u
    setLayout( gblayout );
    gbc.fill = GridBagConstraints.BOTH;
    setObject( bt1, gblayout, gbc);
    setObject( bt2, gblayout, gbc);
    gbc.gridy = 1;
    setObject( lb1, gblayout, gbc);
    gbc.gridwidth = 3;
    setObject( tf1, gblayout, gbc);
    gbc.gridwidth = 1;
    gbc.gridy = 2;
    setObject( lb2, gblayout, gbc);
    setObject( tf2, gblayout, gbc);
    gbc.gridwidth = 5;

    //  WindowListener �̓o�^
    addWindowListener(this);

  }

  //  �I�u�W�F�N�g�̃��C�A�E�g
  public void setObject(Component comp, GridBagLayout layout,
                        GridBagConstraints c) {
    layout.setConstraints( comp, c);
    add(comp);
  }

  //  ���C��
  public static void main( String args[] ) {
    ag = args;

    //  �������g���N��
    UIClient window = new UIClient();
    window.init();
    window.setTitle("check socket");
    window.setSize( 250, 300);
    window.pack();
    window.show();

      uig th = new uig();
      th.start();

  }

  //  �I������Ă��郊�X�g�� String �z��Ƃ��ĕԂ�
  public String[] getHosts() {
    int n = 1;

    Address = new String[n];
    return Address;

  }

  //  GUI �̃A�N�V�����ɑ΂��鏈��
  public void actionPerformed( ActionEvent ae ) {
    Object obj;
    //  TextField �̕�����ǂ݂Ƃ�
    String ts1 = tf1.getText();
    String ts2 = tf2.getText();

    if ( (obj = ae.getSource()) == bt1 ) {
        int port = Integer.parseInt(ag[1]);
        SetStr(port, ts1);
    } else if ( obj == bt2 ) {
        uig(ag);
    }
  }
  public void SetStr (int pn, String str) {
    try {
  ServerSocket ss;
  Socket s;

//    try{
        ss = new ServerSocket(Integer.parseInt(ag[1]));
//    }
//    catch (Exception e){
//        System.out.println("Exception: " + e);
//    }

        ss.setSoTimeout(10000);

      try{
          s = ss.accept();

  FileOutputStream fout = new FileOutputStream("serialtest");
  ObjectOutputStream oout = new ObjectOutputStream(fout);
  int array[] = {10, 20, 30, 40, 50};
  oout.writeObject(array);
  oout.writeObject(new Date());
  otxt tmp = new otxt();
  tmp.str2 = UIClient.tf1.getText();
  oout.writeObject(tmp);
  oout.flush();
  fout.close();

//          OutputStream os = s.getOutputStream();
//          DataOutputStream dos = new DataOutputStream(os);
//
//          dos.writeUTF(str);
//
//          os.close();

          s.close();
      }
      catch (Exception e) {
          System.out.println("UIClient Exception: " + e);
      }
      finally{
          ss.close();
      }


    }
    catch (Exception e) {
        System.out.println("UIClient2 Exception: " + e);
    }

  }

  public void uig(String args[]) {
      int i;
      String str=null;
      try {
          String server = args[0];
          int port = Integer.parseInt(args[1]);
          Socket s=null;

          for(i=0;i<5;i++){
            try {
              s = new Socket(server, port);
            }catch (Exception e) {
              System.out.println("Exception: " + e);
            }
            if(s != null) break;
          }
          if(s == null){
            return;
          }

          InputStream is = s.getInputStream();
          DataInputStream dis = new DataInputStream(is);

          str = dis.readUTF();

          System.out.println(str);
          s.close();

          tf2.setText(str);
      }
      catch (Exception e) {
          System.out.println("Exception: " + e);
      }
  }

//  public static void setTF(String sstr){
//          tf2.setText(sstr);
//  }

  public void windowClosing( WindowEvent we ) {
      dispose();
      System.exit(0);
  }
  public  void windowClosed( WindowEvent we ) {}
  public void windowOpened( WindowEvent we ) {}
  public void windowIconified( WindowEvent we ) {}
  public void windowDeiconified( WindowEvent we ) {}
  public void windowActivated( WindowEvent we ) {}
  public void windowDeactivated( WindowEvent we ) {}

}

class uig extends Thread {
    int i;
    String str=null;

    public void run() {
      try {
       while(true) {
       while(true) {
        Thread.sleep(1000);
        try {
            String server = UIClient.ag[0];
            int port = Integer.parseInt(UIClient.ag[1]);
            Socket s=null;

            for(i=0;i<5;i++){
              try {
                s = new Socket(server, port);
              }catch (Exception e) {
                System.out.println("Exception: " + e);
              }
              if(s != null) break;
            }
            if(s == null){
              // return;
              break;
            }

//            InputStream is = s.getInputStream();
//            DataInputStream dis = new DataInputStream(is);
//
//            str = dis.readUTF();
//
//            System.out.println(str);

  FileInputStream fin = new FileInputStream("serialtest");
  ObjectInputStream oin = new ObjectInputStream(fin);
  int ar[];
  ar = (int [])oin.readObject();
  Date date2 = (Date)oin.readObject();
  otxt pu = (otxt)oin.readObject();
  fin.close();
  System.out.println(ar[0]);
  System.out.println(date2);
  pu.aho("nyu");

            s.close();

          UIClient.tf2.setText(str);
//            UIClient.setTF(str);
        }
        catch (Exception e) {
            System.out.println("uig Exception: " + e);
        }
       }
       }

      }
      catch (InterruptedException ex) {
        ex.printStackTrace();
      }
    }
}

class otxt implements Serializable {
  String str2;

  public static void main( String args[] ) {

  }

  public void aho(String str) {
    System.out.println(str);
    System.out.println(str2);
  }

}

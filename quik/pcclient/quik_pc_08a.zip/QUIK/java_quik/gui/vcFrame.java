package java_quik.gui;
import java_quik.*;
import java_quik.commgr.*;

import java.awt.*;
import java.awt.event.*;

public class vcFrame extends Frame implements WindowListener,
                                              ActionListener {
  videoPanel panel = null;

  public void init() {
    panel = new videoPanel();
    panel.init();
    panel.addActionListener(this);
    add(panel);
    addWindowListener(this);
  }

  public static void main( String args[] ) {
    vcFrame window = new vcFrame();
    window.init();
    window.pack();
    window.show();
  }

  public void actionPerformed( ActionEvent ae ) {
    Object obj = ae.getSource();

    if ( obj == panel ) {
      switch ( panel.getState() ) {
        case panel.PLAY:
          System.out.println("Play");
          break;
        case panel.STOP:
          System.out.println("Stop");
          break;
        case panel.PAUSE:
          System.out.println("Pause");
          break;
      }
    }
  }

  public void windowClosing( WindowEvent we ) {
    dispose();
    System.exit(0);
  }
  public  void windowClosed( WindowEvent we ) {}
  public void windowOpened( WindowEvent we ) {}
  public void windowIconified( WindowEvent we ) {}
  public void windowDeiconified( WindowEvent we ) {}
  public void windowActivated( WindowEvent we ) {}
  public void windowDeactivated( WindowEvent we ) {}
}

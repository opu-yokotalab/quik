package java_quik;

import java.io.*;

public class OM_Utterance implements Serializable {

  public OM_Utterance()
  {
    this.str = null; 
    this.font = null;
    this.loudness = (float)0.5;
    this.pitch = (float)0.5;
  }

  public OM_Utterance(String str, String font, float loudness, float pitch)
  {
    this.str = str; 
    this.font = font;
    this.loudness = loudness;
    this.pitch = pitch;
  }

  public String  str;
  public String  font;
  public float   loudness;
  public float   pitch;
} 

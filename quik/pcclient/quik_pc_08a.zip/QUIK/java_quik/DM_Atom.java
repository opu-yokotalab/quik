package java_quik;

import java.io.*;

public class DM_Atom implements Serializable {
  public String name = null;

  public DM_Atom( OM_Atom atom ) {
    if ( atom == null )
      return;

    this.name = atom.name;
  }

  public DM_Atom() {}

  public static DM_Atom convert( OM_Atom atom ) {
    if ( atom == null )
      return null;

    DM_Atom datom = new DM_Atom();

    datom.name = atom.name;

    return datom;
  }
}

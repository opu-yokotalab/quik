package java_quik;

import java.io.*;

public class OM_Sound implements Serializable {

  public OM_Sound(String url, float volume)
  {
    this.url = url;
    this.volume = volume;
  }

  //  2000/02/14 Earsh
  public OM_Sound() {
    this( null, (float)0.0);
  }

  public String url;
  public float  volume; 
} 

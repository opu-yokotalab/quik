// ---------- �^���X�̃x�[�X�����N���X ---------
//  2000/02/16 Earsh
package java_quik.viewer;
import  java_quik.*;

import javax.media.j3d.*;
import javax.vecmath.*;

class Shelfbase{

  Shelfbase(TransformGroup daiGroup,Appearance appearance){
    TransformGroup part1,part2,part3,part4,part5,part6;

    // �^���X�x�[�X�쐬
    part1 = new BoxBuild(0.6f,0.02f,0.3f,0.0,0.40,0.0,appearance);
    part2 = new BoxBuild(0.03f,0.35f,0.28f,-0.54,0.05,0.0,appearance);
    part3 = new BoxBuild(0.03f,0.35f,0.28f,0.54,0.05,0.0,appearance);
    part4 = new BoxBuild(0.56f,0.35f,0.03f,0.0,0.05,-0.25,appearance);
    part5 = new BoxBuild(0.58f,0.02f,0.29f,0.0,-0.24,0.0,appearance);
    part6 = new BoxBuild(0.6f,0.05f,0.3f,0.0,-0.30,0.0,appearance);
  
    daiGroup.addChild(part1);
    daiGroup.addChild(part2);
    daiGroup.addChild(part3);
    daiGroup.addChild(part4);
    daiGroup.addChild(part5);
    daiGroup.addChild(part6);

  }

}

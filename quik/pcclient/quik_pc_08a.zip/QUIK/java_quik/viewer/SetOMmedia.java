// ------ Set Frame Information of OM_Media ------
//  2000/02/16 Earsh
package java_quik.viewer;
import  java_quik.*;

import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class SetOMmedia extends Frame implements ActionListener,InfoTranslation {

    int c;

    Label label1,label2,label3,label4,label5,label6,label7,label8,label9,label10,label11,label12;
    TextField type,playtime,synchro,name,next,command;
    Button setButton;

    SetOMatom setomatom;
    SetOMpicture setompicture;
    SetOMpoint setompoint;
    SetOMobject setomobject;
    SetOMmove setommove;
    SetOMsound setomsound;
    SetOMutterance setomutterance;
    SetOMtext setomtext;

//  2000/02/16  Earsh
/**
    OM_Media om_media;
    OM_Picture ompic;
    OM_Object omobj;
    OM_Move omv;
*/
    DM_Media om_media;
    DM_Picture ompic;
    DM_Object omobj;
    DM_Move omv;
    OM_Sound omsound;
    OM_Utterance omutt;
    OM_Text omtext;

    public SetOMmedia(){

	setLayout(new GridLayout(10,2));

	label1 = new Label("type");
	label2 = new Label("play_time");
	label3 = new Label("Synchro_time");
	label4 = new Label("picture: 1");
	label5 = new Label("obj: 3");
	label6 = new Label("text: 4");
	label7 = new Label("move: 5");
	label8 = new Label("sound: 6");
	label9 = new Label("utterance: 7");
	label10 = new Label("name");
	label11 = new Label("next");
	label12 = new Label("command");

	type = new TextField(10);
	playtime = new TextField(10);
	synchro = new TextField(10);
	name = new TextField(10);
	next = new TextField(10);
	command = new TextField(10);

	type.setText("1");
	playtime.setText("-1");
	synchro.setText("-1");
	next.setText("null");
	command.setText("1");

	setButton = new Button("set");
	setButton.addActionListener(this);

	add(label1);
	add(type);
	add(label2);
	add(playtime);
	add(label3);
	add(synchro);
	add(label4);
	add(label5);
	add(label6);
	add(label7);
	add(label8);
	add(label9);
	add(label10);
	add(name);
	add(label11);
	add(next);
	add(label12);
	add(command);
	add(setButton);

	setTitle("OM_Media");
	setSize(250,550);
	show();

	setomatom = new SetOMatom();
	setompoint = new SetOMpoint();
	setompicture = new SetOMpicture(setompoint);
	setomobject = new SetOMobject(setompoint);
	setommove = new SetOMmove(setomatom,setompoint); 
	setomsound = new SetOMsound();
	setomutterance = new SetOMutterance();
	setomtext = new SetOMtext();

    }

    public void actionPerformed(ActionEvent event){
	int typeValue = Integer.parseInt(type.getText());
	int ptime = Integer.parseInt(playtime.getText());
	int stime = Integer.parseInt(synchro.getText());

	switch(typeValue){
	case 1:
	    ompic = setompicture.returnOM_Picture();
	    omobj = null;
	    omv = null;
	    omsound = null;
	    omutt = null;
	    omtext = null;
	    break;
	case 3:
	    ompic = null;
	    omobj = setomobject.returnOM_Object();
	    omv = null;
	    omsound = null;
	    omutt = null;
	    omtext = null;
	    break;	    
	case 4:
	    ompic = null;
	    omobj = null;
	    omv = null;
	    omsound = null;
	    omutt = null;
	    omtext = setomtext.returnOM_Text();
	    break;	   	    
	case 5:
	    ompic = null;
	    omobj = null;
	    omv = setommove.returnOM_Move();
	    omsound = null;
	    omutt = null;
	    omtext = null;
	    break;	 
	case 6:
	    ompic = null;
	    omobj = null;
	    omv = null;
	    omsound = setomsound.returnOM_Sound();
	    omutt = null;
	    omtext = null;
	    break;	
	case 7:
	    ompic = null;
	    omobj = null;
	    omv = null;
	    omsound = null;
	    omutt = setomutterance.returnOM_Utterance();
	    omtext = null;
	    break;
	default:
	    throw(new RuntimeException("Internal Error: got unknown type"));
	}

	String n = name.getText();
	c = Integer.parseInt(command.getText());

//  2000/02/16  Earsh
//	om_media = new OM_Media(typeValue,ptime,stime,ompic,omobj,omv,omsound,omutt,omtext,n);
	om_media = new DM_Media();
	om_media.type         = typeValue;
	om_media.play_time    = ptime;
	om_media.synchro_time = stime;
	om_media.picture      = ompic;
	om_media.object       = omobj;
	om_media.move         = omv;
	om_media.sound        = omsound;
	om_media.utterance    = omutt;
	om_media.text         = omtext;
	om_media.atom         = new DM_Atom();
	om_media.atom.name    = n;
    }

//  2000/02/16  Earsh
//    public OM_Atom returnOM_Atom(){
    public DM_Atom returnOM_Atom(){
	return null;
    }

//  2000/02/16  Earsh
//    public OM_Media returnOM_Media(){
    public DM_Media returnOM_Media(){
	return om_media;
    }

//  2000/02/16  Earsh
//    public OM_Move returnOM_Move(){
    public DM_Move returnOM_Move(){
	return null;
    }
    
//  2000/02/16  Earsh
//    public OM_Object returnOM_Object(){
      public DM_Object returnOM_Object(){
	return null;
    }
    
//  2000/02/16  Earsh
//    public OM_Picture returnOM_Picture(){
    public DM_Picture returnOM_Picture(){
	return null;
    }

//  2000/02/16  Earsh
//    public OM_Point returnOM_Point(){
    public DM_Point returnOM_Point(){
	return null;
    }

    public OM_Sound returnOM_Sound(){
	return null;
    }

    public OM_Utterance returnOM_Utterance(){
	return null;
    }

    public OM_Text returnOM_Text(){
	return null;
    }
}

// ------- OM_Object --------
//  2000/02/16 Earsh
package java_quik.viewer;
import  java_quik.*;

import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class SetOMobject extends Frame implements ActionListener,InfoTranslation {

    Button button;
    Label label1,label2;
    TextField url,ompoint;
//  2000/02/16  Earsh
//    OM_Object om_object;
    DM_Object om_object;
    SetOMpoint setompoint;
    
    public SetOMobject(SetOMpoint setompoint){
	this.setompoint = setompoint;
	setLayout(new GridLayout(3,2));
	
	label1 = new Label("URL");
	label2 = new Label("OM_Point");

	url = new TextField(20);
	ompoint = new TextField(20);
	url.setText("http://alpha.c.oka-pu.ac.jp/~issei/Stage1.class");

	button = new Button("Set");
	button.addActionListener(this);

	add(label1);
	add(url);
	add(label2);
	add(ompoint);
	add(button);

	setTitle("OM_Object");
	setSize(250,200);
	show();
    }

    public void actionPerformed(ActionEvent event){
	String s = url.getText();
//  2000/02/16  Earsh
//	OM_Point op = setompoint.returnOM_Point();
	DM_Point op = setompoint.returnOM_Point();
//  2000/02/16  Earsh
//	om_object = new OM_Object(s,op);
	om_object = new DM_Object();
	om_object.url   = s;
	om_object.point = op;
    }

//  2000/02/16  Earsh
//    public OM_Atom returnOM_Atom(){
    public DM_Atom returnOM_Atom(){
	return null;
    }

//  2000/02/16  Earsh
//    public OM_Media returnOM_Media(){
    public DM_Media returnOM_Media(){
	return null;
    }

//  2000/02/16  Earsh
//    public OM_Move returnOM_Move(){
    public DM_Move returnOM_Move(){
	return null;
    }
    
//  2000/02/16  Earsh
//    public OM_Object returnOM_Object(){
    public DM_Object returnOM_Object(){
	return om_object;
    }
    
//  2000/02/16  Earsh
//    public OM_Picture returnOM_Picture(){
    public DM_Picture returnOM_Picture(){
	return null;
    }

//  2000/02/16  Earsh
//    public OM_Point returnOM_Point(){
    public DM_Point returnOM_Point(){
	return null;
    }

    public OM_Sound returnOM_Sound(){
	return null;
    }

    public OM_Utterance returnOM_Utterance(){
	return null;
    }

    public OM_Text returnOM_Text(){
	return null;
    }

}

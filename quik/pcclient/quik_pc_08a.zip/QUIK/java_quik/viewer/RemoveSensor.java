// ------- ��������菜�� --------
//  2000/02/16 Earsh
package java_quik.viewer;
import  java_quik.*;

import java.util.Enumeration;
import javax.media.j3d.*;
import javax.vecmath.*;

public class RemoveSensor extends Behavior {

    private TransformGroup parent;
    private BranchGroup branchgroup1,branchgroup2;
    private WakeupOnActivation wEntry;
    private WakeupOnDeactivation wExit;
    private boolean activation;

    public RemoveSensor(TransformGroup hTG,BranchGroup branch1,BranchGroup branch2){
	parent = hTG;
	branchgroup1 = branch1;
	branchgroup2 = branch2;
	activation = false;
    }

    public void initialize(){
	wEntry = new WakeupOnActivation();
	wExit = new WakeupOnDeactivation();
	wakeupOn(wExit);
    }

    public void processStimulus(Enumeration criteria){
	activation = !activation;

	if(activation){
	    branchgroup1.detach();
	    branchgroup2.detach();
	    wakeupOn(wExit);
	}else{
	    parent.addChild(branchgroup1);
	    parent.addChild(branchgroup2);
	    wakeupOn(wEntry);
	}
    }

}

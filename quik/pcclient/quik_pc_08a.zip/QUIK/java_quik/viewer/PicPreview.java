// ------- �摜�̎��ʗp�L�����o�X --------
//  2000/02/16 Earsh
package java_quik.viewer;
import  java_quik.*;

import java.awt.*;

public class PicPreview extends Canvas{

    Image image;

    public PicPreview(Image image){
	this.image = image;
	setSize(300,300);
	setVisible(true);
    }

    public void paint(Graphics g){
	System.out.println("IN");
	g.drawImage(image,0,0,300,300,this);
    }

}

	

// ------- �����̃{�b�N�X --------
//  2000/02/16 Earsh
package java_quik.viewer;
import  java_quik.*;

import javax.media.j3d.*;
import javax.vecmath.*;
import com.sun.j3d.utils.geometry.Box;

public class SimpleBox extends TransformGroup{


    public SimpleBox(){
	setCapability(TransformGroup.ALLOW_TRANSFORM_READ);
	setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
	setCapability(TransformGroup.ALLOW_CHILDREN_EXTEND);
	WakeupOnTransformChange wboxTrans = new WakeupOnTransformChange(this);

	Appearance boxApp = new Appearance();
	Material boxmt = new Material( new Color3f(0.2f,0.2f,0.2f),
				       new Color3f(0.0f,0.0f,0.0f),
				       new Color3f(0.2f,0.0f,0.2f),
				       new Color3f(0.5f,0.5f,0.5f),30);
	boxmt.setLightingEnable(true);
	boxApp.setMaterial(boxmt);
	BoxBuild box = new BoxBuild(0.1f,0.1f,0.1f,0.0,0.0,0.0,boxApp);
	addChild(box);
    }

}

// -------- �ړ���񏑂����݃A�v���b�g(3D��) -----------
//  2000/02/16 Earsh
package java_quik.viewer;
import  java_quik.*;

import java.awt.*;
import java.util.*;
import javax.media.j3d.*;
import javax.vecmath.*;

public class DramaViewer {

    int onAirScene;
    float x,y,z;
    float[] temp = new float[3];
    Float fx,fy,fz;
    String s1,s2;
    boolean timerSet = false;
    boolean isPerformed = false;

    Hashtable objcache = new Hashtable();
    Hashtable imagecache = new Hashtable();
    Hashtable cacheX = new Hashtable();
    Hashtable cacheY = new Hashtable();
    Hashtable cacheZ = new Hashtable();

    Stage1 stage1;
    //Stage2 stage2;
    //Stage3 stage3;

    Timer timer;
    VirtualWorldViewer vwViewer;
    MoveWayBoard mwboard;
    InfoPanel infopanel;

//  2000/02/16  Earsh
//    DramaViewer(){
    public DramaViewer(){
	vwViewer = new VirtualWorldViewer("3D Viewer");
	DebugViewer dframe = new DebugViewer(this);
	this.mwboard = dframe.mwboard;
	this.infopanel = dframe.infopanel;
    }

//  2000/02/16 Earsh
//    public void transfer(OM_Media actionData,int command){
    public void transfer(DM_Media actionData,int command){
	timerSet = false;
	isPerformed = false;
	AnalyzeOM_Media om_media = new AnalyzeOM_Media(actionData,command,objcache,imagecache);
	int play_time = om_media.play_time;
	int synchro_time = om_media.synchro_time;
	int thisAction = om_media.returnThisAction();
	String mediaName = om_media.returnMediaName();
	infopanel.om_media = actionData;

        System.out.println("command:" + command);

	switch(command){
	case 1:
		timerSet = true;
		timer = new Timer(play_time,synchro_time,this);

	    switch(thisAction){
	    case 1:
		// �Î~��̏ꍇ
		performPIC(om_media,play_time,synchro_time,mediaName,timer);
		break;
	    case 3:
		// �I�u�W�F�N�g�̏ꍇ
		performOBJ(om_media,play_time,synchro_time,mediaName);
		break;
	    case 4:
		// �e�L�X�g�̏ꍇ
		performTEXT(om_media,play_time,synchro_time,mediaName);
		break;
	    case 5:
		// �ړ��̏ꍇ
		mediaName = om_media.returnTargetName();
		performMOVE(om_media,play_time,synchro_time,mediaName,timer);
		break;
	    case 6:
		// �T�E���h�̏ꍇ
		performSOUND(om_media,play_time,synchro_time,mediaName);
		break;
	    case 7:
		// ���b�̏ꍇ
		performUTTERANCE(om_media,play_time,synchro_time,mediaName);
		break;
	    default:
		throw(new RuntimeException("Internal Error: got unknown type"));		   
	    }
	    break;
	case 2:
	    // ���̏����̏ꍇ
	    mediaName = actionData.atom.name;
	    switch(actionData.type){
	    case 1:
		// �Î~��̏ꍇ
		switch(onAirScene){
		case 1:
		    stage1.removePic(mediaName);
		    mwboard.pcache.remove(mediaName);
		    cacheX.remove(mediaName);
		    cacheY.remove(mediaName);
		    cacheZ.remove(mediaName);
		    mwboard.resetFlag = true;
		    mwboard.repaint();
		    break;
		case 2:
		    //stage2.removeObj(mediaName);
		    mwboard.pcache.remove(mediaName);
		    cacheX.remove(mediaName);
		    cacheY.remove(mediaName);
		    cacheZ.remove(mediaName);
		    mwboard.resetFlag = true;
		    mwboard.repaint();
		    break;
		case 3:
		    //stage3.removeObj(mediaName);
		    mwboard.pcache.remove(mediaName);
		    cacheX.remove(mediaName);
		    cacheY.remove(mediaName);
		    cacheZ.remove(mediaName);
		    mwboard.resetFlag = true;
		    mwboard.repaint();	
		    break;
		default:
		    throw(new RuntimeException("Internal Error: got unknown type"));
		}
		break;
	    case 3:
		// �I�u�W�F�N�g�̏ꍇ
		switch(onAirScene){
		case 1:
		    stage1.removeObj(mediaName);
		    mwboard.pcache.remove(mediaName);
		    mwboard.resetFlag = true;
		    mwboard.repaint();
		    break;
		case 2:
		    //stage2.removeObj(mediaName);
		    mwboard.pcache.remove(mediaName);
		    mwboard.resetFlag = true;
		    mwboard.repaint();
		    break;
		case 3:
		    //stage3.removeObj(mediaName);
		    mwboard.pcache.remove(mediaName);
		    mwboard.resetFlag = true;
		    mwboard.repaint();
		    break;
		default:
		    throw(new RuntimeException("Internal Error: got unknown type"));
		}
		break;
	    default:
		throw(new RuntimeException("Internal Error: got unknown type"));
	    }
	    break;
	case 4:
	    // ������Đ��̏ꍇ
	    switch(thisAction){
	    case 1:
		// �Î~��̏ꍇ
		performPIC(om_media,play_time,synchro_time,mediaName,null);
		break;
	    case 3:
		// �I�u�W�F�N�g�̏ꍇ
		performOBJ(om_media,play_time,synchro_time,mediaName);
		break;
	    case 4:
		// �e�L�X�g�̏ꍇ
		performTEXT(om_media,play_time,synchro_time,mediaName);
		break;
	    case 5:
		// �ړ��̏ꍇ
		temp = om_media.returnXYZPoint();
		x = temp[0];
		y = temp[1];
		z = temp[2];
		switch(onAirScene){
		case 1:
		    stage1.changeState((double)x,(double)y,(double)z,mediaName);
		    break;
		case 2:
		    //stage2.changeState((double)x,(double)y,(double)z,mediaName);
		    break;
		case 3:
		    //stage3.changeState((double)x,(double)y,(double)z,mediaName)
		    break;
		default:
		    throw(new RuntimeException("Internal Error: got unknown type"));
		}
		fx = new Float(x);
		fy = new Float(y);
		fz = new Float(z);
		cacheX.remove(mediaName);
		cacheY.remove(mediaName);
		cacheZ.remove(mediaName);
		cacheX.put(mediaName,fx);
		cacheY.put(mediaName,fy);
		cacheZ.put(mediaName,fz);
		break;
	    case 6:
		// �T�E���h�̏ꍇ
		break;
	    case 7:
		// ���b�̏ꍇ
		break;
	    default:
		throw(new RuntimeException("Internal Error: got unknown type"));
	    }
	default:
	    throw(new RuntimeException("Internal Error: got unknown type"));
	}
	if(!timerSet){
	    isPerformed = true;
	    System.out.println("finish at last.");
	}
    }

    
    // �Î~�惁�f�B�A�����s
    void performPIC(AnalyzeOM_Media om_media,int play_time,int synchro_time,String mediaName,Timer timer){
	s1 = om_media.returnURL();
	s2 = om_media.returnFileName();
	Image image = om_media.returnImage();
	float scale = om_media.returnScale();
	temp = om_media.returnXYZPoint();
	x = temp[0];
	y = temp[1];
	z = temp[2];
	fx = new Float(x);
	fy = new Float(y);
	fz = new Float(z);
	cacheX.put(mediaName,fx);
	cacheY.put(mediaName,fy);
	cacheZ.put(mediaName,fz);		
	if(mediaName.equals("illustration")){
	    MyFrame frame = new MyFrame(image,"illust!!");
	    while(!timer.playEnd){

	    }
	    frame.setVisible(false);
	    frame = null;
	}else {
	    infopanel.setPicInfo(play_time,synchro_time,x,y,z,mediaName,s1,s2,scale);
	    mwboard.initPosition(mediaName,(double)x,(double)y,(double)z);	       
	    vwViewer.setUpPic(onAirScene,(double)x,(double)y,(double)z,scale,mediaName,image);
	}
    }


    // �I�u�W�F�N�g���f�B�A�����s
    void performOBJ(AnalyzeOM_Media om_media,int play_time,int synchro_time,String mediaName){
	s1 = om_media.returnURL();
	s2 = om_media.returnFileName();
	Class objclass = om_media.returnObjClass();
	temp = om_media.returnXYZPoint();
	x = temp[0];
	y = temp[1];
	z = temp[2];
	infopanel.setObjInfo(play_time,synchro_time,x,y,z,mediaName,s1,s2);
	RemakeObj obj = new RemakeObj(objclass,mediaName);
	if(mediaName.equals("background1")){
	    stage1 = obj.returnStage1();
	    vwViewer.setStage1((double)x,(double)y,(double)z,stage1);
	    mwboard.setUpMWP(stage1);	
	    onAirScene = 1;
	}else if(mediaName.equals("background2")){
	    /*
	      panel3D.closeStage(1);
	      stage1 = null;
	      stage2 = obj.returnStage2();
	      vwViewer.setStage2((double)x,(double)y,(double)z,stage2);
	      mwboard.setUpMWP(stage2);	
	      onAirScene = 2;
	    */
	}else if(mediaName.equals("background3")){
	    /*
	      panel3D.closeStage(2);
	      stage2 = null;
	      stage3 = obj.returnStage3();
	      vwViewer.setStage3((double)x,(double)y,(double)z,stage3);
	      mwboard.setUpMWP(stage3);	
	      onAirScene = 3;
	    */
	}else {
	    fx = new Float(x);
	    fy = new Float(y);
	    fz = new Float(z);
	    cacheX.put(mediaName,fx);
	    cacheY.put(mediaName,fy);
	    cacheZ.put(mediaName,fz);
	    TransformGroup objTG = obj.returnObjTG();
	    mwboard.initPosition(mediaName,(double)x,(double)y,(double)z);
	    switch(onAirScene){
	    case 1:
		stage1.showUpObj((double)x,(double)y,(double)z,mediaName,objTG);
		break;
	    case 2:
		//stage2.showUpObj((double)x,(double)y,(double)z,mediaName,objTG);
		break;
	    case 3:
		//stage3.showUpObj((double)x,(double)y,(double)z,meidaName,objTG);
		break;
	    default:
		throw(new RuntimeException("Internal Error: got unknown type"));	
	    }
	}
    }
    

    // �e�L�X�g���f�B�A�����s
    void performTEXT(AnalyzeOM_Media om_media,int play_time,int synchro_time,String mediaName){
	s1 = om_media.returnString();
	s2 = om_media.returnFont();
	float tscale = om_media.returnTextScale();
	temp = om_media.returnRGBValues();
	infopanel.setTextInfo(play_time,synchro_time,mediaName,s1,s2,tscale,temp[0],temp[1],temp[2]);
    }


    // �ړ����f�B�A�����s
    void performMOVE(AnalyzeOM_Media om_media,int play_time,int synchro_time,String mediaName,Timer timer){
	if(mediaName.equals("leftdoor")){
	    stage1.openDoor(0);
	}else if(mediaName.equals("rightdoor")){
	    stage1.openDoor(1);
	}else{
	    int pointsNum = om_media.returnPointsNum();
	    float[] xpoints = om_media.returnXPoints();
	    float[] ypoints = om_media.returnYPoints();
	    float[] zpoints = om_media.returnZPoints();

	    switch(onAirScene){
	    case 1:
		stage1.move(mediaName,pointsNum,xpoints,ypoints,zpoints,cacheX,cacheY,cacheZ,timer);
		break;
	    case 2:
		//stage2.move(mediaName,pointsNum,xpoints,ypoints,zpoints);
		break;
	    case 3:
		//stage3.move(mediaName,pointsNum,xpoints,ypoints,zpoints);
		break;
	    default:
		throw(new RuntimeException("Internal Error: got unknown type"));
	    }

	    infopanel.setMoveInfo(play_time,synchro_time,mediaName);
	}
    }


    // �T�E���h���f�B�A�����s
    void performSOUND(AnalyzeOM_Media om_media,int play_time,int synchro_time,String mediaName){
	s1 = om_media.returnURL();
	s2 = om_media.returnFileName();
	infopanel.setSoundInfo(play_time,synchro_time,mediaName,s1,s2);
    }


    // ���b���f�B�A�����s
    void performUTTERANCE(AnalyzeOM_Media om_media,int play_time,int synchro_time,String mediaName){
	s1 = om_media.returnString();
	s2 = om_media.returnFont();
	float loudness = om_media.returnLoudness();
	float pitch = om_media.returnPitch();
	infopanel.setUttInfo(play_time,synchro_time,mediaName,s1,s2,loudness,pitch);
    }


}


// -------- OM_Object����� ----------
//  2000/02/16 Earsh
package java_quik.viewer;
import  java_quik.*;

import java.net.*;
import java.util.Hashtable;

public class AnalyzeOM_Object {

    String objurl,filename,name;
    float[] points;
    Class objclass = null;

    AnalyzeOM_Point om_point;

//  2000/02/16 Earsh
//    public AnalyzeOM_Object(OM_Object target,Hashtable objcache) {
    public AnalyzeOM_Object(DM_Object target,Hashtable objcache) {
	
	objurl = target.url;
	System.out.println("pass!!");
	filename = objurl.substring(objurl.lastIndexOf("/")+1,objurl.length());
	name = filename.substring(0,filename.lastIndexOf(".class"));
        name = "java_quik.viewer." + name;
	System.out.println(name + "!!");
	if(objcache.containsKey(name)){
	    objclass = (Class)objcache.get(name);
	}else{
	    try{
		URL url = new URL(objurl);    
		CreatClass c = new CreatClass(url,name);
		objclass = c.returnClass();
		objcache.put(name,objclass);
	    }catch(MalformedURLException e){
		System.err.println("MalformedURLException: " + e.getMessage());
	    }
	}

	points = new float[3];
	om_point = new AnalyzeOM_Point(target.point);
	points = om_point.returnPoints();

    }

    public String returnURL(){
	return objurl;
    }

    public String returnFileName(){
	return filename;
    }

    public Class returnObjClass(){
	return objclass;
    }

    public float[] returnXYZpoint(){
	return points;
    }

}

// ------- Interface for setting up obj --------
//  2000/02/16 Earsh
package java_quik.viewer;
import  java_quik.*;

import javax.media.j3d.*;

public interface ObjsetUp {

    public void setPosition(double x,double y,double z);

}

// ------- ���ߋ� -------
//  2000/02/16 Earsh
package java_quik.viewer;
import  java_quik.*;

import javax.media.j3d.*;
import javax.vecmath.*;

public class Key extends TransformGroup {

    public Key(double x,double y,double z){

	Appearance appearance = new Appearance();
	Material material = new Material( new Color3f(0.2f,0.2f,0.2f),
					  new Color3f(0.0f,0.0f,0.0f),
					  new Color3f(0.127f,0.116f,0.063f),
					  new Color3f(0.5f,0.5f,0.5f),30);
	material.setLightingEnable(true);
	appearance.setMaterial(material);

	TransformGroup keyTG = new BoxBuild(0.03f,0.06f,0.6f,0.0,0.015,0.0,appearance);
	TransformGroup keyTG_1_1 = new BoxBuild(0.02f,0.09f,0.04f,-0.055,0.005,0.4,appearance);
	TransformGroup keyTG_1_2 = new BoxBuild(0.05f,0.02f,0.04f,0.0,-0.065,0.4,appearance);
	TransformGroup keyTG_2_1 = new BoxBuild(0.02f,0.09f,0.04f,-0.055,0.005,-0.4,appearance);
	TransformGroup keyTG_2_2 = new BoxBuild(0.05f,0.02f,0.04f,0.0,-0.065,-0.4,appearance);
	addChild(keyTG);
	addChild(keyTG_1_1);
	addChild(keyTG_1_2);
	addChild(keyTG_2_1);
	addChild(keyTG_2_2);

	Transform3D transform = new Transform3D();
	transform.setTranslation(new Vector3d(x,y,z));
	setTransform(transform);
    }

}


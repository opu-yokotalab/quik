// -------- �� ----------
//  2000/02/16 Earsh
package java_quik.viewer;
import  java_quik.*;

import javax.media.j3d.*;
import javax.vecmath.*;
import com.sun.j3d.utils.geometry.Box;

public class Wall extends TransformGroup {

    public Wall(){
	Appearance appearance = new Appearance();
	Material material = new Material( new Color3f(0.2f,0.2f,0.2f),
					  new Color3f(0.0f,0.0f,0.0f),
					  new Color3f(0.169f,0.175f,0.178f),
					  new Color3f(0.5f,0.5f,0.5f),1.0f);
	//wallmt.setLightingEnable(true);
	appearance.setMaterial(material);

        setCapability(TransformGroup.ALLOW_TRANSFORM_READ);
	setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
	setCapability(TransformGroup.ALLOW_CHILDREN_EXTEND);
	setCapability(TransformGroup.ALLOW_CHILDREN_READ);
	setCapability(TransformGroup.ALLOW_CHILDREN_WRITE);


	// ����
	TransformGroup leftWall = new BoxBuild(0.15f,1.3f,2.0f,-5.45,1.2,0.0,appearance);

	TransformGroup centerWall = new TransformGroup();
	TransformGroup centerWall_1 = new BoxBuild(0.15f,1.3f,0.75f,0.0,1.2,1.25,appearance);
        TransformGroup centerWall_2 = new BoxBuild(0.15f,1.3f,0.75f,0.0,1.2,-1.25,appearance);
	TransformGroup centerWall_3 = new BoxBuild(0.15f,0.25f,2.0f,0.0,2.25,0.0,appearance);
	centerWall.addChild(centerWall_1);
	centerWall.addChild(centerWall_2);
	centerWall.addChild(centerWall_3);
	//	TransformGroup centerWall_4 = new BoxBuild(0.17f,1.0f,0.05f,0.0,1.0,0.545,appearance);
	//	TransformGroup centerWall_5 = new BoxBuild(0.17f,1.0f,0.05f,0.0,1.0,-0.545,appearance);
	//	TransformGroup centerWall_6 = new BoxBuild(0.17f,0.05f,0.6f,0.0,2.045,0.0,appearance);
	//	centerWall.addChild(centerWall_4);
	//	centerWall.addChild(centerWall_5);
	//	centerWall.addChild(centerWall_6);
	Transform3D centerTrans = new Transform3D();
	centerTrans.setTranslation(new Vector3d(-2.65,0.0,0.0));
	centerWall.setTransform(centerTrans);


	// �E��
	TransformGroup rightWall = (TransformGroup)centerWall.cloneTree(true);
	Transform3D rightTrans = new Transform3D();
	rightTrans.setTranslation(new Vector3d(2.65,0.0,0.0));
	rightWall.setTransform(rightTrans);	

	addChild(leftWall);
	addChild(centerWall);
	addChild(rightWall);

	TransformGroup outWall_1 = new BoxBuild(1.15f,1.3f,0.5f,-1.45,1.2,-2.5,appearance);
	addChild(outWall_1);


	//�E�̕�+��
	TransformGroup rightwall = new TransformGroup();
	Point3d[] ltcoords = { new Point3d(2.5,4.5,0.0),
			       new Point3d(2.5,2.5,-2.0),
			       new Point3d(2.5,2.5,2.0) };
	Color3f[] colors1 = { new Color3f(1.0f,1.0f,1.0f),
			      new Color3f(1.0f,1.0f,1.0f),
			      new Color3f(1.0f,1.0f,1.0f) };
	Shape3D ltriangle = new Shape3D();
	TriangleArray ltgeom = new TriangleArray(3,TriangleArray.COORDINATES | TriangleArray.COLOR_3 | TriangleArray.NORMALS);
	ltgeom.setCoordinates(0,ltcoords);
        ltgeom.setColors(0,colors1);
	ltriangle.setGeometry(ltgeom);
	//	ltriangle.setAppearance(wallApp);
	rightwall.addChild(ltriangle);

	Point3d[] rtcoords  = { new Point3d(2.8,4.5,0.0),
				new Point3d(2.8,2.5,2.0),
				new Point3d(2.8,2.5,-2.0) };
	Shape3D rtriangle = new Shape3D();
	TriangleArray rtgeom = new TriangleArray(3,TriangleArray.COORDINATES | TriangleArray.COLOR_3 | TriangleArray.NORMALS);
	rtgeom.setCoordinates(0,rtcoords);
	rtgeom.setColors(0,colors1);
	rtriangle.setGeometry(rtgeom);
	//	rtriangle.setAppearance(wallApp);
	rightwall.addChild(rtriangle);	

	Point3d[] fcoords = { new Point3d(2.5,4.5,0.0),
			      new Point3d(2.5,2.5,2.0),
			      new Point3d(2.8,2.5,2.0),
			      new Point3d(2.8,4.5,0.0) };
	Color3f[] colors2 = { new Color3f(1.0f,1.0f,1.0f),
			      new Color3f(1.0f,1.0f,1.0f),
			      new Color3f(1.0f,1.0f,1.0f),
			      new Color3f(1.0f,1.0f,1.0f) };
	Shape3D fquad = new Shape3D();
	QuadArray fgeom = new QuadArray(4,QuadArray.COORDINATES | QuadArray.COLOR_3 | QuadArray.NORMALS);
	fgeom.setCoordinates(0,fcoords);
	fgeom.setColors(0,colors2);
	fquad.setGeometry(fgeom);
	//	fquad.setAppearance(wallApp);
	rightwall.addChild(fquad);

	Point3d[] bcoords = { new Point3d(2.8,4.5,0.0),
			      new Point3d(2.8,2.5,-2.0),
			      new Point3d(2.5,2.5,-2.0),
			      new Point3d(2.5,4.5,0.0) };
	Shape3D bquad = new Shape3D();
	QuadArray bgeom = new QuadArray(4,QuadArray.COORDINATES | QuadArray.COLOR_3 | QuadArray.NORMALS);
	bgeom.setCoordinates(0,bcoords);
	bgeom.setColors(0,colors2);
	bquad.setGeometry(bgeom);
	//	bquad.setAppearance(wallApp);
	rightwall.addChild(bquad);
	addChild(rightwall);


	// ���̕�+��
	TransformGroup leftwall = (TransformGroup)rightwall.cloneTree(true);
	Transform3D lwTrans = new Transform3D();
	lwTrans.setTranslation(new Vector3d(-8.1,0.0,0.0));
	leftwall.setTransform(lwTrans);
	addChild(leftwall);


	// �^�񒆂̕�+��
	TransformGroup centerwall = (TransformGroup)rightwall.cloneTree(true);
	Transform3D cwTrans = new Transform3D();
	cwTrans.setTranslation(new Vector3d(-5.3,0.0,0.0));
	centerwall.setTransform(cwTrans);
	addChild(centerwall);

	
	// ����
	TransformGroup backWall = new BoxBuild(4.2f,1.3f,0.15f,-1.4,1.2,-2.15,appearance);
	addChild(backWall);


	// ��둤�̉���
	BranchGroup b_roofBG = new BranchGroup();
	b_roofBG.setCapability(BranchGroup.ALLOW_DETACH);
	b_roofBG.setCapability(BranchGroup.ALLOW_CHILDREN_EXTEND);
	b_roofBG.setCapability(BranchGroup.ALLOW_CHILDREN_READ);
	b_roofBG.setCapability(BranchGroup.ALLOW_CHILDREN_WRITE);
	b_roofBG.setCapability(BranchGroup.ALLOW_COLLISION_BOUNDS_READ);
	b_roofBG.setCapability(BranchGroup.ALLOW_COLLISION_BOUNDS_WRITE);
	TransformGroup b_transTG1 = new TransformGroup();
	Transform3D b_trans = new Transform3D();
	b_trans.setTranslation(new Vector3d(-1.4,3.4,-1.3));
	b_transTG1.setTransform(b_trans);
	Appearance roof_app = new Appearance();
	Material roof_m = new Material( new Color3f(0.0f,0.0f,0.0f),
					  new Color3f(0.0f,0.0f,0.0f),
					  new Color3f(0.178f,0.138f,0.028f),
					  new Color3f(0.0f,0.0f,0.0f),1.0f);
	//material.setLightingEnable(true);
	roof_app.setMaterial(roof_m);
	TransformGroup b_transTG2 = new TransformGroup();
	Transform3D b_rot = new Transform3D();
	b_rot.rotX(Math.PI/4);
	b_transTG2.setTransform(b_rot);
	Box b_roof = new Box(4.5f,1.9f,0.15f,roof_app);
	b_transTG2.addChild(b_roof);
	b_transTG1.addChild(b_transTG2);
	b_roofBG.addChild(b_transTG1);	
        addChild(b_roofBG);


	// �O��
	BranchGroup f_wallBG = new BranchGroup();
	f_wallBG.setCapability(BranchGroup.ALLOW_DETACH);
	f_wallBG.setCapability(BranchGroup.ALLOW_CHILDREN_EXTEND);
	f_wallBG.setCapability(BranchGroup.ALLOW_CHILDREN_READ);
	f_wallBG.setCapability(BranchGroup.ALLOW_CHILDREN_WRITE);
	f_wallBG.setCapability(BranchGroup.ALLOW_COLLISION_BOUNDS_READ);
	f_wallBG.setCapability(BranchGroup.ALLOW_COLLISION_BOUNDS_WRITE);
	f_wallBG.addChild(new BoxBuild(4.2f,1.3f,0.15f,-1.4,1.2,2.15,appearance));
//	addChild(f_wallBG);


	// �O���̉���
	BranchGroup f_roofBG = new BranchGroup();
	f_roofBG.setCapability(BranchGroup.ALLOW_DETACH);
	f_roofBG.setCapability(BranchGroup.ALLOW_CHILDREN_EXTEND);
	f_roofBG.setCapability(BranchGroup.ALLOW_CHILDREN_READ);
	f_roofBG.setCapability(BranchGroup.ALLOW_CHILDREN_WRITE);
	f_roofBG.setCapability(BranchGroup.ALLOW_COLLISION_BOUNDS_READ);
	f_roofBG.setCapability(BranchGroup.ALLOW_COLLISION_BOUNDS_WRITE);
	TransformGroup f_transTG1 = new TransformGroup();
	Transform3D f_trans = new Transform3D();
	f_trans.setTranslation(new Vector3d(-1.4,3.4,1.3));
	f_transTG1.setTransform(f_trans);
	TransformGroup f_transTG2 = new TransformGroup();
	Transform3D f_rot = new Transform3D();
	f_rot.rotX(-Math.PI/4);
	f_transTG2.setTransform(f_rot);
	Box f_roof = new Box(4.5f,1.9f,0.15f,roof_app);
	f_transTG2.addChild(f_roof);
	f_transTG1.addChild(f_transTG2);
	f_roofBG.addChild(f_transTG1);
//	addChild(f_roofBG);


       
	// �Z���T�[�ɂ��O���̕ǂƉ����������E�A��
	RemoveSensor frontsensor = new RemoveSensor(this,f_wallBG,f_roofBG);
	BoundingBox frontBounds = new BoundingBox(new Point3d(-7.0,0.0,4.0),new Point3d(7.0,20.0,7.0));
	frontsensor.setSchedulingBounds(frontBounds);
	this.addChild(frontsensor);
       
    }

}

	

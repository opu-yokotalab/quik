// ------ OM_Media�쐬 -------
//  2000/02/16 Earsh
package java_quik.viewer;
import  java_quik.*;

public class MakeOM_Media {

//  2000/02/16 Earsh
//    OM_Media new_om_media;
    DM_Media new_om_media;

    // ���̗p���f�B�A���쐬
//  2000/02/16 Earsh
//    public MakeOM_Media(OM_Media om_media,int ptime,int stime,float x,float y,float z,String url,String name){
    public MakeOM_Media(DM_Media om_media,int ptime,int stime,float x,float y,float z,String url,String name){
	new_om_media = om_media;
	new_om_media.play_time = ptime;
//  2000/02/16  Earsh
//	new_om_media.Synchro_time = stime;
	new_om_media.synchro_time = stime;
//  2000/02/16 Earsh
/**
	OM_Point om_point = new OM_Point(x,y,z);
	OM_Object om_obj = new OM_Object(url,om_point);
*/
	DM_Point om_point = new DM_Point();
	om_point.point_x = x;
	om_point.point_y = y;
	om_point.point_z = z;
	DM_Object om_obj = new DM_Object();
	om_obj.url   = url;
	om_obj.point = om_point;
//  2000/02/16  Earsh
//	new_om_media.obj = om_obj;
	new_om_media.object = om_obj;
//  2000/02/16  Earsh
//	new_om_media.name = name;
	new_om_media.atom      = new DM_Atom();
	new_om_media.atom.name = name;
    }

    // ����p���f�B�A���쐬
//  2000/02/16 Earsh
//    public MakeOM_Media(OM_Media om_media,int ptime,int stime,float[] xpoints,float[] ypoints,float[] zpoints,int index,String name,boolean saveFlag){
    public MakeOM_Media(DM_Media om_media,int ptime,int stime,float[] xpoints,float[] ypoints,float[] zpoints,int index,String name,boolean saveFlag){
	new_om_media = om_media;
	new_om_media.play_time = ptime;
	new_om_media.synchro_time = stime;
	if(saveFlag){
//  2000/02/16 Earsh
/**
	    OM_Point firstOMP = new OM_Point(xpoints[0],ypoints[0],zpoints[0]);
	    OM_Point secondOMP = new OM_Point(xpoints[1],ypoints[0],zpoints[1]);
*/
	    DM_Point firstOMP = new DM_Point();
	    firstOMP.point_x = xpoints[0];
	    firstOMP.point_y = ypoints[0];
	    firstOMP.point_z = zpoints[0];
	    DM_Point secondOMP = new DM_Point();
	    secondOMP.point_x = xpoints[1];
	    secondOMP.point_y = ypoints[1];
	    secondOMP.point_z = zpoints[1];
	    firstOMP.next = secondOMP;
	    for(int i=2;i<index;i++){
//  2000/02/16  Earsh
//		OM_Point temp = new OM_Point(xpoints[i],ypoints[i],zpoints[i]);
		DM_Point temp = new DM_Point();
		temp.point_x = xpoints[i];
		temp.point_y = ypoints[i];
		temp.point_z = zpoints[i];
		secondOMP.next = temp;
		secondOMP = temp;
	    }
	    new_om_media.move.point = firstOMP;
	System.out.println(firstOMP.point_x);
	System.out.println(firstOMP.next.point_x);
	System.out.println(firstOMP.next.next.point_x);
	}
//  2000/02/16  Earsh
//	new_om_media.name = name;
	new_om_media.atom      = new DM_Atom();
	new_om_media.atom.name = name;
	System.out.println("!!" + index);
    }

    // �摜�p���f�B�A�����쐬
//  2000/02/16 Earsh
//    public MakeOM_Media(OM_Media om_media,int ptime,int stime,float x,float y,float z,String url,String name,float scale){
    public MakeOM_Media(DM_Media om_media,int ptime,int stime,float x,float y,float z,String url,String name,float scale){
	new_om_media = om_media;
	new_om_media.play_time = ptime;
//  2000/02/16  Earsh
//	new_om_media.Synchro_time = stime;
	new_om_media.synchro_time = stime;
//  2000/02/16 Earsh
/**
	OM_Point om_point = new OM_Point(x,y,z);
	OM_Picture om_pic = new OM_Picture(url,om_point,scale);
*/
	DM_Point om_point = new DM_Point();
	om_point.point_x = x;
	om_point.point_y = y;
	om_point.point_z = z;
	DM_Picture om_pic = new DM_Picture();
	om_pic.url   = url;
	om_pic.point = om_point;
	om_pic.scale = scale;
	new_om_media.picture = om_pic;
//  2000/02/16  Earsh
//	new_om_media.name = name;
	new_om_media.atom      = new DM_Atom();
	new_om_media.atom.name = name;
    }


}

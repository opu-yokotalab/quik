// -------- �}�G�̂��߂̃{�[�h���쐬 ---------
//  2000/02/16 Earsh
package java_quik.viewer;
import  java_quik.*;

import java.awt.*;
import javax.media.j3d.*;
import javax.vecmath.*;
import com.sun.j3d.utils.image.TextureLoader;

public class MakeIllust extends BranchGroup {

    public MakeIllust(Canvas canvas,Image image,Transform3D viewTrans){
	setCapability(BranchGroup.ALLOW_DETACH);
	setCapability(BranchGroup.ALLOW_CHILDREN_EXTEND);
	setCapability(BranchGroup.ALLOW_CHILDREN_WRITE);
	setCapability(BranchGroup.ALLOW_CHILDREN_READ);

	BoundingSphere bounds = new BoundingSphere();
	bounds.setRadius(Double.POSITIVE_INFINITY);

	TransformGroup illustTG = new TransformGroup();
	illustTG.setCapability(TransformGroup.ALLOW_TRANSFORM_READ);
	illustTG.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
	TransformGroup bboardTG = new TransformGroup();
	bboardTG.setCapability(TransformGroup.ALLOW_TRANSFORM_READ);
	bboardTG.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
	
	Transform3D trans = new Transform3D();
	trans.setTranslation(new Vector3d(1.0,0.0,-3.0));
	trans.mul(viewTrans);
	illustTG.setTransform(trans);
	Billboard bboard = new Billboard(bboardTG);
	bboard.setSchedulingBounds(bounds);
	bboard.setAlignmentAxis(0.0f,1.0f,0.0f);

	Texture texture = new TextureLoader(image,canvas).getTexture();
	Appearance appearance = new Appearance();
	appearance.setTexture(texture);
	
	Shape3D board = new Shape3D();
	Point3d[] coords = { new Point3d(-0.4,0.6,0.0),
			     new Point3d(-0.4,0.0,0.0),
			     new Point3d(0.4,0.0,0.0),
			     new Point3d(0.4,0.6,0.0) };
	Point2f[] texCoord = { new Point2f(0.0f,1.0f),
			       new Point2f(0.0f,0.0f),
			       new Point2f(1.0f,0.0f),
			       new Point2f(1.0f,1.0f) };
	QuadArray geom = new QuadArray(4,QuadArray.COORDINATES | QuadArray.NORMALS | QuadArray.TEXTURE_COORDINATE_2);
	geom.setCoordinates(0,coords);
	geom.setTextureCoordinate(0,texCoord[0]);
	geom.setTextureCoordinate(1,texCoord[1]);
	geom.setTextureCoordinate(2,texCoord[2]);
	geom.setTextureCoordinate(3,texCoord[3]);
	board.setGeometry(geom);
	board.setAppearance(appearance);
	bboardTG.addChild(board);

	illustTG.addChild(bboardTG);
	addChild(illustTG);
    }

}

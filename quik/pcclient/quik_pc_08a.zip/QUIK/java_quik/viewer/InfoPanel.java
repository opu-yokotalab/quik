// ------ show up Information of OM_Media --------
//  2000/02/16 Earsh
package java_quik.viewer;
import  java_quik.*;

import java.io.*;
import java.net.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.media.j3d.TransformGroup;

public class InfoPanel extends Panel implements ActionListener,ItemListener,InfoPanelControl {

    private int PIC = 0;
    private int OBJ = 1;
    private int MOVE = 2;
    private int SOUND = 3;
    private int UTTERANCE = 5;
    private int TEXT = 6;
    boolean infoChanged = false,fileChanged = false,fileChecked = false,passFlag = false;
    Choice type;
    Button newbutton,savebutton;
    Label typeLabel,ptimeLabel,stimeLabel,pLabel,xLabel,yLabel,zLabel,urlLabel,fileLabel,nameLabel,nameText,scaleLabel,space1,space2;
    TextField ptimeText,stimeText,pxText,pyText,pzText,urlText,fileText,scaleText;

    GridBagLayout gb;
    GridBagConstraints gc;

//  2000/02/16 Earsh
//    OM_Media om_media;
    DM_Media om_media;
    ObjPreview opreview;

    Stage1 stage1;
    //Stage2 stage2;
    //Stage3 stage3;

    DramaViewer dviewer;
    MoveWayBoard mwboard;
    PointsViewer pviewer;
    MakeOM_Media makeMedia;

    public InfoPanel(DramaViewer dviewer,MoveWayBoard mwboard){
	this.dviewer = dviewer;
	this.mwboard = mwboard;
	stage1 = dviewer.stage1;
	//stage2 = dviewer.stage2;
	//stage3 = dviewer.stage3;

	int REL = GridBagConstraints.RELATIVE;
	int REM = GridBagConstraints.REMAINDER;

	typeLabel = new Label("���f�B�A�^�C�v");
	ptimeLabel = new Label("�Đ�����");
	stimeLabel = new Label("��������");
	pLabel = new Label("�ʒu");
	xLabel = new Label("x");
	yLabel = new Label("y");
	zLabel = new Label("z");
	urlLabel = new Label("URL");
	fileLabel = new Label("�t�@�C����");
	nameLabel = new Label("���f�B�A��");
	scaleLabel = new Label("�k��");
	space1 = new Label("  ");
	space2 = new Label("  ");

	ptimeText = new TextField(10);
	ptimeText.addKeyListener(new MyKeyListener());
	stimeText = new TextField(10);
	stimeText.addKeyListener(new MyKeyListener());
	pxText = new TextField(10);
	pxText.addKeyListener(new MyKeyListener());
	pyText = new TextField(10);
	pyText.addKeyListener(new MyKeyListener());
	pzText = new TextField(10);
	pzText.addKeyListener(new MyKeyListener());
	urlText = new TextField(10);
	urlText.addKeyListener(new MyKeyListener());
	fileText = new TextField(10);
	fileText.addKeyListener(new MyKeyListener());
	nameText = new Label();
	scaleText = new TextField(10);
	scaleText.addKeyListener(new MyKeyListener());

	newbutton = new Button("NEW NODE");
	newbutton.addActionListener(this);
	savebutton = new Button("SAVE NODE");
	savebutton.addActionListener(this);

	type = new Choice();
	type.add("�摜");
	type.add("����");
	type.add("����");
	type.add("�~���[�W�b�N");
	type.add("���b");
	type.add("�e�L�X�g");
	type.addItemListener(this);

	gb = new GridBagLayout();
	gc = new GridBagConstraints();
	setLayout(gb);
	gc.fill = GridBagConstraints.BOTH;
        setParts(0,0,2,1,gc);
	gb.setConstraints(typeLabel,gc);
	add(typeLabel);
	setParts(0,1,2,1,gc);
	gb.setConstraints(ptimeLabel,gc);
	add(ptimeLabel);
	setParts(0,2,2,1,gc);
	gb.setConstraints(stimeLabel,gc);
	add(stimeLabel);
	setParts(0,3,2,1,gc);
	gb.setConstraints(nameLabel,gc);
	add(nameLabel);


	setParts(2,0,1,1,gc);
	gb.setConstraints(type,gc);
	add(type);
	setParts(2,1,1,1,gc);
	gb.setConstraints(ptimeText,gc);
	add(ptimeText);
	setParts(2,2,1,1,gc);
	gb.setConstraints(stimeText,gc);
	add(stimeText);
	setParts(2,3,1,1,gc);
	gb.setConstraints(nameText,gc);
	add(nameText);


	setParts(3,0,2,3,gc);
	gb.setConstraints(pLabel,gc);
	add(pLabel);

	setParts(5,0,1,1,gc);
	gb.setConstraints(xLabel,gc);
	add(xLabel);
	setParts(5,1,1,1,gc);
	gb.setConstraints(yLabel,gc);
	add(yLabel);
	setParts(5,2,1,1,gc);
	gb.setConstraints(zLabel,gc);
	add(zLabel);
	setParts(5,3,1,1,gc);
	gb.setConstraints(scaleLabel,gc);
	add(scaleLabel);


	setParts(6,0,1,1,gc);
	gb.setConstraints(pxText,gc);
	add(pxText);
	setParts(6,1,1,1,gc);
	gb.setConstraints(pyText,gc);
	add(pyText);
	setParts(6,2,1,1,gc);
	gb.setConstraints(pzText,gc);
	add(pzText);
	setParts(6,3,1,1,gc);
	gb.setConstraints(scaleText,gc);
	add(scaleText);


	setParts(7,0,2,1,gc);
	gb.setConstraints(fileLabel,gc);
	add(fileLabel);
	setParts(7,1,2,1,gc);
	gb.setConstraints(urlLabel,gc);
	add(urlLabel);

	setParts(9,0,1,1,gc);
	gb.setConstraints(fileText,gc);
	add(fileText);
	setParts(9,1,1,1,gc);
	gb.setConstraints(urlText,gc);
	add(urlText);
	setParts(9,2,1,1,gc);
	gb.setConstraints(newbutton,gc);
	add(newbutton);
	setParts(9,3,1,1,gc);
	gb.setConstraints(savebutton,gc);
	add(savebutton);

	setSize(600,250);
	setVisible(true);
	mwboard.infopanel = this;
	
    }

    public void actionPerformed(ActionEvent event){
	if(event.getSource() == newbutton){
	    if(mwboard.saveFlag){
		infoChanged = true;
	    }
	    if(infoChanged){	
		int choose = JOptionPane.showConfirmDialog(this,"���f�B�A��񂪕ς���Ă��܂��B\n�ύX���܂����H","���ӁI�I",JOptionPane.YES_NO_OPTION);
		if(choose == JOptionPane.YES_OPTION){
		    saveInfo(type.getSelectedIndex());
		}else if(choose == JOptionPane.NO_OPTION){
		    
		}
	    }
	}else if(event.getSource() == savebutton){
	    int infoType = type.getSelectedIndex();
	    if(fileChanged){
		fileCheck(urlText.getText(),infoType);
	    }
	    saveInfo(infoType);
	    fileChanged = false;
	    fileChecked = false;
	}
		
	System.out.println(event.getActionCommand());
    }




    public void itemStateChanged(ItemEvent event){
	infoChanged = true;
    }

    protected void setParts(int x,int y,int w,int h,GridBagConstraints gc){
	gc.gridx = x;
	gc.gridy = y;
	gc.gridwidth = w;
	gc.gridheight = h;
    }

    public void setMoveInfo(int ptime,int stime,String mediaName){
	pLabel.setVisible(true);
	xLabel.setVisible(true);
	yLabel.setVisible(true);
	zLabel.setVisible(true);
	pxText.setVisible(true);
	pyText.setVisible(true);
	pzText.setVisible(true);
	fileLabel.setVisible(false);
	fileText.setVisible(false);
	urlLabel.setVisible(false);
	urlText.setVisible(false);
	scaleLabel.setVisible(false);
	scaleText.setVisible(false);

	type.select("����");
	pLabel.setText("�ʒu");
	xLabel.setText("x");
	yLabel.setText("y");
	zLabel.setText("z");
	ptimeText.setText(String.valueOf(ptime));
	stimeText.setText(String.valueOf(stime));
	pxText.setText("xpoints");
	pyText.setText("ypoints");
	pzText.setText("zpoints");
	nameText.setText(mediaName);

	mwboard.saveFlag = false;
    }

    public void setObjInfo(int ptime,int stime,float x,float y,float z,String mediaName,String url,String file){
	pLabel.setVisible(true);
	xLabel.setVisible(true);
	yLabel.setVisible(true);
	zLabel.setVisible(true);
	pxText.setVisible(true);
	pyText.setVisible(true);
	pzText.setVisible(true);
	fileLabel.setVisible(true);
	fileText.setVisible(true);
	urlLabel.setVisible(true);
	urlText.setVisible(true);
	scaleLabel.setVisible(false);
	scaleText.setVisible(false);

	type.select("����");
	pLabel.setText("�ʒu");
	xLabel.setText("x");
	yLabel.setText("y");
	zLabel.setText("z");
	fileLabel.setText("�t�@�C����");
	urlLabel.setText("URL");
	ptimeText.setText(String.valueOf(ptime));
	stimeText.setText(String.valueOf(stime));
	pxText.setText(String.valueOf(x));
	pyText.setText(String.valueOf(y));
	pzText.setText(String.valueOf(z));
	nameText.setText(mediaName);
	urlText.setText(url);
	fileText.setText(file);
	
	mwboard.saveFlag = false;
    }

    public void setPicInfo(int ptime,int stime,float x,float y,float z,String mediaName,String url,String file,float scale){
	pLabel.setVisible(true);
	xLabel.setVisible(true);
	yLabel.setVisible(true);
	zLabel.setVisible(true);
	pxText.setVisible(true);
	pyText.setVisible(true);
	pzText.setVisible(true);
	fileLabel.setVisible(true);
	fileText.setVisible(true);
	urlLabel.setVisible(true);
	urlText.setVisible(true);
	scaleLabel.setVisible(true);
	scaleText.setVisible(true);

	type.select("�摜");
	pLabel.setText("�ʒu");
	xLabel.setText("x");
	yLabel.setText("y");
	zLabel.setText("z");
	fileLabel.setText("�t�@�C����");
	urlLabel.setText("URL");       
	ptimeText.setText(String.valueOf(ptime));
	stimeText.setText(String.valueOf(stime));
	pxText.setText(String.valueOf(x));
	pyText.setText(String.valueOf(y));
	pzText.setText(String.valueOf(z));
	nameText.setText(mediaName);
	urlText.setText(url);
	fileText.setText(file);	
	scaleText.setText(String.valueOf(scale));

	mwboard.saveFlag = false;
    }

    public void setSoundInfo(int ptime,int stime,String mediaName,String url,String file){
	pLabel.setVisible(false);
	xLabel.setVisible(false);
	yLabel.setVisible(false);
	zLabel.setVisible(false);
	pxText.setVisible(false);
	pyText.setVisible(false);
	pzText.setVisible(false);
	fileLabel.setVisible(true);
	fileText.setVisible(true);
	urlLabel.setVisible(true);
	urlText.setVisible(true);
	scaleLabel.setVisible(false);
	scaleText.setVisible(false);

	type.select("�~���[�W�b�N");
	fileLabel.setText("�t�@�C����");
	urlLabel.setText("URL");
	ptimeText.setText(String.valueOf(ptime));
	stimeText.setText(String.valueOf(stime));	
	nameText.setText(mediaName);
	urlText.setText(url);
	fileText.setText(file);	
	mwboard.saveFlag = false;
    }

//  2000/02/16  Earsh
//    public void setUttInfo(int ptime,int stime,String mediaName,String str,String font,int loudness,int pitch){
    public void setUttInfo(int ptime,int stime,String mediaName,String str,String font,float loudness,float pitch){
	pLabel.setVisible(false);
	xLabel.setVisible(true);
	yLabel.setVisible(true);
	zLabel.setVisible(false);
	pxText.setVisible(true);
	pyText.setVisible(true);
	pzText.setVisible(false);
	fileLabel.setVisible(true);
	fileText.setVisible(true);
	urlLabel.setVisible(true);
	urlText.setVisible(true);
	scaleLabel.setVisible(false);
	scaleText.setVisible(false);

	type.select("���b");
	fileLabel.setText("����");
	urlLabel.setText("���F");
	xLabel.setText("����");
	yLabel.setText("����");
	ptimeText.setText(String.valueOf(ptime));
	stimeText.setText(String.valueOf(stime));	
	nameText.setText(mediaName);
	pxText.setText(String.valueOf(loudness));
	pyText.setText(String.valueOf(pitch));
	urlText.setText(str);
	fileText.setText(font);	
	mwboard.saveFlag = false;
    }

//  2000/02/16  Earsh
//    public void setTextInfo(int ptime,int stime,String mediaName,String str,String font,int scale,float r,float g,float b){
    public void setTextInfo(int ptime,int stime,String mediaName,String str,String font,float scale,float r,float g,float b){
	pLabel.setVisible(true);
	xLabel.setVisible(true);
	yLabel.setVisible(true);
	zLabel.setVisible(true);
	pxText.setVisible(true);
	pyText.setVisible(true);
	pzText.setVisible(true);
	fileLabel.setVisible(true);
	fileText.setVisible(true);
	urlLabel.setVisible(true);
	urlText.setVisible(true);
	scaleLabel.setVisible(true);
	scaleText.setVisible(true);

	type.select("�e�L�X�g");
	pLabel.setText("RGB�l");
	xLabel.setText("R");
	yLabel.setText("G");
	zLabel.setText("B");
	fileLabel.setText("����");
	urlLabel.setText("�t�H���g");
	ptimeText.setText(String.valueOf(ptime));
	stimeText.setText(String.valueOf(stime));	
	nameText.setText(mediaName);
	pxText.setText(String.valueOf(r));
	pyText.setText(String.valueOf(g));
	pzText.setText(String.valueOf(b));
	fileText.setText(str);	
	urlText.setText(font);
	scaleText.setText(String.valueOf(scale));
	mwboard.saveFlag = false;	
    }

    protected void fileCheck(String targetURL,int t){
	int ynchoose = 0;
	Image image;
	try{
	    URL content = new URL(targetURL);
	    try{
		// ����URL�̃t�@�C��������̂��`�F�b�N�I
		InputStream in = content.openStream();
		in.close();
	    }catch(IOException e){
		String message;
		if(targetURL.equals("http:wrongURL")){
		    message = new String("URL����͂��Ă��������B");
		}else{
		    message = new String("URL���Ԉ���Ă��܂��B������URL����͂��Ă��������B");
		}
		String newURL = JOptionPane.showInputDialog(this,message,"URL Error!!",JOptionPane.ERROR_MESSAGE);
		fileCheck(newURL,t);
		System.out.println("IN");
	    }
	    if(!fileChecked){
		Panel panel = new Panel();
		panel.setLayout(new BorderLayout());
		Canvas preCanvas = new Canvas();
		Label comment = new Label("����ł�낵���ł����H");
		String s;
		switch(t){
		case 0:
		    s = targetURL.substring(targetURL.lastIndexOf("/")+1,targetURL.length());
		    if(dviewer.imagecache.containsKey(s)){
			image = (Image)dviewer.imagecache.get(s);
		    }else{
			Toolkit toolkit = Toolkit.getDefaultToolkit();
			image = toolkit.getImage(content);
			dviewer.imagecache.put(s,image);
		    }
		    preCanvas = new PicPreview(image);
		    break;
		case 1:
		    TransformGroup transTG = new TransformGroup();
		    s = targetURL.substring(targetURL.lastIndexOf("/")+1,targetURL.lastIndexOf(".class"));
		    if(dviewer.objcache.containsKey(s)){
			transTG = (TransformGroup)dviewer.objcache.get(s);
		    }else{
			CreatClass c = new CreatClass(content,s);
			RemakeObj obj = new RemakeObj(c.returnClass(),"obj");
			transTG = obj.returnObjTG();
		    }
		    opreview = new ObjPreview(transTG);
		    preCanvas = opreview.returnCanvas();
		    break;
		default:
		    throw(new RuntimeException("Internal Error: got unknown type"));
		}
		preCanvas.setSize(300,300);
		preCanvas.setVisible(true);
		panel.add(preCanvas,"Center");
		panel.add(comment,"South");
		ynchoose = JOptionPane.showConfirmDialog(this,panel,"preview!!",JOptionPane.YES_NO_OPTION);
		if(ynchoose == 1){
		    fileCheck("http:wrongURL",t);
		}else{
		    urlText.setText(targetURL);
		    if(t == 0){
			fileText.setText(s + ".class");
		    }else{
			fileText.setText(s);
		    }
		    opreview = null;
		    preCanvas = null;
		    fileChecked = true;
		}
	    }
	}catch(MalformedURLException e){
	    System.err.println("MalformedURLException!");
	    fileCheck("http:fault",t);
	}
    }

    protected void saveInfo(int infoType){
	int ptime = Integer.valueOf(ptimeText.getText().trim()).intValue();
	int stime = Integer.valueOf(stimeText.getText().trim()).intValue();
	String name = nameText.getText();
	Float fx,fy,fz;
	double x,y,z;
	String url = new String();
	float scale = 0;
	if(infoType < 2){
	    // ���́E�摜�o���̏ꍇ
	    x = Double.valueOf(pxText.getText().trim()).doubleValue();
	    y = Double.valueOf(pyText.getText().trim()).doubleValue();
	    z = Double.valueOf(pzText.getText().trim()).doubleValue();
	    fx = new Float(x);
	    fy = new Float(y);
	    fz = new Float(z);
	    url = urlText.getText();
	    if(infoType == 0){
		// �摜�̏ꍇ�͏k�ڂ�!
		scale = Float.valueOf(scaleText.getText().trim()).floatValue();
	    }
	    switch(dviewer.onAirScene){
	    case 1:
		switch(infoType){
		case 0:
		    dviewer.stage1.removePic(name);
		    break;
		case 1:
		    dviewer.stage1.removeObj(name);
		    break;
		default:
		    throw(new RuntimeException("Internal Error: got unknown type"));
		}
		break;
	    case 2:
		/*
		      switch(infoType){
		      case 0:
		      dviewer.stage2.removePic(name);
		      break;
		      case 1:
		      dviewer.stage2.removeObj(name);
		      break;
		      default:
		      throw(new RuntimeException("Internal Error: got unknown type"));
		      }
		*/
		break;
	    case 3:
		/*
		  switch(infoType){
		  case 0:
		    dviewer.stage3.removePic(name);
		    break;
		    case 1:
		    dviewer.stage3.removeObj(name);
		    break;
		    default:
		    throw(new RuntimeException("Internal Error: got unknown type"));
		    }
		    */
		break;
	    default:
		throw(new RuntimeException("Internal Error: got unknown type"));
	    }
		dviewer.cacheX.remove(name);
		dviewer.cacheY.remove(name);
		dviewer.cacheZ.remove(name);
		dviewer.cacheX.put(name,fx);
		dviewer.cacheY.put(name,fy);
		dviewer.cacheZ.put(name,fz);
		mwboard.pcache.remove(name);
		mwboard.initPosition(name,x,y,z);
		if(infoType == 0){
		    makeMedia = new MakeOM_Media(om_media,ptime,stime,(float)x,(float)y,(float)z,url,name,scale);
		}else {
		    makeMedia = new MakeOM_Media(om_media,ptime,stime,(float)x,(float)y,(float)z,url,name);
		}
		dviewer.transfer(makeMedia.new_om_media,1);
		mwboard.reset();
	}else{
	    // ����̏ꍇ
	    float[] xpoints = mwboard.xpoints;
	    float[] ypoints = mwboard.ypoints;
	    float[] zpoints = mwboard.zpoints;
	    int index = mwboard.ptindex;
	    x = (double)xpoints[index-1];
	    y = (double)ypoints[index-1];
	    z = (double)zpoints[index-1];
	    fx = new Float(x);
	    fy = new Float(y);
	    fz = new Float(z);
	    dviewer.cacheX.remove(name);
	    dviewer.cacheY.remove(name);
	    dviewer.cacheZ.remove(name);
	    dviewer.cacheX.put(name,fx);
	    dviewer.cacheY.put(name,fy);
	    dviewer.cacheZ.put(name,fz);
	    mwboard.pcache.remove(name);
	    mwboard.initPosition(name,x,y,z);
		
	    // �����Ń��Z�b�g�{�^�����������Ƃ����C�x���g���N��������
	    
	    if(mwboard.stage1 != null){
		mwboard.stage1.moveForSave(name,index,xpoints,ypoints,zpoints);
	    }
	    /*else if(mwboard.stage2 != null){
	      mwboard.stage2.changePosition(x,y,z,name);
	      }else if(mwboard.stage3 != null){
	      mwboard.stage3.changePosition(x,y,z,name);
	      }
	    */	   
	    mwboard.reset();
	}    
	infoChanged = false;
    }


    class MyKeyListener extends KeyAdapter {
	public void keyPressed(KeyEvent e){
	    infoChanged = true;
	    if(e.getSource() == urlText || e.getSource() == fileText){
		fileChanged = true;
	    }
	}
    }
		    
}

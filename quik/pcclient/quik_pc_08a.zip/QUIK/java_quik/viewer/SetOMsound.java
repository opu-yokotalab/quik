// ------- Set Frame Information of 0M_Sound ---------
//  2000/02/16 Earsh
package java_quik.viewer;
import  java_quik.*;

import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class SetOMsound extends Frame implements ActionListener,InfoTranslation {
    
    Label label;
    TextField url;
    Button button;
    OM_Sound om_sound;
   
    public SetOMsound(){
	setLayout(new GridLayout(2,2));

	label = new Label("URL");
	url = new TextField(20);
	url.setText("http://alpha.c.oka-pu.ac.jp/~issei/jamiro1open.wav");
	button = new Button("Set");
	button.addActionListener(this);

	add(label);
	add(url);
	add(button);

	setTitle("OM_Sound");
	setSize(100,100);
	show();
    }

    public void actionPerformed(ActionEvent event){
	String soundurl = url.getText();
//  2000/02/16  Earsh
//	om_sound = new OM_Sound(soundurl);
	om_sound = new OM_Sound();
	om_sound.url = soundurl;
    }

//  2000/02/16  Earsh
//    public OM_Atom returnOM_Atom(){
    public DM_Atom returnOM_Atom(){
	return null;
    }

//  2000/02/16  Earsh
//    public OM_Media returnOM_Media(){
    public DM_Media returnOM_Media(){
	return null;
    }

//  2000/02/16  Earsh
//    public OM_Move returnOM_Move(){
    public DM_Move returnOM_Move(){
	return null;
    }
    
//  2000/02/16  Earsh
//    public OM_Object returnOM_Object(){
    public DM_Object returnOM_Object(){
	return null;
    }
    
//  2000/02/16  Earsh
//    public OM_Picture returnOM_Picture(){
    public DM_Picture returnOM_Picture(){
	return null;
    }

//  2000/02/16  Earsh
//    public OM_Point returnOM_Point(){
    public DM_Point returnOM_Point(){
	return null;
    }

    public OM_Sound returnOM_Sound(){
	return om_sound;
    }

    public OM_Utterance returnOM_Utterance(){
	return null;
    }

    public OM_Text returnOM_Text(){
	return null;
    }
    
}

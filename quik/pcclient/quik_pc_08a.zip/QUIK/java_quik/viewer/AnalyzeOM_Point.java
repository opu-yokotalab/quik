// ------- OM_Point����� ----------
//  2000/02/16 Earsh
package java_quik.viewer;
import  java_quik.*;

public class AnalyzeOM_Point {

    float x,y,z;
//    OM_Point next;
    DM_Point next;

//  2000/02/16 Earsh
//    public AnalyzeOM_Point(OM_Point target){
    public AnalyzeOM_Point(DM_Point target){

	x = target.point_x;
	y = target.point_y;
	z = target.point_z;
	next = null;
    }

    public float[] returnPoints(){
	float[] points = new float[3];
	points[0] = x;
	points[1] = y;
	points[2] = z;
	return points;
    }

}

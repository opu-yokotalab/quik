// ------- Set Frame Information of 0M_Sound ---------
//  2000/02/16 Earsh
package java_quik.viewer;
import  java_quik.*;

import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class SetOMutterance extends Frame implements ActionListener,InfoTranslation {
    
    Label label1,label2,label3,label4;
    TextField str,font,loudness,pitch;
    Button button;
    OM_Utterance om_utterance;
   
    public SetOMutterance(){
	setLayout(new GridLayout(5,2));

	label1 = new Label("str");
	label2 = new Label("font");
	label3 = new Label("loudness");
	label4 = new Label("pitch");
	str = new TextField(10);
	font = new TextField(10);
	loudness = new TextField(10);
	pitch = new TextField(10);
	button = new Button("Set");
	button.addActionListener(this);

	add(label1);
	add(str);
	add(label2);
	add(font);
	add(label3);
	add(loudness);
	add(label4);
	add(pitch);
	add(button);

	setTitle("OM_Utterance");
	setSize(100,100);
	show();
    }

    public void actionPerformed(ActionEvent event){
	String strstring = str.getText();
	String fontstring = str.getText();
	int l = Integer.parseInt(loudness.getText());
	int p = Integer.parseInt(pitch.getText());
	om_utterance = new OM_Utterance(strstring,fontstring,l,p);
    }

//  2000/02/16  Earsh
//    public OM_Atom returnOM_Atom(){
    public DM_Atom returnOM_Atom(){
	return null;
    }

//  2000/02/16  Earsh
//    public OM_Media returnOM_Media(){
    public DM_Media returnOM_Media(){
	return null;
    }

//  2000/02/16  Earsh
//    public OM_Move returnOM_Move(){
    public DM_Move returnOM_Move(){
	return null;
    }
    
//  2000/02/16  Earsh
//    public OM_Object returnOM_Object(){
    public DM_Object returnOM_Object(){
	return null;
    }
    
//  2000/02/16  Earsh
//    public OM_Picture returnOM_Picture(){
    public DM_Picture returnOM_Picture(){
	return null;
    }

//  2000/02/16  Earsh
//    public OM_Point returnOM_Point(){
    public DM_Point returnOM_Point(){
	return null;
    }

    public OM_Sound returnOM_Sound(){
	return null;
    }

    public OM_Utterance returnOM_Utterance(){
	return om_utterance;
    }

    public OM_Text returnOM_Text(){
	return null;
    }
    
}

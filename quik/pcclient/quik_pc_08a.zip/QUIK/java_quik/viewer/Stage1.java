// -------- ��P���X�e�[�W -----------
//  2000/02/16 Earsh
package java_quik.viewer;
import  java_quik.*;

import java.awt.*;
import java.util.Hashtable;
import javax.media.j3d.*;
import javax.vecmath.*;
import com.sun.j3d.utils.image.TextureLoader;
import com.sun.j3d.utils.geometry.Box;
import com.sun.j3d.utils.behaviors.mouse.*;

public class Stage1 extends BranchGroup implements PositionControl {

    BranchGroup illustBG;
    TransformGroup sceneTG,boxTG,ldoorTG,rdoorTG;
    Transform3D sceneTrans,boxTrans,lrot,rrot;
    boolean lopen=false,ropen=false;
    Canvas canvas;
    Thread mythread;

    Hashtable cacheObjTG = new Hashtable();
    Hashtable cachePicTransTG = new Hashtable();
    Hashtable cachePicScaleTG = new Hashtable();
    Hashtable cacheObjBG = new Hashtable();
    Hashtable cachePicBG = new Hashtable();

    public Stage1(){
	canvas = new Canvas();
	sceneTG = new TransformGroup();
	sceneTG.setCapability(TransformGroup.ALLOW_TRANSFORM_READ);
	sceneTG.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
	sceneTG.setCapability(TransformGroup.ALLOW_CHILDREN_EXTEND);
	sceneTG.setCapability(TransformGroup.ALLOW_CHILDREN_READ);
	sceneTG.setCapability(TransformGroup.ALLOW_CHILDREN_WRITE);
	sceneTrans = new Transform3D();
	sceneTrans.setTranslation(new Vector3d(0.0,0.0,0.0));
	sceneTG.setTransform(sceneTrans);

	// �X�e�[�W�S�̂��ړ��\��
	WakeupOnTransformChange wsceneTrans = new WakeupOnTransformChange(sceneTG);


	// �e���͈�
	BoundingSphere bounds = new BoundingSphere();
	bounds.setRadius(Double.POSITIVE_INFINITY);

	// ���C�g
	PointLight light = new PointLight(new Color3f(1.0f,1.0f,1.0f),
					  new Point3f(0.0f,2.5f,1.5f),
					  new Point3f(0.0f,0.0f,0.0f));
	addChild(light);
	light.setInfluencingBounds(bounds);



	// �_�C���N�g���C�g
	DirectionalLight dlight = new DirectionalLight(true,
						       new Color3f(1.0f,1.0f,1.0f),
      						       new Vector3f(0.0f,0.0f,-1.0f));
	addChild(dlight);
	dlight.setInfluencingBounds(bounds);


	// �_�C���N�g���C�g
	DirectionalLight dlight1 = new DirectionalLight(true,
						       new Color3f(1.0f,1.0f,1.0f),
      						       new Vector3f(0.0f,0.0f,-1.0f));
	addChild(dlight1);
	dlight1.setInfluencingBounds(bounds);

	// �_�C���N�g���C�g
	DirectionalLight dlight2 = new DirectionalLight(true,
						       new Color3f(1.0f,1.0f,1.0f),
      						       new Vector3f(-0.5f,-1.0f,-1.0f));
	addChild(dlight2);
	dlight2.setInfluencingBounds(bounds);

	// �_�C���N�g���C�g
	DirectionalLight dlight3 = new DirectionalLight(true,
						       new Color3f(1.0f,1.0f,1.0f),
      						       new Vector3f(-0.5f,-1.0f,-1.0f));
	addChild(dlight3);
	dlight3.setInfluencingBounds(bounds);

	// �_�C���N�g���C�g
	DirectionalLight dlight4 = new DirectionalLight(true,
						       new Color3f(1.0f,1.0f,1.0f),
      						       new Vector3f(0.5f,-1.0f,-1.0f));
	addChild(dlight4);
	dlight4.setInfluencingBounds(bounds);

	// �_�C���N�g���C�g
	DirectionalLight dlight5 = new DirectionalLight(true,
						       new Color3f(1.0f,1.0f,1.0f),
      						       new Vector3f(0.5f,-1.0f,-1.0f));
	addChild(dlight5);
	dlight5.setInfluencingBounds(bounds);

	// �_�C���N�g���C�g
	DirectionalLight dlight6 = new DirectionalLight(true,
						       new Color3f(1.0f,1.0f,1.0f),
      						       new Vector3f(-0.25f,-1.0f,-1.0f));
	addChild(dlight6);
	dlight6.setInfluencingBounds(bounds);

	// �_�C���N�g���C�g
	DirectionalLight dlight7 = new DirectionalLight(true,
						       new Color3f(1.0f,1.0f,1.0f),
      						       new Vector3f(-0.25f,-1.0f,-1.0f));
	addChild(dlight7);
	dlight7.setInfluencingBounds(bounds);

	// �_�C���N�g���C�g
	DirectionalLight dlight8 = new DirectionalLight(true,
						       new Color3f(1.0f,1.0f,1.0f),
      						       new Vector3f(0.25f,-1.0f,-1.0f));
	addChild(dlight8);
	dlight8.setInfluencingBounds(bounds);

	// �_�C���N�g���C�g
	DirectionalLight dlight9 = new DirectionalLight(true,
						       new Color3f(1.0f,1.0f,1.0f),
      						       new Vector3f(0.25f,-1.0f,-1.0f));
	addChild(dlight9);
	dlight9.setInfluencingBounds(bounds);


        // �o�b�N�O���E���h
        Background back = new Background(new Color3f(0.0f,0.212f,0.255f));
        back.setBounds(bounds);
        back.setApplicationBounds(bounds);
        addChild(back);

	// ��
	sceneTG.addChild(new House());

	// �h�A
	ldoorTG = new TransformGroup();
	ldoorTG.setCapability(TransformGroup.ALLOW_TRANSFORM_READ);
	ldoorTG.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
	WakeupOnTransformChange wlrot = new WakeupOnTransformChange(ldoorTG);
	rdoorTG = new TransformGroup();
	rdoorTG.setCapability(TransformGroup.ALLOW_TRANSFORM_READ);
	rdoorTG.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
	WakeupOnTransformChange wrrot = new WakeupOnTransformChange(rdoorTG);
	sceneTG.addChild(new Door(ldoorTG,rdoorTG));

	// �n��
	Appearance floorApp = new Appearance();
	Material floormt = new Material( new Color3f(0.0f,0.0f,0.0f),
					 new Color3f(0.0f,0.0f,0.0f),
					 new Color3f(0.178f,0.138f,0.028f),
					 new Color3f(0.0f,0.0f,0.0f),1.0f);
	floormt.setLightingEnable(true);
	floorApp.setMaterial(floormt);
	
	BoxBuild floor = new BoxBuild(20.0f,0.1f,15.0f,0.0,-0.1,0.0,floorApp);
	sceneTG.addChild(floor);


	// �֎q
	sceneTG.addChild(new Chair(-0.8,0.7,0.0));

	// �h�J��
	sceneTG.addChild(new Embroidery(1.8,0.7,-1.6));

	// �^���X
	sceneTG.addChild(new Shelf(-2.15,0.35,-1.35));

	// �O�ɂ��镨�u���H
	sceneTG.addChild(new BoxBuild(0.6f,1.0f,0.3f,-1.0,1.0,-2.25,floorApp));

	// �h�A�̗��ߖ�
	sceneTG.addChild(new Key(2.46,1.0,-1.2));


        // �}�E�X������\��
        MouseRotate rotator = new MouseRotate(sceneTG);
        MouseTranslate translate = new MouseTranslate(sceneTG);
        MouseZoom zoomer = new MouseZoom(sceneTG);
        rotator.setSchedulingBounds(bounds);
        translate.setSchedulingBounds(bounds);
        zoomer.setSchedulingBounds(bounds);
        sceneTG.addChild(rotator);
        sceneTG.addChild(translate);
        sceneTG.addChild(zoomer);


	addChild(sceneTG);
    }

    public void move(String name,int index,float[] xpoints,float[] ypoints,float[] zpoints,Hashtable cacheX,Hashtable cacheY,Hashtable cacheZ,Timer timer){

	TransformGroup transGroup = new TransformGroup();
	if(cachePicTransTG.containsKey(name)){
	    transGroup = (TransformGroup) cachePicTransTG.get(name);
	}else if(cacheObjTG.containsKey(name)){
	    transGroup = (TransformGroup) cacheObjTG.get(name);
	}
	MoveThread movethread = new MoveThread(name,transGroup,index,xpoints,ypoints,zpoints,cacheX,cacheY,cacheZ,timer);
    }

    public void moveForWrite(String name,int index,double scale,double[] xpoints,double[] ypoints,double[] zpoints){
	Thread thread = Thread.currentThread();
	double x1 =0,x2 =0,xd =0;
	double y1 =0,y2 =0,yd =0;
	double z1 =0,z2 =0,zd =0;
	TransformGroup transGroup = new TransformGroup();
	if(cachePicTransTG.containsKey(name)){
	    transGroup = (TransformGroup) cachePicTransTG.get(name);
	}else if(cacheObjTG.containsKey(name)){
	    transGroup = (TransformGroup) cacheObjTG.get(name);
	}
	Transform3D trans = new Transform3D();
	for(int i=0; i<index-1 ; i++){
	    x1 = (double)(xpoints[i]/100-2.5)*scale;
	    y1 = (double)(ypoints[i]);
	    z1 = (double)(zpoints[i]/100-2.0)*scale;
	    x2 = (double)(xpoints[i+1]/100-2.5)*scale;
	    y2 = (double)(ypoints[i+1]);
	    z2 = (double)(zpoints[i+1]/100-2.0)*scale;
	    xd = (x2 - x1)/8;
	    yd = (y2 - y1)/8;
	    zd = (z2 - z1)/8;
	    for(int j=0; j<9 ; j++){
		System.out.println("x=" + x1 + ",y=" + ypoints[i] + ",z=" +z1);
//		trans.setTranslation(new Vector3d(x1,ypoints[i],z1));
		trans.setTranslation(new Vector3d(x1,y1,z1));
		transGroup.setTransform(trans);
		x1 = x1+xd;
		y1 = y1+yd;
		z1 = z1+zd;
		try{
		    thread.sleep(1);
		}catch(InterruptedException e){
		    System.out.println("Interrupted!!");
		}
	    }
	}
    }

    public void moveForSave(String name,int index,float[] xpoints,float[] ypoints,float[] zpoints){
	Thread thread = Thread.currentThread();
	double x1 =0,x2 =0,xd =0;
	double y1 =0,y2 =0,yd =0;
	double z1 =0,z2 =0,zd =0;
	TransformGroup transGroup = new TransformGroup();
	if(cachePicTransTG.containsKey(name)){
	    transGroup = (TransformGroup) cachePicTransTG.get(name);
	}else if(cacheObjTG.containsKey(name)){
	    transGroup = (TransformGroup) cacheObjTG.get(name);
	}
	Transform3D trans = new Transform3D();
	for(int i=0; i<index-1 ; i++){
	    x1 = (double)xpoints[i];
	    y1 = (double)ypoints[i];
	    z1 = (double)zpoints[i];
	    x2 = (double)xpoints[i+1];
	    y2 = (double)ypoints[i+1];
	    z2 = (double)zpoints[i+1];
	    xd = (x2 - x1)/8;
	    yd = (y2 - y1)/8;
	    zd = (z2 - z1)/8;
	    for(int j=0; j<9 ; j++){
		System.out.println("x=" + x1 + ",y=" + ypoints[i] + ",z=" +z1);
//		trans.setTranslation(new Vector3d(x1,ypoints[i],z1));
		trans.setTranslation(new Vector3d(x1,y1,z1));
		transGroup.setTransform(trans);
		x1 = x1+xd;
		y1 = y1+yd;
		z1 = z1+zd;
		try{
		    thread.sleep(1);
		}catch(InterruptedException e){
		    System.out.println("Interrupted!!");
		}
	    }
	}
    }

    public void resetPosition(String target,double x,double y,double z){
	TransformGroup targetTG = new TransformGroup();
	if(cachePicTransTG.containsKey(target)){
	    targetTG = (TransformGroup) cachePicTransTG.get(target);
	}else if(cacheObjTG.containsKey(target)){
	    targetTG = (TransformGroup) cacheObjTG.get(target);
	}
	Transform3D targetTrans = new Transform3D();
	targetTrans.setTranslation(new Vector3d(x,y,z));
	targetTG.setTransform(targetTrans);
    }

    public void setUpScene(Canvas canvas,double x,double y,double z){
	this.canvas = canvas;
	sceneTrans.setTranslation(new Vector3d(x,y,z));
	sceneTG.setTransform(sceneTrans);
    }

    public void showUpObj(double x,double y,double z,String name,TransformGroup objTG){
	BranchGroup branch = new BranchGroup();
	branch.setCapability(BranchGroup.ALLOW_DETACH);
	branch.setCapability(BranchGroup.ALLOW_CHILDREN_EXTEND);
	branch.setCapability(BranchGroup.ALLOW_CHILDREN_WRITE);
	branch.setCapability(BranchGroup.ALLOW_CHILDREN_READ);
	Transform3D trans = new Transform3D();
	trans.setTranslation(new Vector3d(x,y,z));
	objTG.setTransform(trans);
	branch.addChild(objTG);
	WakeupOnTransformChange wobj = new WakeupOnTransformChange(objTG);
	sceneTG.addChild(branch);
	
	cacheObjBG.put(name,branch);
	cacheObjTG.put(name,objTG);
    }

    public void showUpPic(double x,double y,double z,String name,float scale,double ratio,Image image){
	MakeChara branch = new MakeChara(canvas,image,x,y,z,scale,ratio);
	sceneTG.addChild(branch);
	cachePicBG.put(name,branch);
	cachePicTransTG.put(name,branch.transTG);
	cachePicScaleTG.put(name,branch.scaleTG);
    }

    public void showIllust(Image image,Transform3D viewTrans){
	illustBG = new MakeIllust(canvas,image,viewTrans);
	sceneTG.addChild(illustBG);
    }
    
    public void changeState(double x,double y,double z,String name){
	TransformGroup targetTG = new TransformGroup();
	if(cacheObjTG.containsKey(name)){
	    targetTG = (TransformGroup)cacheObjTG.get(name);
	}else{
	    targetTG = (TransformGroup)cachePicTransTG.get(name);
	}
	Transform3D newTrans = new Transform3D();
	newTrans.setTranslation(new Vector3d(x,y,z));
	targetTG.setTransform(newTrans);
    }
    /*
    public void changeState(double x,double y,double z,float scale,String name){
	TransformGroup targetTG_1 = (TransformGroup)cachePicTransTG.get(name);
	TransformGroup targetTG_2 = (TransformGroup)cachePicScaleTG.get(name);
	Transform3D newTrans = new Transform3D();
	Transform3D newScale = new Transform3D();
	newTrans.setTranslation(new Vector3d(x,y,z));
	newScale.setScale(scale);
	targetTG_1.setTransform(newTrans);
	targetTG_2.setTransform(newScale);
    }
    */
    public void removeObj(String name){
        System.out.println("Name:" + name);
	BranchGroup branch = (BranchGroup)cacheObjBG.get(name);
	branch.detach();
	cacheObjBG.remove(name);
	cacheObjTG.remove(name);
    }

    public void removePic(String name){
	BranchGroup branch = (BranchGroup)cachePicBG.get(name);
	branch.detach();
	cachePicBG.remove(name);
	cachePicTransTG.remove(name);
	cachePicScaleTG.remove(name);
    }

    public void openDoor(int side){
	mythread = new Thread();
	switch(side){
	case 0:
	    // ���h�A�I�[�v���E�N���[�Y
	    lopen = !lopen;
	    Transform3D lrot = new Transform3D();
	    if(lopen){
		for(double i=0.1;i<=1;i+=0.1){
		    lrot.rotY(Math.PI/2*i);
		    ldoorTG.setTransform(lrot);
		    try{
			mythread.sleep(50);
		    }catch(InterruptedException e){
			System.out.println("Interrupted!!");
		    }
		}
	    }else {
		System.out.println("lclose");
		for(double j=1;j>=0;j-=0.1){
		    lrot.rotY(Math.PI/2*j);
		    ldoorTG.setTransform(lrot);
		    try{
			mythread.sleep(50);
		    }catch(InterruptedException e){
			System.out.println("Interrupted!!");
		    }
		}
	    }
	    break;
	case 1:
	    // �E�h�A�I�[�v���E�N���[�Y
	    ropen = !ropen;
	    Transform3D rrot = new Transform3D();
	    if(ropen){
		for(double i=0.1;i<=1;i+=0.1){
		    rrot.rotY(Math.PI/2*i);
		    rdoorTG.setTransform(rrot);
		    try{
			mythread.sleep(50);
		    }catch(InterruptedException e){
			System.out.println("Interrupted!!");
		    }
		}
	    }else {
		for(double j=1;j>=0;j-=0.1){
		    rrot.rotY(Math.PI/2*j);
		    rdoorTG.setTransform(rrot);
		    try{
			mythread.sleep(50);
		    }catch(InterruptedException e){
			System.out.println("Interrupted!!");
		    }
		}
	    }
	    break;
	default:
	    throw(new RuntimeException("Internal Error: got unknown type"));
	}
	
    }
		
	    

}

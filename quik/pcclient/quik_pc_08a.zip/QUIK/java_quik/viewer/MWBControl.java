// ------ MoveWayPanel's Interface --------
//  2000/02/16 Earsh
package java_quik.viewer;
import  java_quik.*;

import java.awt.Graphics;

public interface MWBControl {

    public void setUpMWP(Stage1 stage);
    /*
    public void setUpMWP(Stage2 stage);

    public void setUPMWP(Stage3 stage);
    */

    public void initPosition(String name,double x,double y,double z);

    public void initDraw(Graphics g);

    public void changeAllPosition();

    public void setGoSign(Graphics g);

    public void drawRoad(Graphics g);

    public void resetCanvas(Graphics g);

    public void reset();

}

// ------- OM_Picture����� ----------
//  2000/02/16 Earsh
package java_quik.viewer;
import  java_quik.*;

import java.io.*;
import java.awt.*;
import java.net.*;
import java.util.Hashtable;

//  2000/02/17  Earsh
//public class AnalyzeOM_Picture {
//  MediaTracker ���g�����ߖ������Canvas���p��
public class AnalyzeOM_Picture extends Canvas {

    boolean errorFlag = false;
    String urlString,fileName;
    float scale;
    float[] points;
    Image image;
    AnalyzeOM_Point om_point;

//  2000/02/16 Earsh
//    public AnalyzeOM_Picture(OM_Picture target,Hashtable imagecache){
    public AnalyzeOM_Picture(DM_Picture target,Hashtable imagecache){
	points = new float[3];
	urlString = target.url;
	fileName = urlString.substring(urlString.lastIndexOf("/")+1,urlString.length());
	om_point = new AnalyzeOM_Point(target.point);
	points = om_point.returnPoints();
	scale = target.scale;
        MediaTracker mt = new MediaTracker(this);

	if(imagecache.containsKey(fileName)){
	    image = (Image)imagecache.get(fileName);
	}else {
	    try{
		Toolkit t = Toolkit.getDefaultToolkit();
		URL content = new URL(urlString);
		try{
		    // ����URL�̃t�@�C��������̂��`�F�b�N�I
		    InputStream in = content.openStream();
		    in.close();
		}catch(IOException e){
		    System.err.println("IO Error!");
		    errorFlag = true;
		}
		image = t.getImage(content);
                mt.addImage( image, 0);
                try {
                  mt.waitForAll();
                } catch ( InterruptedException ie ) {}
		imagecache.put(fileName,image);
	    }catch(MalformedURLException e){
		System.err.println("URL Error!");
	    }
	}
    }

    public String returnURL(){
	return urlString;
    }

    public String returnFileName(){
	return fileName;
    }

    public float[] returnXYZpoint(){
	return points;
    }

    public Image returnImage(){
	return image;
    }
    
    public float returnScale(){
	return scale;
    }
}

// ------- Set Frame Information of 0M_Point ---------
//  2000/02/16 Earsh
package java_quik.viewer;
import  java_quik.*;

import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class SetOMpoint extends Frame implements ActionListener,InfoTranslation {

    int pointsLength;
    Button button1,button2,button3,button4;
    Label label1,label2,label3,label4;
    TextField xpoint,ypoint,zpoint,next;
//  2000/02/16  Earsh
//    OM_Point om_point,n_om_point;
    DM_Point om_point,n_om_point;
    
    public SetOMpoint(){
	setLayout(new GridLayout(6,2));
	
	label1 = new Label("point_x");
	label2 = new Label("point_y");
	label3 = new Label("point_z");
	label4 = new Label("next");

	xpoint = new TextField(20);
	ypoint = new TextField(20);
	zpoint = new TextField(20);
	next = new TextField(20);

	button1 = new Button("Set");
	button1.addActionListener(this);
	button2 = new Button("Make Move-Points");
	button2.addActionListener(this);
	button3 = new Button("Close Make M-P");
	button3.addActionListener(this);
	button4 = new Button("Look Move-Points");
	button4.addActionListener(this);

	add(label1);
	add(xpoint);
	add(label2);
	add(ypoint);
	add(label3);
	add(zpoint);
	add(label4);
	add(next);
	add(button1);
	add(button2);
	add(button3);
	add(button4);

	setTitle("OM_Point");
	setSize(250,200);
	show();
    }

    public void actionPerformed(ActionEvent event){
	if(event.getSource() == button1){
	    float x = Float.valueOf(xpoint.getText()).floatValue();
	    float y = Float.valueOf(ypoint.getText()).floatValue();
	    float z = Float.valueOf(zpoint.getText()).floatValue();
//  2000/02/16  Earsh
//	    om_point = new OM_Point(x,y,z);
	    om_point = new DM_Point();
	    om_point.point_x = x;
	    om_point.point_y = y;
	    om_point.point_z = z;
	}else if(event.getSource() == button2){
	    pointsLength++;
	    float x = Float.valueOf(xpoint.getText()).floatValue();
	    float y = Float.valueOf(ypoint.getText()).floatValue();
	    float z = Float.valueOf(zpoint.getText()).floatValue();
	    if(pointsLength == 1){
//  2000/02/16  Earsh
//		n_om_point = new OM_Point(x,y,z);
		n_om_point = new DM_Point();
		n_om_point.point_x = x;
		n_om_point.point_y = y;
		n_om_point.point_z = z;
		om_point.next = n_om_point;
	    }else {
//  2000/02/16  Earsh
//		OM_Point temp = new OM_Point(x,y,z);
		DM_Point temp = new DM_Point();
		temp.point_x = x;
		temp.point_y = y;
		temp.point_z = z;
		n_om_point.next = temp;
		n_om_point = temp;
	    }
	}else if(event.getSource() == button3){
	    pointsLength = 0;
	}else if(event.getSource() == button4){
//  2000/02/16  Earsh
//	    OM_Point temp = om_point;
	    DM_Point temp = om_point;
	    int num = 1;
	    do{
		float x = temp.point_x;
		float y = temp.point_y;
		float z = temp.point_z;
		System.out.println("Point" + num + "=(" + x + "," + y + "," + z + ")");
		num++;
		temp = temp.next;
	    }while(temp != null);
	}
    }

//  2000/02/16  Earsh
//    public OM_Atom returnOM_Atom(){
    public DM_Atom returnOM_Atom(){
	return null;
    }

//  2000/02/16  Earsh
//    public OM_Media returnOM_Media(){
    public DM_Media returnOM_Media(){
	return null;
    }

//  2000/02/16  Earsh
//    public OM_Move returnOM_Move(){
    public DM_Move returnOM_Move(){
	return null;
    }
    
//  2000/02/16  Earsh
//    public OM_Object returnOM_Object(){
    public DM_Object returnOM_Object(){
	return null;
    }
    
//  2000/02/16  Earsh
//    public OM_Picture returnOM_Picture(){
    public DM_Picture returnOM_Picture(){
	return null;
    }

//  2000/02/16  Earsh
//    public OM_Point returnOM_Point(){
    public DM_Point returnOM_Point(){
	return om_point;
    }

    public OM_Sound returnOM_Sound(){
	return null;
    }

    public OM_Utterance returnOM_Utterance(){
	return null;
    }

    public OM_Text returnOM_Text(){
	return null;
    }

}     

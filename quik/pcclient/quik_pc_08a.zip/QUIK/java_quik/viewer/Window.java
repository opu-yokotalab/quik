// ------- �� --------
//  2000/02/16 Earsh
package java_quik.viewer;
import  java_quik.*;

import javax.media.j3d.*;
import javax.vecmath.*;

public class Window extends TransformGroup {

    public Window(double x,double y,double z){
	Transform3D trans = new Transform3D();
	trans.setTranslation(new Vector3d(x,y,z));
	setTransform(trans);
	Appearance appearance = new Appearance();
	Material material = new Material( new Color3f(0.0f,0.0f,0.0f),
					  new Color3f(0.0f,0.0f,0.0f),
					  new Color3f(0.102f,0.051f,0.0f),
					  new Color3f(0.0f,0.0f,0.0f),1.0f );
	material.setLightingEnable(true);
	appearance.setMaterial(material);
	TransformGroup left_frame = new BoxBuild(0.025f,0.5f,0.175f,-0.6,0.0,0.0,appearance);
	TransformGroup right_frame = new BoxBuild(0.025f,0.5f,0.175f,0.6,0.0,0.0,appearance);
	TransformGroup top_frame = new BoxBuild(0.65f,0.05f,0.2f,0.0,0.55,0.0,appearance);
	TransformGroup bottom_frame = new BoxBuild(0.65f,0.05f,0.2f,0.0,-0.55,0.0,appearance);

	addChild(left_frame);
	addChild(right_frame);
	addChild(top_frame);
	addChild(bottom_frame);
    }

}

// ------- Interface for InfoViewer.java --------
//  2000/02/16 Earsh
package java_quik.viewer;
import  java_quik.*;

public interface InfoPanelControl {

    public void setMoveInfo(int ptime,int stime,String meidaName);

    public void setObjInfo(int ptime,int stime,float x,float y,float z,String mediaName,String url,String file);

    public void setPicInfo(int ptime,int stime,float x,float y,float z,String mediaName,String url,String file,float scale);

    public void setSoundInfo(int ptime,int stime,String mediaName,String url,String file);

//  2000/02/16  Earsh
//    public void setUttInfo(int ptime,int stime,String mediaName,String str,String font,int loudness,int pitch);
    public void setUttInfo(int ptime,int stime,String mediaName,String str,String font,float loudness,float pitch);

//  2000/02/16  Earsh
//    public void setTextInfo(int ptime,int stime,String mediaName,String str,String font,int scale,float r,float g,float b);
    public void setTextInfo(int ptime,int stime,String mediaName,String str,String font,float scale,float r,float g,float b);

}

// --------- �ƍ쐬 ----------
//  2000/02/16 Earsh
package java_quik.viewer;
import  java_quik.*;

import javax.media.j3d.*;
import javax.vecmath.*;
import com.sun.j3d.utils.geometry.Sphere;

public class House extends TransformGroup {

    public House(){
        this.setCapability(TransformGroup.ALLOW_TRANSFORM_READ);
	this.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
        this.setCapability(TransformGroup.ALLOW_CHILDREN_EXTEND);
	this.setCapability(TransformGroup.ALLOW_CHILDREN_READ);
	this.setCapability(TransformGroup.ALLOW_CHILDREN_WRITE);

	// ��
	addChild(new Wall());

	// ��
	addChild(new Window(0.6,1.3,-2.15));
/*
	// �^�C��
	Appearance tileApp = new Appearance();
	Material tilemt = new Material(new Color3f(0.0f,0.0f,0.0f),
				       new Color3f(0.0f,0.0f,0.0f),
				       new Color3f(0.229f,0.152f,0.0f),
				       new Color3f(0.0f,0.0f,0.0f),1.0f);
	tilemt.setLightingEnable(true);
	tileApp.setMaterial(tilemt);
	for(int i=0;i<4;i++){
	    for(int j=0;j<20;j++){
		addChild(new BoxBuild(0.1f,0.02f,0.5f,2.5-0.412*j,0.0,-1.5+1.01*i,tileApp));
	    }
	}
	for(int i=0;i<3;i++){
	    for(int j=0;j<19;j++){
		addChild(new BoxBuild(0.1f,0.02f,0.5f,2.295-0.412*j,0.0,-1.0+1.01*i,tileApp));
	    }
	}
	for(int i=0;i<19;i++){
	    addChild(new BoxBuild(0.1f,0.02f,0.26f,2.295-0.412*i,0.0,-1.77,tileApp));
	    addChild(new BoxBuild(0.1f,0.02f,0.26f,2.295-0.412*i,0.0,1.79,tileApp));
	}
  
	// �^�C����
	Shape3D ground = new Shape3D();
	Point3d[] points = { new Point3d(-5.5,0.001,-2.0),
			     new Point3d(-5.5,0.001,2.0),
			     new Point3d(2.6,0.001,2.0),
			     new Point3d(2.6,0.001,-2.0) };
	Color3f[] colors = { new Color3f(0.0f,0.0f,0.0f),
			     new Color3f(0.0f,0.0f,0.0f),
			     new Color3f(0.0f,0.0f,0.0f),
			     new Color3f(0.0f,0.0f,0.0f) };
	QuadArray tilegeom = new QuadArray(4,QuadArray.COORDINATES | QuadArray.NORMALS | QuadArray.COLOR_3);
	tilegeom.setCoordinates(0,points);
	tilegeom.setColors(0,colors);
	ground.setGeometry(tilegeom);
	addChild(ground);
*/
    }

}

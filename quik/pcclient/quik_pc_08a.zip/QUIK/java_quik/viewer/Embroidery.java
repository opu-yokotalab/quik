// ---------- �h�J�� -------------
//  2000/02/16 Earsh
package java_quik.viewer;
import  java_quik.*;

import java.awt.Frame;
import javax.media.j3d.*;
import javax.vecmath.*;
import com.sun.j3d.utils.geometry.Cylinder;
import com.sun.j3d.utils.universe.*;
import com.sun.j3d.utils.behaviors.mouse.*;

public class Embroidery extends BranchGroup{

    public Embroidery(double x,double y,double z){

      TransformGroup eGroup = new TransformGroup();
      Transform3D eTrans = new Transform3D();
      eTrans.setTranslation(new Vector3d(x,y,z));
      eGroup.setTransform(eTrans);

      Appearance app = new Appearance();
      Material mt = new Material( new Color3f(0.0f,0.0f,0.0f),
				  new Color3f(0.0f,0.0f,0.0f),
				  new Color3f(0.102f,0.051f,0.00f),
				  new Color3f(0.0f,0.0f,0.0f), 1.0f );
      mt.setLightingEnable(true);
      app.setMaterial(mt);

      
      // �h�J��쐬
      BuildEmbroidery buildE = new BuildEmbroidery(eGroup,app);
      
      // �V���v���Ȉ֎q�쐬
      TransformGroup seat = new BoxBuild(0.25f,0.03f,0.13f,0.0,-0.38,0.3,app);
      TransformGroup leftFoot = new BoxBuild(0.025f,0.15f,0.1f,-0.175,-0.55,0.3,app);
      TransformGroup rightFoot = new BoxBuild(0.025f,0.15f,0.1f,0.175,-0.55,0.3,app);
      eGroup.addChild(seat);
      eGroup.addChild(leftFoot);
      eGroup.addChild(rightFoot);

      // �S���̂̈ړ�����
      eGroup.setCapability(TransformGroup.ALLOW_TRANSFORM_READ);
      eGroup.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);

      addChild(eGroup);
  }

}

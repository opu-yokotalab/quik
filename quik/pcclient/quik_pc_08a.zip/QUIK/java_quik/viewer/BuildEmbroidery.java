// �h�J��쐬�N���X
//  2000/02/16 Earsh
package java_quik.viewer;
import  java_quik.*;

import javax.media.j3d.*;
import javax.vecmath.*;
import com.sun.j3d.utils.geometry.Cylinder;

class BuildEmbroidery extends TransformGroup{

    public BuildEmbroidery(TransformGroup eGroup,Appearance app){
      TransformGroup poleLeft,poleRight,poleTop,rollerAxleGroup,roller1Group,roller2Group;
      Transform3D rollerAxleTrans = new Transform3D();
      Transform3D roller1Trans;
      Transform3D roller2Trans = new Transform3D();
      Transform3D tempTrans = new Transform3D(); 

      poleLeft = new BoxBuild(0.05f,0.7f,0.1f,-0.45,0.0,0.0,app);
      poleRight = new BoxBuild(0.05f,0.7f,0.1f,0.45,0.0,0.0,app);
      poleTop = new BoxBuild(0.5f,0.05f,0.1f,0.0,0.7,0.0,app);


      // ���[���[�̎�
      Cylinder rollerAxle = new Cylinder(0.03f,1.1f,Cylinder.GENERATE_NORMALS,app);
      tempTrans.rotZ(Math.PI/2);
      rollerAxleTrans.setTranslation(new Vector3d(0.0,-0.2,0.0));
      rollerAxleTrans.mul(tempTrans);    
      rollerAxleGroup = new TransformGroup(rollerAxleTrans);
      rollerAxleGroup.addChild(rollerAxle);

      // ���[���[��
      Cylinder roller1 = new Cylinder(0.1f,0.76f,Cylinder.GENERATE_NORMALS,app);
      roller1Trans = new Transform3D(rollerAxleTrans);
      roller1Group = new TransformGroup(roller1Trans);
      roller1Trans.setTranslation(new Vector3d(0.0,-0.2,0.0));
      roller1Group.setTransform(roller1Trans);
      roller1Group.addChild(roller1);

      // �t�b�N
      TransformGroup fukLeft1 = new BoxBuild(0.02f,0.07f,0.03f,-0.45,0.37,-0.2,app);
      TransformGroup fukLeft2 = new BoxBuild(0.02f,0.03f,0.07f,-0.45,0.31,-0.16,app);
      TransformGroup fukRight1 = new BoxBuild(0.02f,0.07f,0.03f,0.45,0.37,-0.2,app);
      TransformGroup fukRight2 = new BoxBuild(0.02f,0.03f,0.07f,0.45,0.31,-0.16,app);
    
      // ���[���[��
      Cylinder roller2 = new Cylinder(0.02f,1.1f,Cylinder.GENERATE_NORMALS,app);
      roller2Trans.setTranslation(new Vector3d(0.0,0.36,-0.12));
      roller2Trans.mul(tempTrans);
      roller2Group = new TransformGroup(roller2Trans);
      roller2Group.addChild(roller2);
    

      eGroup.addChild(poleLeft);
      eGroup.addChild(poleRight);
      eGroup.addChild(poleTop);
      eGroup.addChild(rollerAxleGroup);
      eGroup.addChild(roller1Group);
      eGroup.addChild(roller2Group);
      eGroup.addChild(fukLeft1);
      eGroup.addChild(fukLeft2);
      eGroup.addChild(fukRight1);
      eGroup.addChild(fukRight2);
  }

}


// ---- 3D�L�����o�X�̃p�l�� ------
//  2000/02/16 Earsh
package java_quik.viewer;
import  java_quik.*;

import java.awt.*;
import java.awt.event.*;
import javax.media.j3d.*;
import javax.vecmath.*;

public class VirtualWorldViewer extends Frame implements VirtualWorldControl {

    Canvas3D canvas;
    Stage1 stage1;
    //Stage2 stage2;
    //Stage3 stage3;
    VirtualUniverse universe;
    Locale locale;
    BranchGroup viewRoot;
    TransformGroup viewGroup;
    Transform3D viewTransform;

    VirtualWorldViewer(String title){
	super(title);

	universe = new VirtualUniverse();
	locale = new Locale(universe);

	BoundingSphere bounds = new BoundingSphere();
	bounds.setRadius(Double.POSITIVE_INFINITY);

	// �r���[
	View view = new View();
	ViewPlatform viewPlatform = new ViewPlatform();
	viewPlatform.setBounds(bounds);
	viewPlatform.setActivationRadius(1.0f);
	view.attachViewPlatform(viewPlatform);
	view.addCanvas3D(new Canvas3D(null));
	view.setPhysicalBody(new PhysicalBody());
	view.setPhysicalEnvironment(new PhysicalEnvironment());	

	viewGroup = new TransformGroup();
	viewGroup.setCapability(TransformGroup.ALLOW_TRANSFORM_READ);
	viewGroup.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
	viewTransform = new Transform3D();
	viewTransform.setTranslation(new Vector3d(0.0,1.7,3.0/Math.tan(Math.PI/8.0)));
	//viewTransform.lookAt(new Point3d(0.0,0.0,10.0),new Point3d(0.0,0.0,0.0),new Vector3d(0.0,1.0,0.0));
	viewGroup.setTransform(viewTransform);
	viewGroup.addChild(viewPlatform);

	viewRoot = new BranchGroup();
	viewRoot.addChild(viewGroup);


	
	canvas = view.getCanvas3D(0);
	canvas.setSize(500,300);

	setLayout(new BorderLayout());
	add(canvas,BorderLayout.CENTER);

	setSize(600,500);
	show();

    }

    public void setStage1(double x,double y,double z,Stage1 stage1){
	this.stage1 = stage1;
	stage1.setUpScene(canvas,x,y,z);
	locale.addBranchGraph(stage1);
	locale.addBranchGraph(viewRoot);
    }
    /*
    public void setStage2(double x,double y,double z,Stage2 stage2){
        this.stage2 = stage2;
	stage2.setUpScene(x,y,z);
	locale.addBranchGraph(stage2);
	locale.addBranchGraph(viewRoot);
    }

    public void setStage3(double x,double y,double z,Stage3 stage3){
        this.stage3 = stage3;
	stage3.setUpScene(x,y,z);
	locale.addBranchGraph(stage3);
	locale.addBranchGraph(viewRoot);
    }
    */
    public void closeStage(int sceneNumber){
	switch(sceneNumber){
	case 1:
	    stage1.detach();
	    break;
	case 2:
	    //    stage2.detach();
	    //    stage1 = null;
	    break;
	case 3:
	    //    stage3.detach();
	    //    stage2 = null;
	    break;
	default:
	    throw(new RuntimeException("Internal Error: got unknown type"));
	}
    }

    public void setUpPic(int onAirScene,double x,double y,double z,float scale,String name,Image image){
	int w = image.getWidth(this);
	int h = image.getHeight(this);
	double ratio = w/h;
	System.out.println("width:"+w+",height:"+h+",ratio:"+ratio);
	switch(onAirScene){
	case 1:
	    stage1.showUpPic(x,y,z,name,scale,ratio,image);
	    break;
	case 2:
	    //stage2.showUpPic(x,y,z,name,scale,ratio,image);
	    break;
	case 3:
	    //stage2.showUpPic(x,y,z,name,scale,ratio,image);
	    break;
	default:
	    throw(new RuntimeException("Internal Error: got unknown type"));
	}
    }

    public void setIllust(Image image,int onAirScene){
	Transform3D trans = new Transform3D();
	viewGroup.getTransform(trans);
	switch(onAirScene){
	case 1:
	    stage1.showIllust(image,trans);
	    break;
	case 2:
	    //stage2.showIllust(image,trans);
	    break;
	case 3:
	    //stage3.showIllust(image,trans);
	    break;
	default:
	    throw(new RuntimeException("Internal Error: got unknown type"));
	}
    }

}

	

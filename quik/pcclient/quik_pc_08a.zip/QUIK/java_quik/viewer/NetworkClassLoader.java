// ------ load class from local or network --------
//  2000/02/16 Earsh
package java_quik.viewer;
import  java_quik.*;

import java.net.*;
import java.io.*;

public class NetworkClassLoader extends ClassLoader {

    URL url;

    public NetworkClassLoader(URL url){
	this.url = url;
    }

    public synchronized Class loadClass(String name,boolean resolve) throws ClassNotFoundException {
	
	Class c = null;

	try{
	    c = findSystemClass(name);
	}catch(ClassNotFoundException e){
	    //		System.out.println("class file not found at local: " + e.getMessage());
	}

	if(c == null){
	    byte b[] = loadClassData(name);
	    try{
//                name = "java_quik.viewer." + name;
		c = defineClass(name,b,0,b.length);
	    }catch(ClassFormatError e){
		System.err.println("ClassFormatError: " + e.getMessage());
	    }
	}
	if(resolve){
	    resolveClass(c);
	}
	return c;
    }

    private byte[] loadClassData(String name) throws ClassNotFoundException {
	byte[] b;
	InputStream theClass = null;
	int bfr = 128;
	System.out.println(name + "," + url.toString() );
	try{
	    URL classURL = new URL(url,name + ".class");
	    URLConnection connect = classURL.openConnection();
	    connect.setAllowUserInteraction(false);

	    try{
		theClass = connect.getInputStream();
	    }catch(NullPointerException e){
		System.err.println("NullPointer: " + e.getMessage());
		throw new ClassNotFoundException(name + " input stream problem");
	    }
	    int cl = connect.getContentLength();
	    System.out.println("##" + cl);
	    if(cl == -1){
		b = new byte[bfr * 16];
	    }else{
		b = new byte[cl];
	    }

            System.out.println("cl:" + cl);

	    int bytesread = 1;
	    int offset = 0;
	    int d = 0;

	    while(bytesread > 0){
	    	bytesread = 0;
//		System.out.println("==" + offset + "==" + bfr);
		d = offset + bfr;
		if(cl < d && cl != -1){
		    bfr = cl - offset;
		}
		bytesread = theClass.read(b,offset,bfr);
//		if(bytesread < bfr) break;
		if(bytesread == 0) break;
		offset += bytesread;
		if(cl == -1 && offset == b.length){
		    byte temp[] = new byte[offset * 2];
		    System.arraycopy(b,0,temp,0,offset);
		    b = temp;
		}else if(offset > b.length){
		    throw new ClassNotFoundException(name + " error reading data into the array");
		}
	    }

	    if(offset < b.length){
		byte temp[] = new byte[offset];
		System.arraycopy(b,0,temp,0,offset);
		b = temp;
	    }

	    if(cl != -1 && offset != cl){
                System.out.println("offset:" + offset );
		throw new ClassNotFoundException("Only " + offset + " bytes received for " + name + " rsn Expected " + cl + " bytes");
	    }
	}catch(Exception e){
	    throw new ClassNotFoundException(name + " " + e);
	}finally{
	    try{
		if(theClass != null) theClass.close();
	    }catch(IOException e){
		System.err.println("IOException: " + e.getMessage());
	    }
	}
	return b;
    }

}


	

// ---------- Box�����ėp�N���X ------------
//  2000/02/16 Earsh
package java_quik.viewer;
import  java_quik.*;

import javax.media.j3d.*;
import javax.vecmath.*;
import com.sun.j3d.utils.geometry.Box;

public class BoxBuild extends TransformGroup{

  public BoxBuild(float xdim,float ydim,float zdim,
		  double x,double y,double z,Appearance appearance){
    Transform3D transform = new Transform3D();

    Box box = new Box(xdim,ydim,zdim,Box.GENERATE_NORMALS | Box.GENERATE_TEXTURE_COORDS,appearance);
    transform.setTranslation(new Vector3d(x,y,z));
    setTransform(transform);
    addChild(box);
  }

}

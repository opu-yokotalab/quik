// ------- �^���X�̍쐬 ---------
//  2000/02/16 Earsh
package java_quik.viewer;
import  java_quik.*;

import javax.media.j3d.*;
import javax.vecmath.*;

public class Shelf extends BranchGroup{

  public Shelf(double x,double y,double z){
    TransformGroup daiGroup = new TransformGroup();
    Transform3D boxTrans = new Transform3D();
    Transform3D rotation = new Transform3D();

    Appearance shelfApp = new Appearance();
    Material shelfmt = new Material( new Color3f(0.0f,0.0f,0.0f),
				     new Color3f(0.0f,0.0f,0.0f),
				     new Color3f(0.102f,0.051f,0.0f),
				     new Color3f(0.0f,0.0f,0.0f), 1.0f );
    shelfmt.setLightingEnable(true);
    shelfApp.setMaterial(shelfmt);

    // �^���X�쐬
    Shelfbase shelfbase = new Shelfbase(daiGroup,shelfApp);
    ShelfDrawer shelfdrawer = new ShelfDrawer(daiGroup,shelfApp);

    rotation.rotY(Math.PI/2);
    boxTrans.setTranslation(new Vector3d(x,y,z));
    boxTrans.mul(rotation);
    daiGroup.setTransform(boxTrans);
    addChild(daiGroup);


  }

}



    

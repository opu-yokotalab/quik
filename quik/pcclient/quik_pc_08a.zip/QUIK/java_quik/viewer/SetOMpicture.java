// ------- Set Frame Information of 0M_Picture ---------
//  2000/02/16 Earsh
package java_quik.viewer;
import  java_quik.*;

import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class SetOMpicture extends Frame implements ActionListener,InfoTranslation {

    Label label1,label2,label3;
    TextField url,point,scale;
    Button button;
//  2000/02/16  Earsh
//    OM_Picture om_picture;
    DM_Picture om_picture;
    SetOMpoint setompoint;

    public SetOMpicture(SetOMpoint setompoint){
	this.setompoint = setompoint;
	setLayout(new GridLayout(4,2));
	
	label1 = new Label("URL");
	label2 = new Label("point");
	label3 = new Label("scale");

	url = new TextField(20);
	point = new TextField(20);
	scale = new TextField(20);
	url.setText("http://alpha.c.oka-pu.ac.jp/~issei/bowie1.jpg");

	button = new Button("Set");
	button.addActionListener(this);

	add(label1);
	add(url);
	add(label2);
	add(point);
	add(label3);
	add(scale);
	add(button);

	setTitle("OM_Picture");
	setSize(250,200);
	show();
    }

    public void actionPerformed(ActionEvent event){
	String picurl = url.getText();
//  2000/02/16  Earsh
//	OM_Point op = setompoint.returnOM_Point();
	DM_Point op = setompoint.returnOM_Point();
	float s = Float.valueOf(scale.getText()).floatValue();

//  2000/02/16  Earsh
//	om_picture = new OM_Picture(picurl,op,s);
	om_picture = new DM_Picture();
	om_picture.url   = picurl;
	om_picture.point = op;
	om_picture.scale = s;
    }

//  2000/02/16  Earsh
//    public OM_Atom returnOM_Atom(){
    public DM_Atom returnOM_Atom(){
	return null;
    }

//  2000/02/16  Earsh
//    public OM_Media returnOM_Media(){
    public DM_Media returnOM_Media(){
	return null;
    }

//  2000/02/16  Earsh
//    public OM_Move returnOM_Move(){
    public DM_Move returnOM_Move(){
	return null;
    }
    
//  2000/02/16  Earsh
//    public OM_Object returnOM_Object(){
    public DM_Object returnOM_Object(){
	return null;
    }

//  2000/02/16  Earsh
//    public OM_Picture returnOM_Picture(){
    public DM_Picture returnOM_Picture(){
	return om_picture;
    }

//  2000/02/16  Earsh
//    public OM_Point returnOM_Point(){
    public DM_Point returnOM_Point(){
	return null;
    }

    public OM_Sound returnOM_Sound(){
	return null;
    }

    public OM_Utterance returnOM_Utterance(){
	return null;
    }

    public OM_Text returnOM_Text(){
	return null;
    }

    
}

// ------- �L�����Ƃ��ĉ摜��\��t�����{�[�h���쐬���� --------
//  2000/02/16 Earsh
package java_quik.viewer;
import  java_quik.*;

import java.awt.*;
import javax.media.j3d.*;
import javax.vecmath.*;
import com.sun.j3d.utils.image.TextureLoader;

public class MakeChara extends BranchGroup {

    TransformGroup transTG;
    TransformGroup scaleTG;

    public MakeChara(Canvas canvas,Image image,double x,double y,double z,float scale,double ratio){
	setCapability(BranchGroup.ALLOW_DETACH);
	setCapability(BranchGroup.ALLOW_CHILDREN_EXTEND);
	setCapability(BranchGroup.ALLOW_CHILDREN_WRITE);
	setCapability(BranchGroup.ALLOW_CHILDREN_READ);
	transTG = new TransformGroup();
	transTG.setCapability(TransformGroup.ALLOW_TRANSFORM_READ);
	transTG.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
	transTG.setCapability(TransformGroup.ALLOW_CHILDREN_EXTEND);
	transTG.setCapability(TransformGroup.ALLOW_CHILDREN_READ);
	transTG.setCapability(TransformGroup.ALLOW_CHILDREN_WRITE);
        scaleTG = new TransformGroup();
	scaleTG.setCapability(TransformGroup.ALLOW_TRANSFORM_READ);
	scaleTG.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
	scaleTG.setCapability(TransformGroup.ALLOW_CHILDREN_EXTEND);
	scaleTG.setCapability(TransformGroup.ALLOW_CHILDREN_READ);
	scaleTG.setCapability(TransformGroup.ALLOW_CHILDREN_WRITE);
	WakeupOnTransformChange wpic_1 = new WakeupOnTransformChange(transTG);
	WakeupOnTransformChange wpic_2 = new WakeupOnTransformChange(scaleTG);
	Transform3D scaleTrans = new Transform3D();
	Transform3D trans = new Transform3D();
	scaleTrans.setScale(scale);
	trans.setTranslation(new Vector3d(x,y,z));
	scaleTG.setTransform(scaleTrans);
	transTG.setTransform(trans);

	Texture texture = new TextureLoader(image,canvas).getTexture();
	Appearance appearance = new Appearance();
	appearance.setTexture(texture);
	
	double w = 1.0*ratio;
	System.out.println("w_length:"+w);
	Shape3D board = new Shape3D();
	Point3d[] coords = { new Point3d(-1.0,2.0,0.0),
			     new Point3d(-1.0,0.0,0.0),
			     new Point3d(1.0,0.0,0.0),
			     new Point3d(1.0,2.0,0.0) };
	Point2f[] texCoord = { new Point2f(0.0f,1.0f),
			       new Point2f(0.0f,0.0f),
			       new Point2f(1.0f,0.0f),
			       new Point2f(1.0f,1.0f) };
	QuadArray geom = new QuadArray(4,QuadArray.COORDINATES | QuadArray.NORMALS | QuadArray.TEXTURE_COORDINATE_2);
	geom.setCoordinates(0,coords);
	geom.setTextureCoordinate(0,texCoord[0]);
	geom.setTextureCoordinate(1,texCoord[1]);
	geom.setTextureCoordinate(2,texCoord[2]);
	geom.setTextureCoordinate(3,texCoord[3]);
	board.setGeometry(geom);
	board.setAppearance(appearance);

	scaleTG.addChild(board);
	transTG.addChild(scaleTG);
	addChild(transTG);
    }

}

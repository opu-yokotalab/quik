// -------- �f�o�b�O�p�r���[�A --------
//  2000/02/16 Earsh
package java_quik.viewer;
import  java_quik.*;

import java.awt.*;

public class DebugViewer extends Frame {

    MoveWayBoard mwboard;
    InfoPanel infopanel;

    public DebugViewer(DramaViewer dviewer){
	super("Debuger");
	setLayout(new BorderLayout());
        mwboard = new MoveWayBoard(dviewer);
	infopanel = new InfoPanel(dviewer,mwboard);
	add(mwboard,"Center");
	add(infopanel,"South");

	setSize(600,700);
	setVisible(true);
    }

}

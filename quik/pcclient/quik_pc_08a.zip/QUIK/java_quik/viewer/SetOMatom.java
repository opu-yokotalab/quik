// ------ Set Frame Information of OM_Atom ------
//  2000/02/16 Earsh
package java_quik.viewer;
import  java_quik.*;

import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class SetOMatom extends Frame implements ActionListener,InfoTranslation {

    Button button;
    Label label1,label2,label3,label4;
    TextField name,nextbucket,node,data;
//  2000/02/16  Earsh
//    OM_Atom om_atom;
    DM_Atom om_atom;

    public SetOMatom(){

	setLayout(new GridLayout(5,2));

	label1 = new Label("name");
	label2 = new Label("nextbucket");
	label3 = new Label("node");
	label4 = new Label("data");

	name = new TextField(20);
	nextbucket = new TextField(20);
	node = new TextField(20);
	data = new TextField(20);

	button = new Button("Set");
	button.addActionListener(this);

	add(label1);
	add(name);
	add(label2);
	add(nextbucket);
	add(label3);
	add(node);
	add(label4);
	add(data);
	add(button);

	setTitle("OM_Atom");
	setSize(250,300);
	show();
    }

    public void actionPerformed(ActionEvent event){
	String s = name.getText();
//  2000/02/16  Earsh
//	om_atom = new OM_Atom(s);
	om_atom = new DM_Atom();
	om_atom.name = s;
    }

//  2000/02/16  Earsh
//    public OM_Atom returnOM_Atom(){
    public DM_Atom returnOM_Atom(){
	return om_atom;
    }

//  2000/02/16  Earsh
//    public OM_Media returnOM_Media(){
    public DM_Media returnOM_Media(){
	return null;
    }

//  2000/02/16  Earsh
//    public OM_Move returnOM_Move(){
    public DM_Move returnOM_Move(){
	return null;
    }
    
//  2000/02/16  Earsh
//    public OM_Object returnOM_Object(){
    public DM_Object returnOM_Object(){
	return null;
    }
    
//  2000/02/16  Earsh
//    public OM_Picture returnOM_Picture(){
    public DM_Picture returnOM_Picture(){
	return null;
    }

//  2000/02/16  Earsh
//    public OM_Point returnOM_Point(){
    public DM_Point returnOM_Point(){
	return null;
    }

    public OM_Sound returnOM_Sound(){
	return null;
    }

    public OM_Utterance returnOM_Utterance(){
	return null;
    }

    public OM_Text returnOM_Text(){
	return null;
    }


}

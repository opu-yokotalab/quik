// ------- �h�A --------
//  2000/02/16 Earsh
package java_quik.viewer;
import  java_quik.*;

import javax.media.j3d.*;
import javax.vecmath.*;

public class Door extends TransformGroup {

    public Door(TransformGroup ldoorTG,TransformGroup rdoorTG){
	Appearance doorApp = new Appearance();
	Material material = new Material( new Color3f(0.0f,0.0f,0.0f),
					  new Color3f(0.0f,0.0f,0.0f),
					  new Color3f(0.102f,0.051f,0.0f),
					  new Color3f(0.0f,0.0f,0.0f),1.0f );
	material.setLightingEnable(true);
	doorApp.setMaterial(material);	

	// ����
	BoxBuild ldoor = new BoxBuild(0.05f,0.975f,0.45f,0.0,0.0,0.5,doorApp);
	ldoorTG.addChild(ldoor);
	TransformGroup ldoorTG_2 = new TransformGroup();
	Transform3D ldoorTrans = new Transform3D();
	ldoorTrans.setTranslation(new Vector3d(-2.65,0.95,-0.5));
	ldoorTG_2.setTransform(ldoorTrans);
	ldoorTG_2.addChild(ldoorTG);
	// ���̉�
	ldoorTG_2.addChild(new BoxBuild(0.1f,0.05f,0.7f,0.0,1.0,0.5,doorApp));
	ldoorTG_2.addChild(new BoxBuild(0.1f,0.98f,0.05f,0.0,0.0,1.0,doorApp));
	ldoorTG_2.addChild(new BoxBuild(0.1f,0.98f,0.05f,0.0,0.0,0.0,doorApp));
	// �����h�A�m�u
	BoxBuild lnob_1 = new BoxBuild(0.025f,0.3f,0.05f,0.1,0.0,0.3,doorApp);
	BoxBuild lnob_2 = new BoxBuild(0.025f,0.3f,0.05f,-0.1,0.0,0.3,doorApp); 
	ldoor.addChild(lnob_1);
	ldoor.addChild(lnob_2);
	addChild(ldoorTG_2);


	// �E��
	BoxBuild rdoor = new BoxBuild(0.05f,0.975f,0.45f,0.0,0.0,0.5,doorApp);
	rdoorTG.addChild(rdoor);
	TransformGroup rdoorTG_2 = new TransformGroup();
	Transform3D rdoorTrans = new Transform3D();
	rdoorTrans.setTranslation(new Vector3d(2.65,0.95,-0.5));
	rdoorTG_2.setTransform(rdoorTrans);
	rdoorTG_2.addChild(rdoorTG);
	// ���̉�
	rdoorTG_2.addChild(new BoxBuild(0.1f,0.05f,0.7f,0.0,1.0,0.5,doorApp));
	rdoorTG_2.addChild(new BoxBuild(0.1f,0.98f,0.05f,0.0,0.0,1.0,doorApp));
	rdoorTG_2.addChild(new BoxBuild(0.1f,0.98f,0.05f,0.0,0.0,0.0,doorApp));
	// �h�A�m�u
	BoxBuild rnob = new BoxBuild(0.025f,0.3f,0.05f,-0.1,0.0,0.3,doorApp);
	rdoor.addChild(rnob);
	addChild(rdoorTG_2);

    }

}

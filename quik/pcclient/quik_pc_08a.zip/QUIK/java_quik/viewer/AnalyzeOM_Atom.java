// ------ OM_Atom����� --------
//  2000/02/16 Earsh
package java_quik.viewer;
import  java_quik.*;

public class AnalyzeOM_Atom {

    String name;

//  2000/02/16  Earsh
//    public AnalyzeOM_Atom(OM_Atom target){
    public AnalyzeOM_Atom(DM_Atom target){
	name = target.name;
    }

    public String returnObjName(){
	return name;
    }

}

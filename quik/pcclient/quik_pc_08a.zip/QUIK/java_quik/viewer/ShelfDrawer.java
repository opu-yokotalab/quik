// --------- �^���X�̈����o�������N���X -----------
//  2000/02/16 Earsh
package java_quik.viewer;
import  java_quik.*;

import javax.media.j3d.*;
import javax.vecmath.*;

class ShelfDrawer{

  ShelfDrawer(TransformGroup daiGroup,Appearance appearance){

    BranchGroup drawer1,drawer2,drawer3;

    // �����o���쐬
    drawer1 = drawerBuild(0.5f,0.08f,0.23f,0.0,0.29,0.04,appearance);
    drawer2 = drawerBuild(0.5f,0.10f,0.23f,0.0,0.10,0.04,appearance);
    drawer3 = drawerBuild(0.5f,0.10f,0.23f,0.0,-0.11,0.04,appearance);

    drawer1.setCapability(BranchGroup.ENABLE_PICK_REPORTING);
    drawer2.setCapability(BranchGroup.ENABLE_PICK_REPORTING);
    drawer3.setCapability(BranchGroup.ENABLE_PICK_REPORTING);

    daiGroup.addChild(drawer1);
    daiGroup.addChild(drawer2);
    daiGroup.addChild(drawer3);


  }

  BranchGroup drawerBuild(float xdim,float ydim,float zdim,
			     double x,double y,double z,Appearance appearance){
      TransformGroup nobLeft,nobRight,part1,part2,part3,part4,part5;
      BranchGroup temp = new BranchGroup();

    part1 = new BoxBuild(xdim,0.01f,zdim,x,y-0.07,z,appearance);
    part2 = new BoxBuild(xdim,ydim,0.01f,x,y,z+0.22,appearance);
    part3 = new BoxBuild(xdim,ydim,0.01f,x,y,z-0.22,appearance);
    part4 = new BoxBuild(0.01f,ydim,zdim,-0.49,y,z,appearance);
    part5 = new BoxBuild(0.01f,ydim,zdim,0.49,y,z,appearance);

    temp.addChild(part1);
    temp.addChild(part2);
    temp.addChild(part3);
    temp.addChild(part4);
    temp.addChild(part5);

    nobLeft = new BoxBuild(0.02f,0.02f,0.02f,0.30,y,0.275,appearance);
    nobRight = new BoxBuild(0.02f,0.02f,0.02f,-0.30,y,0.275,appearance);

    nobLeft.setCapability(TransformGroup.ALLOW_TRANSFORM_READ);
    nobLeft.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
    nobRight.setCapability(TransformGroup.ALLOW_TRANSFORM_READ);
    nobRight.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
    
    temp.addChild(nobLeft);
    temp.addChild(nobRight);
    
    return temp;
  }

}

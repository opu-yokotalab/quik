// ------ OM_Move����� --------
//  2000/02/16 Earsh
package java_quik.viewer;
import  java_quik.*;

public class AnalyzeOM_Move {

    String name;
    int num = 0;
    float[] xyzpoint = new float[3];
    float[] xpoints = new float[1000];
    float[] ypoints = new float[1000];
    float[] zpoints = new float[1000];    
    
    AnalyzeOM_Atom ana_omatom;
//    OM_Point om_point;
    DM_Point om_point;
    AnalyzeOM_Point ana_ompoint;
  
//  2000/02/16 Earsh
//    public AnalyzeOM_Move(OM_Move target,int command){
    public AnalyzeOM_Move(DM_Move target,int command){

	ana_omatom = new AnalyzeOM_Atom(target.obj);
	name = ana_omatom.returnObjName();
	
	float[] temp = new float[3];
	om_point = target.point;
	if(command == 4){
	    while(om_point.next != null){
		om_point = om_point.next;
	    }
	    ana_ompoint = new AnalyzeOM_Point(om_point);
	    xyzpoint = ana_ompoint.returnPoints();
	}else {	    
	    do{
		ana_ompoint = new AnalyzeOM_Point(om_point);
		temp = ana_ompoint.returnPoints();
		xpoints[num] = temp[0];
		ypoints[num] = temp[1];
		zpoints[num] = temp[2];
		om_point = om_point.next;
		num++;
	    }while(om_point != null);
	}
    }

    public String returnTarget(){
	return name;
    }

    public int returnPointsNum(){
	return num;
    }

    public float[] returnXpoints(){
	return xpoints;
    }

    public float[] returnYpoints(){
	return ypoints;
    }

    public float[] returnZpoints(){
	return zpoints;
    }

}

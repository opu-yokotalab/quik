// ------ Interface for 
//             OM_Atom,OM_Media,OM_Move,OM_Object,OM_Picture,OM_Point ------
//  2000/02/16 Earsh
package java_quik.viewer;
import  java_quik.*;

public interface InfoTranslation {

//  2000/02/16  Earsh
//    public OM_Atom returnOM_Atom();
    public DM_Atom returnOM_Atom();

//  2000/02/16  Earsh
//    public OM_Media returnOM_Media();
    public DM_Media returnOM_Media();

//  2000/02/16  Earsh
//    public OM_Move returnOM_Move();
    public DM_Move returnOM_Move();
    
//  2000/02/16  Earsh
//    public OM_Object returnOM_Object();
    public DM_Object returnOM_Object();
    
//  2000/02/16  Earsh
//    public OM_Picture returnOM_Picture();
    public DM_Picture returnOM_Picture();

//  2000/02/16  Earsh
//    public OM_Point returnOM_Point();
    public DM_Point returnOM_Point();

    public OM_Sound returnOM_Sound();
    
    public OM_Utterance returnOM_Utterance();

    public OM_Text returnOM_Text();

}

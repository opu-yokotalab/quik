// ------- 
//  2000/02/16 Earsh
package java_quik.viewer;
import  java_quik.*;

import java.util.Hashtable;
import java.awt.*;
import javax.media.j3d.*;

public interface PositionControl {

    public void move(String name,int index,float[] xpoints,float[] ypoints,float[] zpoints,Hashtable cacheX,Hashtable cacheY,Hashtable cacheZ,Timer timer);

    public void moveForWrite(String name,int index,double scale,double[] xpoints,double[] ypoints,double[] zpoints);

    public void moveForSave(String name,int index,float[] xpoints,float[] ypoints,float[] zpoints);

    public void resetPosition(String target,double x,double y,double z);

    public void setUpScene(Canvas canvas,double x,double y,double z);

    public void showUpObj(double x,double y,double z,String name,TransformGroup objTG);

    public void showUpPic(double x,double y,double z,String name,float scale,double ratio,Image image);

    public void showIllust(Image image,Transform3D viewTrans);

    public void changeState(double x,double y,double z,String name);

    //public void changeState(double x,double y,double z,float scale,String name);

    public void removeObj(String name);

    public void removePic(String name);

    public void openDoor(int side);

}

// ------- Set Frame Information of 0M_Sound ---------
//  2000/02/16 Earsh
package java_quik.viewer;
import  java_quik.*;

import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class SetOMtext extends Frame implements ActionListener,InfoTranslation {
    
    Label label1,label2,label3,label4,label5,label6;
    TextField str,font,scale,r,g,b;
    Button button;
    OM_Text om_text;
    
    public SetOMtext(){
	setLayout(new GridLayout(7,2));
	
	label1 = new Label("str");
	label2 = new Label("font");
	label3 = new Label("scale");
	label4 = new Label("r");
	label5 = new Label("g");
	label6 = new Label("b");
	str = new TextField(10);
	font = new TextField(10);
	scale = new TextField(10);
	r = new TextField(10);
	g = new TextField(10);
	b = new TextField(10);
	button = new Button("Set");
	button.addActionListener(this);

	add(label1);
	add(str);
	add(label2);
	add(font);
	add(label3);
	add(scale);
	add(label4);
	add(r);
	add(label5);
	add(g);
	add(label6);
	add(b);
	add(button);
	
	setTitle("OM_Text");
	setSize(100,100);
	show();
    }

    public void actionPerformed(ActionEvent event){
	String strstring = str.getText();
	String fontstring = font.getText();
	int s = Integer.parseInt(scale.getText());
	float rv = Float.parseFloat(r.getText());
	float gv = Float.parseFloat(g.getText());
	float bv = Float.parseFloat(b.getText());
	om_text = new OM_Text(strstring,fontstring,s,rv,gv,bv);
    }

 
//  2000/02/16  Earsh
//    public OM_Atom returnOM_Atom(){
    public DM_Atom returnOM_Atom(){
	return null;
    }

//  2000/02/16  Earsh
//    public OM_Media returnOM_Media(){
    public DM_Media returnOM_Media(){
	return null;
    }

//  2000/02/16  Earsh
//    public OM_Move returnOM_Move(){
    public DM_Move returnOM_Move(){
	return null;
    }
    
//  2000/02/16  Earsh
//    public OM_Object returnOM_Object(){
    public DM_Object returnOM_Object(){
	return null;
    }
    
//  2000/02/16  Earsh
//    public OM_Picture returnOM_Picture(){
    public DM_Picture returnOM_Picture(){
	return null;
    }

//  2000/02/16  Earsh
//    public OM_Point returnOM_Point(){
    public DM_Point returnOM_Point(){
	return null;
    }

    public OM_Sound returnOM_Sound(){
	return null;
    }

    public OM_Utterance returnOM_Utterance(){
	return null;
    }

    public OM_Text returnOM_Text(){
	return om_text;
    }
    
}
   

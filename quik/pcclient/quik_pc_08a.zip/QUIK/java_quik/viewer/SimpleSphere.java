// ------- just a simple sphere ------
//  2000/02/16 Earsh
package java_quik.viewer;
import  java_quik.*;

import javax.media.j3d.*;
import javax.vecmath.*;
import com.sun.j3d.utils.geometry.Sphere;

public class SimpleSphere extends TransformGroup{


    public SimpleSphere(){
	setCapability(TransformGroup.ALLOW_TRANSFORM_READ);
	setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
	setCapability(TransformGroup.ALLOW_CHILDREN_EXTEND);
	setCapability(TransformGroup.ALLOW_CHILDREN_READ);
	setCapability(TransformGroup.ALLOW_CHILDREN_WRITE);
	WakeupOnTransformChange wsphereTrans = new WakeupOnTransformChange(this);

	Appearance sphereApp = new Appearance();
	Material spheremt = new Material( new Color3f(0.2f,0.2f,0.2f),
					   new Color3f(0.0f,0.0f,0.0f),
					   new Color3f(0.2f,0.0f,0.2f),
					   new Color3f(0.5f,0.5f,0.5f),30);
	spheremt.setLightingEnable(true);
	sphereApp.setMaterial(spheremt);
	Sphere sphere = new Sphere(0.1f,sphereApp);
	addChild(sphere);
    }

}

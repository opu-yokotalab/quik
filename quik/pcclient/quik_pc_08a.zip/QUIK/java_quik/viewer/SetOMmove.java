// ------ Set Frame Information of OM_Move ------
//  2000/02/16 Earsh
package java_quik.viewer;
import  java_quik.*;

import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class SetOMmove extends Frame implements ActionListener,InfoTranslation {

    Button button;
    Label label1,label2,label3;
    TextField type,atom,ompoint;
//  2000/02/16  Earsh
//    OM_Move om_move;
    DM_Move om_move;
    SetOMatom setomatom;
    SetOMpoint setompoint;

    public SetOMmove(SetOMatom setomatom,SetOMpoint setompoint){
	this.setomatom = setomatom;
	this.setompoint = setompoint;
	setLayout(new GridLayout(4,2));
	
	label1 = new Label("type");
	label2 = new Label("OM_Atom");
	label3 = new Label("OM_Point");

	type = new TextField(20);
	atom = new TextField(20);
	ompoint = new TextField(20);

	button = new Button("Set");
	button.addActionListener(this);

	add(label1);
	add(type);
	add(label2);
	add(atom);
	add(label3);
	add(ompoint);
	add(button);


	setTitle("OM_Move");
	setSize(250,200);
	show();
    }

    public void actionPerformed(ActionEvent event){
	int t = Integer.parseInt(type.getText());
//  2000/02/16  Earsh
//	OM_Atom om_atom = setomatom.returnOM_Atom();
	DM_Atom om_atom = setomatom.returnOM_Atom();
//  2000/02/16  Earsh
//	OM_Point om_point = setompoint.returnOM_Point();
	DM_Point om_point = setompoint.returnOM_Point();
//  2000/02/16  Earsh
//	om_move = new OM_Move(t,om_atom,om_point);
	om_move = new DM_Move();
	om_move.type  = t;
	om_move.obj   = om_atom;
	om_move.point = om_point;
    }

//  2000/02/16  Earsh
//    public OM_Atom returnOM_Atom(){
    public DM_Atom returnOM_Atom(){
	return null;
    }

//  2000/02/16  Earsh
//    public OM_Media returnOM_Media(){
    public DM_Media returnOM_Media(){
	return null;
    }

//  2000/02/16  Earsh
//    public OM_Move returnOM_Move(){
    public DM_Move returnOM_Move(){
	return om_move;
    }
    
//  2000/02/16  Earsh
//    public OM_Object returnOM_Object(){
    public DM_Object returnOM_Object(){
	return null;
    }
    
//  2000/02/16  Earsh
//    public OM_Picture returnOM_Picture(){
    public DM_Picture returnOM_Picture(){
	return null;
    }

//  2000/02/16  Earsh
//    public OM_Point returnOM_Point(){
    public DM_Point returnOM_Point(){
	return null;
    }

    public OM_Sound returnOM_Sound(){
	return null;
    }

    public OM_Utterance returnOM_Utterance(){
	return null;
    }

    public OM_Text returnOM_Text(){
	return null;
    }

}

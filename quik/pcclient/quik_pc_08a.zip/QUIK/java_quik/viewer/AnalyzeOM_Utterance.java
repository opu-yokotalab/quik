// -------- OM_Utterance����� ----------
//  2000/02/16 Earsh
package java_quik.viewer;
import  java_quik.*;

public class AnalyzeOM_Utterance {

    String str;
    String font;
//  2000/02/16 Earsh
/**
    int loudness;
    int pitch;
*/
    float loudness;
    float pitch;

    public AnalyzeOM_Utterance(OM_Utterance target){
	str = target.str;
	font = target.font;
	loudness = target.loudness;
	pitch = target.pitch;
    }

    public String returnString(){
	return str;
    }
    
    public String returnFont(){
	return font;
    }

    public float returnLoudness(){
	return loudness;
    }

    public float returnPitch(){
	return pitch;
    }

}

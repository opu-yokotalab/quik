// 
//  2000/02/16 Earsh
package java_quik.viewer;
import  java_quik.*;

import java.awt.Image;
import javax.media.j3d.*;

public interface VirtualWorldControl {

    public void setStage1(double x,double y,double z,Stage1 stage1);

    //    public void setStage2(double x,double y,double z,Stage2 stage2);

    //    public void setStage3(double x,double y,double z,Stage3 stage3);

    public void closeStage(int sceneNumber);

    public void setUpPic(int onAirScene,double x,double y,double z,float scale,String name,Image image);

    public void setIllust(Image image,int onAirScene);

}

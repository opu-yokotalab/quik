// ------- �I�u�W�F�N�g����͂��� --------
//  2000/02/16 Earsh
package java_quik.viewer;
import  java_quik.*;

import java.awt.*;
import java.util.Hashtable;

public class AnalyzeOM_Media {

    Class objclass;
    int thisAction, play_time, synchro_time, pointsNum;
    private int PIC = 1;
    private int OBJ = 3;
    private int TEXT = 4;
    private int MOVE = 5;
    private int SOUND = 6;
    private int UTTERANCE = 7;
    float scale, tscale, loudness, pitch;
    float[] xyzPoint,xpoints,ypoints,zpoints,rgbValues;
    String mediaName,targetName,url,fileName,str,font;
    Image image;
    
    boolean picFlag = false;
    boolean objFlag = false;
    boolean moveFlag = false;

    AnalyzeOM_Picture om_picture;
    AnalyzeOM_Object om_object;
    AnalyzeOM_Move om_move;

//  2000/02/16 Earsh
//    public AnalyzeOM_Media(OM_Media target,int command,Hashtable objcache,Hashtable imagecache) {
    public AnalyzeOM_Media(DM_Media target,int command,Hashtable objcache,Hashtable imagecache) {

	this.play_time = target.play_time;
	this.synchro_time = target.synchro_time;
//  2000/02/16  Earsh
//	mediaName = target.name;
	mediaName = target.atom.name;

	switch(target.type){
	case 1:
	    // �Î~��
	    xyzPoint = new float[3];
	    om_picture = new AnalyzeOM_Picture(target.picture,imagecache);
	    url = om_picture.returnURL();
	    fileName = om_picture.returnFileName();
	    image = om_picture.returnImage();
	    xyzPoint = om_picture.returnXYZpoint();
	    scale = om_picture.returnScale();
	    thisAction = PIC;
	    break;
	case 3:
	    // �I�u�W�F�N�g
	    xyzPoint = new float[3];
	    om_object = new AnalyzeOM_Object(target.object,objcache);
	    url = om_object.returnURL();
	    fileName = om_object.returnFileName();
	    objclass = om_object.returnObjClass();
	    xyzPoint = om_object.returnXYZpoint();
	    thisAction = OBJ;
	    break;
	case 4:
	    // �e�L�X�g
	    str = target.text.str;
	    font = target.text.font;
	    tscale = target.text.scale;
	    rgbValues = new float[3];
	    rgbValues[0] = target.text.r;
	    rgbValues[1] = target.text.g;
	    rgbValues[2] = target.text.b;
	    thisAction = TEXT;
	    break;
	case 5:
	    // �ړ�
	    if(command == 4){
		xyzPoint = new float[3];
	    }else{
		xpoints = new float[1000];
		ypoints = new float[1000];
		zpoints = new float[1000];
	    }
	    om_move = new AnalyzeOM_Move(target.move,command);
	    targetName = om_move.returnTarget();
	    if(command == 4){
		xyzPoint = om_move.xyzpoint;
	    }else{
		pointsNum = om_move.returnPointsNum();
		xpoints = om_move.returnXpoints();
		ypoints = om_move.returnYpoints();
		zpoints = om_move.returnZpoints();
	    }    
	    thisAction = MOVE;
	    break;
	case 6:
	    // �T�E���h
	    url = target.sound.url;
	    fileName = url.substring(url.lastIndexOf("/")+1,url.length());
	    thisAction = SOUND;
	    break;
	case 7:
	    // ���b
	    str = target.utterance.str;
	    font = target.utterance.font;
	    loudness = target.utterance.loudness;
	    pitch = target.utterance.pitch;
	    thisAction = UTTERANCE;
	    break;
	default:
	    throw(new RuntimeException("Internal Error: got unknown type"));
	}
    }

    public int returnThisAction(){
	return thisAction;
    }

    public int returnPlay_Time(){
	return play_time;
    }

    public int returnSynchro_Time(){
	return synchro_time;
    }

    public float returnLoudness(){
	return loudness;
    }
    
    public float returnPitch(){
	return pitch;
    }

    public float returnTextScale(){
	return tscale;
    }

    public Image returnImage(){
	return image;
    }

    public float returnScale(){
	return scale;
    }

    public float[] returnXYZPoint(){
	return xyzPoint;
    }

    public Class returnObjClass(){
	return objclass;
    }

    public String returnMediaName(){
	return mediaName;
    }

    public String returnString(){
	return str;
    }

    public String returnFont(){
	return font;
    }

    public String returnTargetName(){
	return targetName;
    }

    public String returnURL(){
	return url;
    }
    
    public String returnFileName(){
	return fileName;
    }

    public int returnPointsNum(){
	return pointsNum;
    }

    public float[] returnRGBValues(){
	return rgbValues;
    }

    public float[] returnXPoints(){
	return xpoints;
    }

    public float[] returnYPoints(){
	return ypoints;
    }

    public float[] returnZPoints(){
	return zpoints;
    }

}

	    

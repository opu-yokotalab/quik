// --------- ����C�x���g���s���X���b�h -----------
//  2000/02/16 Earsh
package java_quik.viewer;
import  java_quik.*;

import java.util.Hashtable;
import javax.media.j3d.*;
import javax.vecmath.*;

class MoveThread extends Thread {

    TransformGroup targetTG;
    int index;
    String name;
    double x1,y1,z1,xd,yd,zd;
    float[] xpoints,ypoints,zpoints;
    Timer timer;
    Hashtable cacheX,cacheY,cacheZ;

    public MoveThread(String name,TransformGroup transGroup,int index,float[] xpoints,float[] ypoints,float[] zpoints,Hashtable cacheX,Hashtable cacheY,Hashtable cacheZ,Timer timer){
	targetTG = transGroup;
	this.name = name;
	this.index = index;
	this.xpoints = xpoints;
	this.ypoints = ypoints;
	this.zpoints = zpoints;
	this.cacheX = cacheX;
	this.cacheY = cacheY;
	this.cacheZ = cacheZ;
	this.timer = timer;
	start();
    }

    public void run(){
	Transform3D trans = new Transform3D();
	for(int i=0; i<index-1 && !timer.playEnd ; i++){
	    x1 = (double)xpoints[i];
	    y1 = (double)ypoints[i];
	    z1 = (double)zpoints[i];
	    double x2 = (double)xpoints[i+1];
	    double y2 = (double)ypoints[i+1];
	    double z2 = (double)zpoints[i+1];
	    xd = (x2 - x1)/8;
	    yd = (y2 - y1)/8;
	    zd = (z2 - z1)/8;
	    for(int j=0; j<9 ; j++){
		System.out.println("x=" + x1 + ",y=" + ypoints[i] + ",z=" +z1);
//		trans.setTranslation(new Vector3d(x1,(double)ypoints[i],z1));
		trans.setTranslation(new Vector3d(x1,y1,z1));
		targetTG.setTransform(trans);
		x1 = x1+xd;
		y1 = y1+yd;
		z1 = z1+zd;
		try{
		    sleep(1);
		}catch(InterruptedException e){
		    System.out.println("Interrupted!!");
		}
		this.yield();
	    }
	}	
	cacheX.remove(name);
	cacheY.remove(name);
	cacheZ.remove(name);
	cacheX.put(name,new Float(x1-xd));
//	cacheY.put(name,new Float(0.0));
	cacheY.put(name,new Float(y1-yd));
	cacheZ.put(name,new Float(z1-zd));
	System.out.println("X:" + ((Float)cacheX.get(name)).floatValue()+"!");
	System.out.println("Y:" + ((Float)cacheY.get(name)).floatValue()+"!");
	System.out.println("Z:" + ((Float)cacheZ.get(name)).floatValue()+"!");
    }

}


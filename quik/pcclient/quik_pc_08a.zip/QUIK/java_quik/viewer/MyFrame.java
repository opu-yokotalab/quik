// ------ �}�G�̂��߂̃r���[�A -----
//  2000/02/16 Earsh
package java_quik.viewer;
import  java_quik.*;

import java.awt.*;

public class MyFrame extends Frame {

    public MyFrame(Image image,String name){
	setTitle(name);
	add(new PicPreview(image));
	setSize(300,300);
	setVisible(true);
    }

}

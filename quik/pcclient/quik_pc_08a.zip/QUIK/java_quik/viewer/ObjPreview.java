// ------ ���̂̎��ʗp���z���E -------
//  2000/02/16 Earsh
package java_quik.viewer;
import  java_quik.*;

import java.awt.Canvas;
import javax.media.j3d.*;
import javax.vecmath.*;

public class ObjPreview {

    View view;

    public ObjPreview(TransformGroup targetTG){
	VirtualUniverse universe = new VirtualUniverse();
	Locale locale = new Locale(universe);
	BranchGroup rootBG = new BranchGroup();
	
	// �e���͈�
	BoundingSphere bounds = new BoundingSphere();
	bounds.setRadius(20.0);

	// ���C�g
	PointLight light = new PointLight( new Color3f(1.0f,1.0f,1.0f),
					   new Point3f(0.0f,1.0f,1.0f),
					   new Point3f(0.0f,0.0f,0.0f) );
	rootBG.addChild(light);
	light.setInfluencingBounds(bounds);

	// ��]�^����`
	Alpha alpha = new Alpha();
	alpha.setIncreasingAlphaDuration(8000L);
	Transform3D axis = new Transform3D();
	RotationInterpolator rotator = new RotationInterpolator(alpha,targetTG,axis,0.0f,(float)(Math.PI*2.0));
	rotator.setSchedulingBounds(bounds);
	targetTG.addChild(rotator);
	rootBG.addChild(targetTG);
	locale.addBranchGraph(rootBG);

	// �I�u�U�[�o
	view = new View();
	ViewPlatform viewPlatform = new ViewPlatform();
	view.attachViewPlatform(viewPlatform);
	view.addCanvas3D(new Canvas3D(null));
	view.setPhysicalBody(new PhysicalBody());
	view.setPhysicalEnvironment(new PhysicalEnvironment());

	TransformGroup viewGroup = new TransformGroup();
	Transform3D viewTransform = new Transform3D();
	viewTransform.setTranslation(new Vector3d(0.0,0.0,1.0/Math.tan(Math.PI/8.0)));
	viewGroup.setTransform(viewTransform);
	viewGroup.addChild(viewPlatform);

	BranchGroup viewRoot = new BranchGroup();
	viewRoot.addChild(viewGroup);
	locale.addBranchGraph(viewRoot);
    }

    public Canvas returnCanvas(){
	Canvas canvas = view.getCanvas3D(0);
	return canvas;
    }

}

// -------- �֎q�̍쐬 ----------
//  2000/02/16 Earsh
package java_quik.viewer;
import  java_quik.*;

import javax.media.j3d.*;
import javax.vecmath.*;
import com.sun.j3d.utils.geometry.*;

public class Chair extends BranchGroup{

  public Chair(double x,double y,double z){
    TransformGroup chairTG = new TransformGroup();
    Transform3D chairTrans = new Transform3D();
    Transform3D rotation = new Transform3D();

    // �֎q�쐬
    BuildChair(chairTG);

    rotation.rotY(Math.PI/3);
    chairTrans.setTranslation(new Vector3d(x,y,z));
    chairTrans.mul(rotation);
    chairTG.setTransform(chairTrans);

    addChild(chairTG);

  }

  void  BuildChair(TransformGroup chairTG){
    TransformGroup footFrontLeft,footFrontRight,footBackLeft,footBackRight,backBoard,stick,sitBoard,leftArm_1,leftArm_2,leftArm_3,rightArm_1,rightArm_2,rightArm_3;
    double p=0.06;

    Appearance appearance = new Appearance();
    Material material = new Material( new Color3f(0.0f,0.0f,0.0f),
                                      new Color3f(0.0f,0.0f,0.0f),
                                      new Color3f(0.102f,0.051f,0.00f),
                                      new Color3f(0.0f,0.0f,0.0f), 1.0f );
    material.setLightingEnable(true);
    appearance.setMaterial(material);
    
    footBackLeft = new BoxBuild(0.03f,0.7f,0.03f,0.0,0.0,0.0,appearance);
    footBackRight = new BoxBuild(0.03f,0.7f,0.03f,0.36,0.0,0.0,appearance);
    footFrontLeft = new BoxBuild(0.03f,0.17f,0.03f,0.015,-0.535,0.25,appearance);
    footFrontRight = new BoxBuild(0.03f,0.17f,0.03f,0.34,-0.535,0.25,appearance);
    backBoard = new BoxBuild(0.18f,0.08f,0.02f,0.17,0.58,0.0,appearance);
    for(int i=0;i<7;i++){
      stick = new BoxBuild(0.01f,0.45f,0.01f,p,0.08,0.0,appearance);
      chairTG.addChild(stick);
      p+=0.04;
    }
    sitBoard = new BoxBuild(0.2f,0.03f,0.16f,0.18,-0.38,0.145,appearance);
    leftArm_1 = new BoxBuild(0.03f,0.015f,0.12f,0.0,-0.2,0.13,appearance);
    leftArm_2 = new BoxBuild(0.015f,0.1f,0.015f,0.0,-0.3,0.24,appearance);
    rightArm_1 = new BoxBuild(0.03f,0.015f,0.12f,0.36,-0.2,0.13,appearance);
    rightArm_2 = new BoxBuild(0.015f,0.1f,0.015f,0.36,-0.3,0.25,appearance);
    leftArm_3 = new TransformGroup();
    Box larm = new Box(0.03f,0.015f,0.03f,Box.GENERATE_NORMALS | Box.GENERATE_TEXTURE_COORDS,appearance);
    leftArm_3.addChild(larm);
    Transform3D lrot = new Transform3D();
    lrot.rotX(-Math.PI/10);
    Transform3D larmTrans = new Transform3D();
    larmTrans.setTranslation(new Vector3d(0.0,-0.191,0.275));
    larmTrans.mul(lrot);
    leftArm_3.setTransform(larmTrans);
    rightArm_3 = new TransformGroup();
    Box rarm = new Box(0.03f,0.015f,0.03f,Box.GENERATE_NORMALS | Box.GENERATE_TEXTURE_COORDS,appearance);
    rightArm_3.addChild(rarm);
    Transform3D rrot = new Transform3D();
    rrot.rotX(-Math.PI/10);
    Transform3D rarmTrans = new Transform3D();
    rarmTrans.setTranslation(new Vector3d(0.36,-0.191,0.275));
    rarmTrans.mul(rrot);
    rightArm_3.setTransform(rarmTrans);

    TransformGroup sphereLgroup = new TransformGroup(),
                   sphereRgroup = new TransformGroup();
    Transform3D sphereLtrans = new Transform3D(),
                sphereRtrans = new Transform3D();

    Sphere sphereLeft = new Sphere(0.03f);
    Sphere sphereRight = new Sphere(0.03f);
    sphereLeft.setAppearance(appearance);
    sphereRight.setAppearance(appearance);
    sphereLtrans.setTranslation(new Vector3d(0.0,0.72,0.0));
    sphereRtrans.setTranslation(new Vector3d(0.36,0.72,0.0));
    sphereLgroup.addChild(sphereLeft);
    sphereRgroup.addChild(sphereRight);
    sphereLgroup.setTransform(sphereLtrans);
    sphereRgroup.setTransform(sphereRtrans);
    chairTG.addChild(sphereLgroup);
    chairTG.addChild(sphereRgroup);
    

    chairTG.addChild(footBackLeft);
    chairTG.addChild(footBackRight);
    chairTG.addChild(footFrontLeft);
    chairTG.addChild(footFrontRight);
    chairTG.addChild(backBoard);
    chairTG.addChild(sitBoard);
    chairTG.addChild(leftArm_1);
    chairTG.addChild(leftArm_2);
    chairTG.addChild(leftArm_3);
    chairTG.addChild(rightArm_1);
    chairTG.addChild(rightArm_2);
    chairTG.addChild(rightArm_3);

  }
    

}

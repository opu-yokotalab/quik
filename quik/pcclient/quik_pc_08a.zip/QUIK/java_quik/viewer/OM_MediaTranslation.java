// --------- MotionWriter3D's Interface ----------
//  2000/02/16 Earsh
package java_quik.viewer;
import  java_quik.*;

public interface OM_MediaTranslation {

    public void translateObj(OM_Media actionData);

}

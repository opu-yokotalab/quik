// ------- �ړ����H�`��p�l�� ---------
//  2000/02/16 Earsh
package java_quik.viewer;
import  java_quik.*;

import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class MoveWayBoard extends Panel implements ActionListener,ItemListener,MouseListener,MouseMotionListener,MWBControl {

    Button play_button,reset_button,save_button;
    Choice scale_button;
    TextField text;
    Canvas canvas;
    Panel panel1,panel2;
    Point ptStart,ptEnd;
    Point pts[] = new Point[1000];
    int ptindex = 0,onAirScene;
    double scale = 4,time;
    float[] xpoints,ypoints,zpoints;
    Rectangle position,tempRec;
    Stage1 stage1;
    //Stage2 stage2;
    //Stage3 stage3;

    Hashtable pcache = new Hashtable();
    Hashtable mapcache = new Hashtable();
    Enumeration enum;
    String target;
    
    DramaViewer dviewer;
    DebugViewer dbugviewer;
    InfoPanel infopanel;
    PointsViewer pviewer;
    
    boolean setUpFlag = false;
    boolean initFlag = false;
    boolean playFlag = false;
    boolean resetFlag = false;
    boolean saveFlag = false;
    boolean dragFlag = false;
    boolean active = false;
    boolean drawFlag = false;


    public MoveWayBoard(DramaViewer dviewer){
	this.dviewer = dviewer;

	setLayout(new BorderLayout());

	panel1 = new Panel();
	panel1.setBackground(Color.gray);
	panel1.setLayout(new FlowLayout(FlowLayout.CENTER));
	canvas = new Canvas();
        canvas.setSize(500,400);
	canvas.setBackground(new Color(0,127,0));
	canvas.addMouseListener(this);
	canvas.addMouseMotionListener(this);
	panel1.add(canvas);
	add("Center",panel1);

	panel2 = new Panel();
	panel2.setSize(300,200);
	panel2.setBackground(Color.gray);
 
	play_button = new Button("�v���r���[");
	play_button.addActionListener(this);
	reset_button = new Button("���Z�b�g");
	reset_button.addActionListener(this);
	save_button = new Button("Save Road");
	save_button.addActionListener(this);
	scale_button = new Choice();
	scale_button.add("2�{");
	scale_button.add("1�{");
	scale_button.add("1/2�{");
	scale_button.add("1/4�{");
	scale_button.add("1/5�{");
	scale_button.add("1/8�{");
	scale_button.add("1/10�{");
	scale_button.addItemListener(this);
       
	text = new TextField(20);
      
	panel2.add(play_button);
	panel2.add(reset_button);
	panel2.add(save_button);
	panel2.add(scale_button);
       
	panel2.add(text);	

	add("South",panel2);
	setSize(600,500);
	setVisible(true);
	time = (double)System.currentTimeMillis();
    }
    
    public void actionPerformed(ActionEvent e){
	if(e.getSource() == play_button && drawFlag == true){
	    playFlag = true;
	    double s = 1/scale;
	    double[] x = new double[ptindex];
	    double[] y = new double[ptindex];
	    double[] z = new double[ptindex];
	    for(int i=0; i<ptindex ;i++){
		x[i] = (double)pts[i].getX();
	    }
	    for(int j=0; j<ptindex ;j++){
		y[j] = 0.0;
	    }
	    for(int k=0; k<ptindex ;k++){
		z[k] = (double)pts[k].getY();
	    }
	    text.setText(target);
	    stage1.moveForWrite(target,ptindex,s,x,y,z);
	}
	if(e.getSource() == reset_button){
	    reset();
	    if(!pcache.isEmpty()){
		double x = ((Float)dviewer.cacheX.get(target)).doubleValue();
		double y = ((Float)dviewer.cacheY.get(target)).doubleValue();
		double z = ((Float)dviewer.cacheZ.get(target)).doubleValue();
		switch(onAirScene){
		case 1:
		    stage1.resetPosition(target,x,y,z);
		    break;
		case 2:
		    //stage2.resetPosition(target,x,y,z);
		    break;
		case 3:
		    //stage3.resetPosition(target,x,y,z);
		    break;
		default:
		    throw(new RuntimeException("Internal Error: got unknown type"));  
		}
	    }
	}
	if(e.getSource() == save_button && drawFlag == true){
	    xpoints = new float[ptindex];
	    ypoints = new float[ptindex];
	    zpoints = new float[ptindex];
	    pviewer = new PointsViewer();
	    for(int i=0;i<ptindex;i++){
		xpoints[i] = (float)(pts[i].getX()-250)/100;
		ypoints[i] = (float)0.0;
		zpoints[i] = (float)(pts[i].getY()-200)/100;
		pviewer.tarea.append("x=" + xpoints[i] + ",y=" + ypoints[i] +",z=" + zpoints[i] + "\n");
	    }
	    pviewer.show();
	    saveFlag = true;
	}
		
	System.out.println(e.getActionCommand());
    }
   
    public void mousePressed(MouseEvent e){

    }
    
    public void mouseReleased(MouseEvent e){
	dragFlag = false;
    }

    public void mouseClicked(MouseEvent e){
	double t = (double)System.currentTimeMillis();
	int x = e.getX();
	int y = e.getY();
	boolean flag = false;
	if((t-time)<400){
	    System.out.println("Double Click!!");
	    enum = pcache.keys();
	    /*
	    target = studyMap(enum,x,y);
	    active = true;
	    repaint();
	    */
	    while(enum.hasMoreElements()){
		target = (String) enum.nextElement();
		position = (Rectangle) pcache.get(target);
		if(position.contains(x,y)){
		    active = true;
		    repaint();
		    break;
		}
	    }
	}else{
	    String s = new String();
	    System.out.println("Click!");
	    enum = pcache.keys();
	    /*
	    s = studyMap(enum,x,y);
	    text.setText(s);
	    flag = true;
	    */
	    while(enum.hasMoreElements()){
		s = (String) enum.nextElement();
		position = (Rectangle) pcache.get(s);
		if(position.contains(x,y)){
		    text.setText(s);
		    break;
		}
	    }
	}
	time = t;
    }

    public void mouseEntered(MouseEvent e){
    }

    public void mouseExited(MouseEvent e){
    }

    public void mouseDragged(MouseEvent e){
	dragFlag = true;
	if(active){
	    pts[ptindex] = new Point(e.getX(),e.getY());
	    ptindex++;
	    repaint();
	}
    }

    public void mouseMoved(MouseEvent e){
    }

    public void itemStateChanged(ItemEvent e){
	int index = scale_button.getSelectedIndex();
	mapcache.clear();
	pcache.clear();
	setUpFlag = true;
	switch(index){
	case 0:
	    scale = 2;
	    break;
	case 1:
	    scale = 1;
	    break;
	case 2:
	    scale = 0.5;
	    break;
	case 3:
	    scale = 0.25;
	    break;
	case 4:
	    scale = 0.2;
	    break;
	case 5:
	    scale = 0.125;
	    break;
	case 6:
	    scale = 0.1;
	    break;
	default:
	    throw(new RuntimeException("Internal Error: got unknown type"));
	}
	changeAllPosition();
	if(stage1 != null){
	    repaint();
	}
    }
   
    public void update(Graphics g){
	g = canvas.getGraphics();
	paint(g);
    }

    public void paint(Graphics g){
	if(setUpFlag){
	    g.setColor(canvas.getBackground());
	    g.fillRect(0,0,canvas.getWidth(),canvas.getHeight());
	    drawMap(g);
	    setGoSign(g);
	    setUpFlag = false;
	}
	if(initFlag){
	    initDraw(g);
	}
	if(resetFlag){
	    resetCanvas(g);
	}
	if(!dragFlag && active){
	    setGoSign(g);
	}
	if(dragFlag && active){
	    drawRoad(g);
	}
    }
    

    public void setUpMWP(Stage1 stage){
	stage1 = stage;
	setUpFlag = true;
	onAirScene = 1;
	repaint();
    }
    /*
    public void setUpMWP(Stage2 stage){
	stage2 = stage;
	stage1 = null;
    }

    public void setUpMWP(Stage3 stage){
	stage3 = stage;
	stage2 = null;
    }
    */

    public void initPosition(String name,double x,double y,double z){
	initFlag = true;
	target = name;
	int xp = (int) (x*100*scale + 250);
	int zp = (int) (z*100*scale + 200);
	position = new Rectangle((int)(xp-10*scale),(int)(zp-10*scale),(int)(20*scale),(int)(20*scale));
	pcache.put(name,position);
	repaint();
    }

    public void initDraw(Graphics g){
	setGoSign(g);
	initFlag = false;
	active = true;
    }

    public void changeAllPosition(){
	String s = new String();
	enum = dviewer.cacheX.keys();
	while(enum.hasMoreElements()){
	    s = (String)enum.nextElement();
	    int x = (int)(((Float)dviewer.cacheX.get(s)).doubleValue()*100*scale+250);
	    int y = (int)(((Float)dviewer.cacheY.get(s)).doubleValue());
	    int z = (int)(((Float)dviewer.cacheZ.get(s)).doubleValue()*100*scale+200);
	    position = new Rectangle((int)(x-10*scale),(int)(z-10*scale),(int)(20*scale),(int)(20*scale));
	    pcache.put(s,position);
	}
    }

    public void setGoSign(Graphics g){
	String s = new String();
	enum = pcache.keys();
	while(enum.hasMoreElements()){
	    s = (String) enum.nextElement();
	    position = (Rectangle) pcache.get(s);
	    if(s.equals(target)){
		text.setText(target);
		g.setColor(Color.blue);
		g.fillOval((int)position.getX(),(int)position.getY(),(int)position.getWidth(),(int)position.getHeight());
		g.setColor(Color.black);
		g.drawOval((int)position.getX(),(int)position.getY(),(int)position.getWidth(),(int)position.getHeight());
	    }else {
		g.setColor(Color.red);
		g.fillOval((int)position.getX(),(int)position.getY(),(int)position.getWidth(),(int)position.getHeight());
		g.setColor(Color.black);
		g.drawOval((int)position.getX(),(int)position.getY(),(int)position.getWidth(),(int)position.getHeight());
	    }	
	}	  
    }

    public void drawRoad(Graphics g){
	drawFlag = true;
	g.setColor(Color.white);
	for(int loop_index = 0; loop_index < ptindex -1; loop_index++){
	    g.drawLine(pts[loop_index].x,pts[loop_index].y,pts[loop_index+1].x,pts[loop_index+1].y);
	}
    }

    public void resetCanvas(Graphics g){
	g.setColor(canvas.getBackground());
	g.fillRect(0,0,canvas.getWidth(),canvas.getHeight());
	drawMap(g);
	setGoSign(g);
	resetFlag = false;	
	System.out.println("RESET!!!");
    }

    public void reset(){
	if(pviewer != null){
	    pviewer.setVisible(false);
	    pviewer = null;
	}
	saveFlag = false;
	resetFlag = true;
	active = false;
	drawFlag = false;
	ptindex = 0;
	repaint();
    }	


    protected String studyMap(Enumeration enumeration,int x,int y){
	String name = new String();
	String targetName = new String();
	while(enumeration.hasMoreElements()){
	    name = (String) enumeration.nextElement();
	    position = (Rectangle) pcache.get(name);
	    if(position.contains(x,y)){
		targetName = name;
	    }
	}
	return targetName;
    }

    protected void drawMap(Graphics g){
	switch(onAirScene){
	case 1:
	    // �ƕ`��
	    g.setColor(new Color(100,100,0));
	    g.fillRect(250-(int)(250*scale),200-(int)(200*scale),(int)(500*scale),(int)(400*scale));
	    g.setColor(Color.black);
	    g.drawRect(250-(int)(250*scale),200-(int)(200*scale),(int)(500*scale),(int)(400*scale));
	    g.setColor(new Color(100,100,0));
	    g.fillRect(250-(int)(550*scale),200-(int)(200*scale),(int)(300*scale),(int)(400*scale));
	    g.setColor(Color.black);
	    g.drawRect(250-(int)(550*scale),200-(int)(200*scale),(int)(300*scale),(int)(400*scale));
	    if(setUpFlag){
		tempRec = new Rectangle(250-(int)(550*scale),200-(int)(200*scale),(int)(800*scale),(int)(400*scale));
		mapcache.put(tempRec,"House");
	    }
	    // �^���X�`��
	    g.setColor(Color.blue);
	    g.fillRect(250-(int)(240*scale),200-(int)(190*scale),(int)(60*scale),(int)(120*scale));
	    g.setColor(Color.black);
	    g.drawRect(250-(int)(240*scale),200-(int)(190*scale),(int)(60*scale),(int)(120*scale));
	    if(setUpFlag){
		tempRec = new Rectangle(250-(int)(240*scale),200-(int)(190*scale),(int)(60*scale),(int)(120*scale));
		mapcache.put(tempRec,"Shelf");
	    }
	    // �h�J��`��
	    g.setColor(Color.blue);
	    g.fillRect(250+(int)(130*scale),200-(int)(180*scale),(int)(110*scale),(int)(30*scale));
	    g.setColor(Color.black);
	    g.drawRect(250+(int)(130*scale),200-(int)(180*scale),(int)(110*scale),(int)(30*scale));
	    g.setColor(Color.blue);
	    g.fillRect(250+(int)(160*scale),200-(int)(140*scale),(int)(50*scale),(int)(26*scale));
	    g.setColor(Color.black);
	    g.drawRect(250+(int)(160*scale),200-(int)(140*scale),(int)(50*scale),(int)(26*scale));
	    if(setUpFlag){
		tempRec = new Rectangle(250+(int)(130*scale),200-(int)(180*scale),(int)(110*scale),(int)(30*scale));
		mapcache.put(tempRec,"Embroidery");
	    }
	    // �֎q�`��
	    int[] xpoints = {250-(int)(80*scale),250-(int)(60*scale),250-(int)(88*scale),250-(int)(108*scale),250-(int)(80*scale)};
	    int[] ypoints = {200,200-(int)(35*scale),200-(int)(51*scale),200-(int)(16*scale),200};
	    int pts = xpoints.length;
	    Polygon chairPoly = new Polygon(xpoints,ypoints,pts);
	    g.setColor(Color.blue);
	    g.fillPolygon(chairPoly);
	    g.setColor(Color.black);
	    g.drawPolygon(chairPoly);
	    if(setUpFlag){
		tempRec = chairPoly.getBounds();
		mapcache.put(tempRec,"Chair");
	    }
	    break;
	case 2:
	    break;
	case 3:
	    break;
	default:
	    throw(new RuntimeException("Internal Error: got unknown type"));
	}
    }
	    

}

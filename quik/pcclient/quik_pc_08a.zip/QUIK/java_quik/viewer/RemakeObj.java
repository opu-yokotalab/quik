// ------- �N���X����I�u�W�F�N�g�� ---------
//  2000/02/16 Earsh
package java_quik.viewer;
import  java_quik.*;

import javax.media.j3d.*;
import javax.vecmath.*;

public class RemakeObj {

    Stage1 stage1;
    //Stage2 stage2;
    //Stage3 stage3;
    TransformGroup objTG = new TransformGroup();

    public RemakeObj(Class objclass,String typeName){
	if(typeName.equals("background1")) {
	    try{
		stage1 = (Stage1) objclass.newInstance();
	    }catch(IllegalAccessException e){
		System.err.println("IllegalAccessException: " + e.getMessage());
	    }catch(InstantiationException e){
		System.err.println("InstantiationException: " + e.getMessage());
	    }catch(ExceptionInInitializerError e){
		System.err.println("ExceptionInInitializerError: " + e.getMessage());
	    }catch(SecurityException e){
		System.err.println("SecurityException: " + e.getMessage());
	    }
	}else if(typeName.equals("background2")){
	    /*
	      try{
	      stage2 = (Stage2) objclass.newInstance();
	      }catch(IllegalAccessException e){
	      System.err.println("IllegalAccessException: " + e.getMessage());
	      }catch(InstantiationException e){
	      System.err.println("InstantiationException: " + e.getMessage());
	      }catch(ExceptionInInitializerError e){
	      System.err.println("ExceptionInInitializerError: " + e.getMessage());
	      }catch(SecurityException e){
	      System.err.println("SecurityException: " + e.getMessage());
	      }
	    */
	}else if(typeName.equals("background3")){
	    /*
	      try{
	      stage3 = (Stage3) objclass.newInstance();
	      }catch(IllegalAccessException e){
	      System.err.println("IllegalAccessException: " + e.getMessage());
	      }catch(InstantiationException e){
	      System.err.println("InstantiationException: " + e.getMessage());
	      }catch(ExceptionInInitializerError e){
	      System.err.println("ExceptionInInitializerError: " + e.getMessage());
	      }catch(SecurityException e){
	      System.err.println("SecurityException: " + e.getMessage());
	      }
	    */
	}else {
	    try{
		objTG = (TransformGroup) objclass.newInstance();
	    }catch(IllegalAccessException e){
		System.err.println("IllegalAccessException: " + e.getMessage());
	    }catch(InstantiationException e){
		System.err.println("InstantiationException: " + e.getMessage());
	    }catch(ExceptionInInitializerError e){
		System.err.println("ExceptionInInitializerError: " + e.getMessage());
	    }catch(SecurityException e){
		System.err.println("SecurityException: " + e.getMessage());
	    }
	}
    }

    public Stage1 returnStage1(){
	return stage1;
    }

    /*
    public Stage2 retrunStage2(){
	return stage2;
    }

    public Stage3 returnStage3(){
	return stage3;
    }
    */

    public TransformGroup returnObjTG(){
	return objTG;
    }

}

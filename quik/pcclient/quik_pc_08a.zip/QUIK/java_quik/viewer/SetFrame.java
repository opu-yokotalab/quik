// ------- Set Frame for Test ---------
//  2000/02/16 Earsh
package java_quik.viewer;
import  java_quik.*;

import java.awt.*;
import java.awt.event.*;

public class SetFrame extends Frame implements ActionListener {

    Button button;
    Class c;
    String om_mediaName;
    DramaViewer dviewer;
    SetOMmedia setommedia;

    public SetFrame(){
	button = new Button("set");
	button.addActionListener(this);
	add(button);
	setTitle("Here we go!!");
	setSize(100,100);
	show();
	dviewer = new DramaViewer();
	setommedia = new SetOMmedia();
    }

    public static void main(String args[]){
	SetFrame test = new SetFrame();
    }

    public void actionPerformed(ActionEvent event){
//  2000/02/16  Earsh
//	OM_Media om_media = setommedia.returnOM_Media();
	DM_Media om_media = setommedia.returnOM_Media();
	int command = setommedia.c;
	dviewer.transfer(om_media,command);
    }

}

// ------- �N���X�𐶐����� ---------
//  2000/02/16 Earsh
package java_quik.viewer;
import  java_quik.*;

import java.net.*;

public class CreatClass {

    Class objclass = null;

    public CreatClass(URL url,String name){
	try{
	    NetworkClassLoader loader = new NetworkClassLoader(url);
            System.out.println("url:" + url + " name:" + name);
	    objclass = loader.loadClass(name,true);
	}catch(ClassNotFoundException e){
	    System.err.println("Class not found1: " + e.getMessage());
	}
    }

    public Class returnClass(){
	return objclass;
    }

}

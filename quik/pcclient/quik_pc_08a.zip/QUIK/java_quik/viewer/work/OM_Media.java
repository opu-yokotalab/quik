// ------- test of OM_Media -------
package java_quik;

public class OM_Media {

    int type;
    int play_time;
    int Synchro_time;
    OM_Picture picture;
    OM_Object obj;
    OM_Move move;
    OM_Sound sound;
    OM_Utterance utterance;
    OM_Text text;
    String name;
    OM_Media next;

    public OM_Media(int t,int pt,int st,OM_Picture pic,OM_Object o,OM_Move m,OM_Sound sound,OM_Utterance utterance,OM_Text text,String s){
	type = t;
	play_time = pt;
	Synchro_time = st;
	picture = pic;
	obj = o;
	move = m;
	this.sound = sound;
	this.utterance = utterance;
	this.text = text;
	name = s;
    }

}

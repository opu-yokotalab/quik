// ------- test of OM_Atom -------
package java_quik;

public class OM_Atom {

    String name;

    public OM_Atom(String s){
	name = s;
    }

}

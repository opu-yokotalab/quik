// ------ test of OM_Point ------
package java_quik;

public class OM_Point {

    float point_x;
    float point_y;
    float point_z;
    OM_Point next;

    public OM_Point(float x,float y,float z){
	point_x = x;
	point_y = y;
	point_z = z;
	next = null;
    }

}

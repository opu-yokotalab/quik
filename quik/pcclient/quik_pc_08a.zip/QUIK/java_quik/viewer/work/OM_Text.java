// ------- test of OM_Text --------

public class OM_Text {

    String str;
    String font;
    int scale;
    float r;
    float g;
    float b;

    public OM_Text(String str,String font,int scale,float r,float g,float b){
	this.str = str;
	this.font = font;
	this.scale = scale;
	this.r = r;
	this.g = g;
	this.b = b;
    }

}

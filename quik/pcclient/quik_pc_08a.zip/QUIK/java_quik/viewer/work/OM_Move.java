// ------- test of OM_Move ---------
package java_quik;

public class OM_Move {

    int type;
    OM_Atom obj;
    OM_Point point;

    public OM_Move(int t,OM_Atom oa,OM_Point p){
	type = t;
	obj = oa;
	point = p;
    }

}

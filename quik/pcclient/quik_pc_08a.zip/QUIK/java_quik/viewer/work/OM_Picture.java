// ------ test of OM_Picture -------
package java_quik;

public class OM_Picture {

    String URL;
    OM_Point point;
    float scale;

    public OM_Picture(String url,OM_Point op,float s){
	URL = url;
	point = op;
	scale = s;
    }

}

// ------ test of OM_Sound -------
package java_quik;

public class OM_Sound {
    
    String URL;

    public OM_Sound(String url){
	URL = url;
    }

}

// ------- test of OM_Object ------
package java_quik;

public class OM_Object {

    String URL;
    OM_Point point;

    public OM_Object(String url,OM_Point p){
	URL = url;
	point = p;
    }

}

// ------- test of OM_Utterance ---------

public class OM_Utterance {
    
    String str;
    String font;
    int loudness;
    int pitch;

    public OM_Utterance(String str,String font,int loudness,int pitch){
	this.str = str;
	this.font = font;
	this.loudness = loudness;
	this.pitch = pitch;
    }

}

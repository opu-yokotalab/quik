//  Dummy OM_Media
package java_quik;

public class OM_Media {
  public int          type         = 0;
  public OM_Atom      atom         = null;
  public int          play_time    = 0;
  public int          synchro_time = 0;
  public OM_Picture   picture      = null;
  public OM_Sound     sound        = null;
  public OM_Utterance utterance    = null;
  public OM_Text      text         = null;
  public OM_Object    object       = null;
  public OM_Move      move         = null;
  public OM_Media     next         = null;
}

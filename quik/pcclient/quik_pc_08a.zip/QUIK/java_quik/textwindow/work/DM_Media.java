package java_quik;

public class DM_Media{
  OM_Text      text;
  DM_Media     next;

  public DM_Media(){
    text = null;
    next = null;
  }
}

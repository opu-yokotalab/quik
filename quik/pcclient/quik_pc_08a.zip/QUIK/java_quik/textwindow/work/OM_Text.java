package java_quik;

public class OM_Text{
  String str;
  String font;
  float  scale;
  float  r;
  float  g;
  float  b;

  public OM_Text(){
    str = null;
    font = "TimesRoman";/*null;*/
    scale = 1.0f;
    r = 1.0f;
    g = 1.0f;
    b = 1.0f;
  }

}

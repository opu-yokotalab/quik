/* TextWindow��P�̃e�X�g���邽�߂̃v���O���� */

package java_quik.textwindow;
import  java_quik.*;

import java.awt.*;
import java.io.*;

public class testText extends Frame{

  public static void main( String argv[] ){
    TextWindow tw = new TextWindow();
    tw.show();

    DM_Media media = new DM_Media();
    OM_Text ot = new OM_Text();
    ot.str = "file://C:/jdk122/Prog/QUIK/java_quik/textwindow/message.txt";

    media.text = ot;
    int flag = tw.PrintText( media );

    System.out.println( flag );
  }
}

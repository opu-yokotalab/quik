package java_quik.textwindow;
import  java_quik.*;

public class Text_outstr{
  String string;
  Text_outstr next;

  public Text_outstr( String str ){
    string = str;
    next = null;
  }

}

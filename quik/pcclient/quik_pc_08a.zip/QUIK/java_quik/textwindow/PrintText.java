package java_quik.textwindow;
import  java_quik.*;

import java.awt.*;
import java.net.*;
import java.io.*;

public class PrintText extends Canvas{
  Graphics ag;
  Image    bg;
  Graphics gf;
  Image    sImage;
  Graphics sg;
  int      TextWidth;   /* �e�L�X�g�������镝 */
  int      TextHeight;  /* �e�L�X�g�������鍂�� */
  Font     font;
  OM_Text  o_text = null;
  int      flag;
  Image    sImage2;


  public PrintText(){
    setSize( 500,500 );
    font = new Font( "TimesRoman", Font.PLAIN, 24 );
    /* Font.PLAIN �W��, Font.BOLD ������, Font.ITALIC �Α� */
    flag = 0;
  }

  public int PrintString( OM_Text text ){
    o_text = text;
    flag = 0;

    return 0;
  }
  
  /* �󂯂Ƃ��� DM_Media ���o�͉\�ȕ�����̕���(�s��)�ɕϊ�����B */
  public void DrawString(){
    int    len, size;      /* len:�o�͂��镶����̕����� */
                           /* size:�o�͂��镶����̃T�C�Y */
    String name;           /* �o�͂��镶����̏��� */
    Color  co;             /* �o�͂��镶����̐F */
    String message;        /* �o�͂��镶���� */
    int    w_size, h_size; /* ���݂̃L�����o�X�̑傫���ŕ\���ł��� */
                           /* ������(w_size)�ƍs��(h_size) */
    int    str_height;     /* �ꕶ���̕����̍��� */
    Font   f;              /* �t�H���g */

    FontMetrics fontmetrics;
    Text_outstr outstr, top = null;

    if ( o_text == null )
      return;

    if( o_text.str.startsWith( "http:" ) )
      message = loadData( o_text.str );
    else
      message = GetMessage( o_text.str );

    len = message.length();

    size = (int)(30*o_text.scale); /* 1�����̍ő�T�C�Y 30 */
    if( o_text.font == null )
      name = "TimesRoman";
    else
      name = o_text.font;

    w_size = TextWidth / size * 2;

    co = new Color( o_text.r, o_text.g, o_text.b );
    font = new Font( name, Font.PLAIN, size );

    Toolkit tk = Toolkit.getDefaultToolkit();
    String str[] = tk.getFontList();
    font = new Font( str[0], Font.PLAIN, size );
    ag.setFont( font );
    
    fontmetrics = getFontMetrics( font );

    str_height = fontmetrics.getHeight();
    h_size = TextHeight / str_height;


    /* message ���o�͂ł��镶�����ɋ�؂� Text_outstr.string �Ɋi�[���Ă��� */
    int s_index = 0, e_index;
    int d_size;
    int n=0;

    outstr = new Text_outstr("top");
    top = outstr;
    
    while( len >= s_index+1 ){
      if( len != s_index+1 ){
	if( len > s_index + w_size )
	  e_index = s_index + w_size;
	else
	  e_index = len;
	
	outstr.next = new Text_outstr( message.substring( s_index, e_index ) );
	outstr = outstr.next;

	while( fontmetrics.stringWidth( outstr.string ) > TextWidth ){
	  e_index--;
	  outstr.string = message.substring( s_index, e_index );
	}
      }
      else{
	e_index = len;
	outstr.next = new Text_outstr( message.substring( len-1, len ) );
	outstr = outstr.next;
      }
      n++;
      s_index = e_index;
    }

    /* �o�͂���镶����̑S�̂̃C���[�W sImage �ɁA Text_outstr ��`�ʂ��� */
    sImage = createImage( TextWidth, str_height*n+2 );
    sg = sImage.getGraphics();

    font = new Font( str[0], Font.PLAIN, size );

    sg.setColor( Color.black );
    sg.fillRect( 0, 0, TextWidth, str_height*n+2 );

    sg.setColor( co );
    sg.setFont( font );
    Text_outstr tmp = top.next;
    int line=str_height-1;
    while( tmp != null ){
      sg.drawString( tmp.string, 0, line );
      line += str_height;
      tmp = tmp.next;
    }

    if( sImage.getHeight(this) < TextHeight ){
      ag.drawImage( sImage, 8, 6, this );
      sImage2 = sImage;
    }
    else{
      Image    outImage = createImage( TextWidth, TextHeight );
      Graphics pg = outImage.getGraphics();

      int i=0;
      while( TextHeight + i < sImage.getHeight(this) ){
	pg.setColor( Color.black );
	pg.fillRect( 0, 0, TextWidth, TextHeight );
	
	pg.drawImage( sImage, 0, -i, this );
	ag.drawImage( outImage, 8, 6, this );
	
	try{Thread.sleep(100);}catch(InterruptedException e){System.exit(1);}
	i++;
      }
      sImage2 = outImage;
    }
    flag = 1;
  }

  public void paint( Graphics g ){
    ag = g;

    /* �w�i�̕`�� */
    if( bg == null )
      SetBackGround();
    ag.drawImage(bg, 0, 0, this);
    
    /* �����̕`�� */
    if( flag == 0 )
      DrawString();
    else
      ag.drawImage(sImage2, 8, 6, this);
  }

  public void PrintSize(){
    int w = getSize().width;
    System.out.println( "w = " + w );
    System.out.println( "h = " + getSize().height );
  }

  public void SetSize( int w, int h ){
    setSize( w, h );
    bg = null;
  }

  public void SetBackGround(){
    int w = getSize().width;
    int h = getSize().height;

    bg = createImage( w, h );
    gf = bg.getGraphics();

    gf.setColor( Color.black );
    gf.fillRect( 0, 0, w, h );

    gf.setColor( new Color( 255, 255, 255 ) );
    gf.drawRect( 0, 0, 7, 7 );
    gf.drawRect( 2, 2, 3, 3 );


    gf.drawRect( w-8, 0, 7, 7 );
    gf.drawRect( w-6, 2, 3, 3 );

    gf.drawRect( 0, h-8, 7, 7 );
    gf.drawRect( 2, h-6, 3, 3 );

    gf.drawRect( w-8, h-8, 7, 7 );
    gf.drawRect( w-6, h-6, 3, 3 );
    
    gf.drawLine( 7, 2, w-8, 2 );
    gf.drawLine( 7, 5, w-8, 5 );

    gf.drawLine( w-3, 7, w-3, h-9 );
    gf.drawLine( w-6, 7, w-6, h-9 );

    gf.drawLine( 7, h-3, w-8, h-3 );
    gf.drawLine( 7, h-6, w-8, h-6 );

    gf.drawLine( 2, 7, 2, h-9 );
    gf.drawLine( 5, 7, 5, h-9 );

    /*gf.setColor( new Color( 255, 0, 0 ) );
    gf.drawRect( 8, 8, w-17, h-17 );*/

    TextWidth  = w-17;
    TextHeight = h-17;

    /*for( int i=8; i<TextWidth; i+=12)
      gf.drawLine( i, 0, i, 100 );*/
  }

  public String loadData( String location) {
    URL url;
    URLConnection uc;
    BufferedReader br;
    String meg = "", line = "";

    try {
      url = new URL( location);
      uc  = url.openConnection();
      br = new BufferedReader(new InputStreamReader( uc.getInputStream()));
//    uc.getInputStream(), sysdat.KNJ));
      while( (line = br.readLine()) != null) {
        meg += line;
      }
      br.close();
    } catch ( Exception e ) {
      System.out.println("Exception: " + e);
      e.printStackTrace();
      return null;
    }
    return meg;
  }

  public static String GetMessage( String location ){
    FileInputStream fis = null;
    BufferedReader  br;
    String          buff;
    String          message = "";
    String          str = "";

    for( int i=7; i<location.length(); i++ )
      str += location.charAt( i );

    try{
      fis = new FileInputStream(str);
      br  = new BufferedReader( new InputStreamReader( fis ) );

      while( true ){
	/* �t�@�C������f�[�^�� 1 �s���Ăэ��� */
	buff = br.readLine();

	/* �Ăяo���ꂽ�f�[�^�� null �Ȃ�Ăэ��ݏI�� */
	if( buff == null ){
	  br.close();
	  fis.close();
	  break;
	}
	else
	  message += buff;
      }
    }catch(IOException e){
      /* �t�@�C�����o�͎��̃G���[���� */
      System.out.println("IO error");
      System.exit(1);
    }

    return message;
  }

}

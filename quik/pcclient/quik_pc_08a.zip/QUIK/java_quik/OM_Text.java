package java_quik;

import java.io.*;

public class OM_Text implements Serializable {

  public OM_Text()
  {
    this.str = null;  
    this.font = null;
    this.scale = (float)0.5;
    this.r = (float)1.0;
    this.g = (float)1.0;
    this.b = (float)1.0;
  }

  public OM_Text(String str, String font, float scale, float r, float g, float b)
  {
    this.str = str;  
    this.font = font;
    this.scale = scale;
    this.r = r;
    this.g = g;
    this.b = b;
  }

  public String    str;
  public String    font;
  public float     scale;
  public float     r;
  public float     g;
  public float     b;
} 

package java_quik;

import java.io.*;

public class DM_Point implements Serializable {
  public float            point_x = (float)0.0;
  public float            point_y = (float)0.0;
  public float            point_z = (float)0.0;
  public DM_Point         next    = null;

  public DM_Point(OM_Point point) {
    if ( point == null )
      return;

    this.point_x = point.point_x;
    this.point_y = point.point_y;
    this.point_z = point.point_z;
    this.next    = DM_Point.convert( point.next );
  }

  public DM_Point() {}

  public static DM_Point convert( OM_Point pit ) {
    if ( pit == null )
      return null;

    DM_Point dpit = new DM_Point();

    dpit.point_x = pit.point_x;
    dpit.point_y = pit.point_y;
    dpit.point_z = pit.point_z;
    dpit.next    = DM_Point.convert( pit.next );

    return dpit;
  }
}

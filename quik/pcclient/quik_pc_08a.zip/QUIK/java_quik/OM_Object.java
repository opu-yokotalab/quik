//  Dummy OM_Object
package java_quik;

public class OM_Object {
  public String   url   = null;
  public OM_Point point = null;
}

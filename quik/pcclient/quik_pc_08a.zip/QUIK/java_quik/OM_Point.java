//  Dummy OM_Point
package java_quik;

public class OM_Point {
  public float    point_x = (float)0.0;
  public float    point_y = (float)0.0;
  public float    point_z = (float)0.0;
  public OM_Point next    = null;
}

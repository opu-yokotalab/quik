package java_quik;

import java.io.*;

public class DM_Media implements Serializable {
  public int           type         = 0;
  public DM_Atom       atom         = null;
  public int           play_time    = 0;
  public int           synchro_time = 0;
  public DM_Picture    picture      = null;
  public OM_Sound      sound        = null;
  public OM_Utterance  utterance    = null;
  public OM_Text       text         = null;
  public DM_Object     object       = null;
  public DM_Move       move         = null;
  public DM_Media      next         = null;

  public DM_Media( OM_Media media){
    if ( media == null )
      return;

    this.type         = media.type;
    this.atom         = new DM_Atom( media.atom );
    this.play_time    = media.play_time;
    this.synchro_time = media.synchro_time;
    this.picture      = new DM_Picture( media.picture );
    this.sound        = media.sound;
    this.utterance    = media.utterance;
    this.text         = media.text;
    this.object       = new DM_Object( media.object );
    this.move         = new DM_Move( media.move );
    this.next         = new DM_Media( media.next );
  }

  public DM_Media() {}

  public static DM_Media convert( OM_Media media ) {
    if ( media == null )
      return null;

    DM_Media dmedia = new DM_Media();

    dmedia.type         = media.type;
    dmedia.atom         = DM_Atom.convert( media.atom );
    dmedia.play_time    = media.play_time;
    dmedia.synchro_time = media.synchro_time;
    dmedia.picture      = DM_Picture.convert( media.picture );
    dmedia.sound        = media.sound;
    dmedia.utterance    = media.utterance;
    dmedia.text         = media.text;
    dmedia.object       = DM_Object.convert( media.object );
    dmedia.move         = DM_Move.convert( media.move );
    dmedia.next         = DM_Media.convert( media.next );

    return dmedia;
  }
}

package java_quik;

import java.io.*;

public class OM_Atom implements Serializable {

  public OM_Atom()
    {
		name = null;
		next_bucket = null;
		node = null;
		data = null;
    }

  public String       name;  
  public OM_Atom      next_bucket;
  public OM_Node      node;
  public OM_Media     data;
}

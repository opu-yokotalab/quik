package java_quik;

import java.io.*;

public class OM_Point implements Serializable {

/* 2000.2.10 ogata */
/*public OM_Point(T_Point t_point, OM_Point next)
{
  this.point_x = t_point.point_x;
  this.point_y = t_point.point_y;
  this.point_z = t_point.point_z;
  this.next = next;
}*/

public OM_Point()
{
  this.point_x = (float)0.0;
  this.point_y = (float)0.0;
  this.point_z = (float)0.0;
  this.next = null;
}

public float            point_x;
public float            point_y;
public float            point_z;
public OM_Point         next;
public static OM_Point  point_pool;

}

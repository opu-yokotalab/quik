import java.awt.*;
import java.awt.event.*;

public class threadTest extends Frame implements WindowListener,
                                                 ActionListener {
  public final int num = 5;

  testThread thread[] = new testThread[num];
  Button     bt[]     = new Button[num];
  TextArea   ta       = new TextArea(10,10);

  public void init() {
    setLayout( new BorderLayout());
    Panel pn1 = new Panel();
    pn1.setLayout( new GridLayout( 1, num));
    for ( int i = 0; i < num; i++ ) {
      bt[i] = new Button("Thread" + i);
      bt[i].addActionListener(this);
      pn1.add(bt[i]);
      thread[i] = new testThread( i, ta);
    }
    add("North",  pn1);
    add("Center", ta);
    addWindowListener(this);
  }

  public static void main( String args[] ) {
    threadTest window = new threadTest();
    window.init();
    window.pack();
    window.show();
  }

  public void actionPerformed( ActionEvent ae ) {
    Object obj = ae.getSource();

    for ( int i = 0; i < bt.length; i++)
      if ( bt[i] == obj )
        thread[i].start();
  }

  public void windowClosing( WindowEvent we ) {
    dispose();
    System.exit(0);
  }
  public  void windowClosed( WindowEvent we ) {}
  public void windowOpened( WindowEvent we ) {}
  public void windowIconified( WindowEvent we ) {}
  public void windowDeiconified( WindowEvent we ) {}
  public void windowActivated( WindowEvent we ) {}
  public void windowDeactivated( WindowEvent we ) {}
}

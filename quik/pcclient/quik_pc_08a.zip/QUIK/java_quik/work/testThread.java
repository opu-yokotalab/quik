import java.awt.*;

public class testThread extends Thread {
  int      number = 0;
  TextArea ta     = null;
  Thread   thread = null;

  public testThread( int n, TextArea t) {
    number = n;
    ta     = t;
  }

  public testThread( int n ) {
    this( n, null);
  }

  public void start() {
    if ( thread == null ) {
      thread = new Thread(this);
      thread.start();
    }
  }

  public void sstop() {
    if ( thread != null ) {
      thread.stop();
      thread = null;
    }
  }

  public void run() {
    for( int i = 0; i < 10; i++) {
      ta.append("Thread[" + number +"]=" + i + "\n");
      try {
        sleep(1000);
      } catch( InterruptedException ie) {}
    }
    sstop();
  }
}

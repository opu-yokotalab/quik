package java_quik;

import java.io.*;

public class OM_Node implements Serializable {

  public OM_Node(){
    this.head = null;
    this.body = null;
    this.next = null;
    this.parent = null;
    //this.head = head;
    //this.body = body;
    //this.next = next;
    //this.parent = parent;
  }

  public OM_Atom   head;
  public OM_Leaf   body;
  public OM_Node   next;
  public OM_Leaf   parent;

  //public static OM_Leaf   leaf_list;  //OM_Leaf.node ---> OM_Node�̂Ƃ��K�v 

  //public static int  stream_str_int;  //#stream()�̒��̕������int�ŕێ�
  public static String  stream_str;
  public static OM_Node node_pool = null;
  public static OM_Node node_pool_last = null;
} 

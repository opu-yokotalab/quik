package java_quik;

import java.io.*;

public class OM_Media implements Serializable {

  public OM_Media(int type, OM_Atom atom){
    this.type = type;
    this.atom = atom;
    this.play_time = 0;
    this.synchro_time = 0;
    this.picture = null;
    this.sound = null;
    this.utterance = null;
    this.text = null;
    this.object = null;
    this.move = null;
    this.next = null;
  }

  public int           type;
  public OM_Atom       atom;
  public int           play_time;
  public int           synchro_time;
  public OM_Picture    picture;
  public OM_Sound      sound;
  public OM_Utterance  utterance;
  public OM_Text       text;
  public OM_Object     object;
  public OM_Move       move;
  public OM_Media      next;

  public static OM_Media media_pool_last = null;
} 

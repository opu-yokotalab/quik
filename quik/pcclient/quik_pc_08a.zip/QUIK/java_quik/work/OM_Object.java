package java_quik;

import java.io.*;

public class OM_Object implements Serializable {

  public OM_Object()
  {
    this.url = null;  
    this.point = null;
  }

  public OM_Object(String url)
  {
    this.url = url;  
    this.point = null;
  }

  public String    url;
  public OM_Point  point;

} 

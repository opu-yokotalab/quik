package java_quik;

import java.io.*;

public class OM_Leaf implements Serializable {

  public OM_Leaf()
  {
    this.command = -1;  
    this.seq_next = null;
    this.nonorder = null;
    this.data = null;
    this.node = null;
    this.comment = null;
  }

  public OM_Leaf(int command, OM_Atom data)
  {
    this.command = command;
    this.seq_next = null;
    this.nonorder = null;
    this.data = data;
    this.node = null;
    this.comment = null;
  }

  public OM_Leaf(int t_seq, int t_non)
  {
    this.command = -1;
    this.seq_next = null;
    this.nonorder = null;
    this.data = null;
    this.node = null;
    this.comment = null;

    if(t_seq == 1)
      this.seq_next = ex_leaf;
    if(t_non == 1)
      this.nonorder = ex_leaf;

  }

  public int       command;
  public OM_Leaf   seq_next;
  public OM_Leaf   nonorder;
  public OM_Atom   data;
  public OM_Node   node;
  public String    comment;

  public static OM_Leaf stream_current_leaf; //#stream()�̌��݂Ȃ���Ă���Ƃ���܂ł�Leaf
  public static int   stack_command;
  public static OM_Leaf ex_leaf;  
} 

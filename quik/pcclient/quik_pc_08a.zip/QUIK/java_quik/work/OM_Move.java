package java_quik;

import java.io.*;

public class OM_Move implements Serializable {

  public OM_Move()
  {
    //this.type = 0;  
    this.obj = null;
    this.point = null;
  }

  public OM_Move(OM_Atom obj)
  {
    this.type = obj.data.type;  
    this.obj = obj;
    this.point = null;
  }

  public int       type;
  public OM_Atom   obj;
  public OM_Point  point;
} 

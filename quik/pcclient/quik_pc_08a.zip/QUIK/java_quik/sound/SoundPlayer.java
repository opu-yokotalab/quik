package java_quik.sound;
import java_quik.*;

import java.awt.*;
import java.io.*;
import javax.media.j3d.*;
import com.sun.j3d.utils.universe.*;

public class SoundPlayer {
  public String soundfile;
  float volume;

  Frame frame;
  ControlButton button;

  Canvas3D canvas;
  SimpleUniverse universe;

  BranchGroup sceneRoot;
  BgSoundNode node;

  String Serectedfile;
  public MediaContainer data;

  public SoundPlayer(){
    canvas = new Canvas3D(null);
    universe = new SimpleUniverse(canvas);
    
    AudioDevice ad = universe.getViewer().createAudioDevice();
    volume = 0.5f;
    soundfile = ".\\Media\\bell.wav";
//    soundfile = null;

    sceneRoot = new BranchGroup();
    node = new BgSoundNode(soundfile,volume);
    
    frame = new Frame("Sound Player");
    button = new ControlButton(this);

    sceneRoot.addChild(node);
    universe.addBranchGraph(sceneRoot);
  }

  public void PlayerShow(){
    canvas.setSize(1,1);

    frame.add(canvas,"Center");
    frame.add(button,"South");
    frame.pack();
    frame.show();
  }


  //  2000/02/15 Earsh
  //  ������炷���߂ɕK�v�� Canvas ���擾����
  public Canvas3D getCanvas() {
    canvas.setSize( 1, 1);
    return canvas;
  }

//  2000/02/15 Earsh
//  public int SoundPlay(OM_Media om_media, int n,boolean play_time){
  public int SoundPlay( DM_Media om_media, int n, boolean play_time){
    String url = "";
//  2000/02/15 Earsh
//    OM_Sound om_s1 = new OM_Sound();
//    om_media.sound = om_s1;

    data = new MediaContainer();
    data.setCapability(MediaContainer.ALLOW_URL_WRITE);

    try{
      url = om_media.sound.url;
//  2000/02/15 Earsh
      if ( url.startsWith("http:") || url.startsWith("file:") ) {
        data.setURL( url );
      } else {
        data.setURL(node.getAbsoluteFileURL( url ));
      }
      node.setSoundData(data);
      node.setInitialGain(om_media.sound.volume);
      if(play_time == true){
        node.setReleaseEnable(true);
        node.setEnable(true);
      }else{
        node.setReleaseEnable(false);
        node.setEnable(false);
      }

    }catch(CapabilityNotSetException e){
      System.out.println("Execption:" + e );
    }
    return 0;
  }

  public static void main(String[] args){
    SoundPlayer player;

    player = new SoundPlayer();
    player.PlayerShow();
  }
}

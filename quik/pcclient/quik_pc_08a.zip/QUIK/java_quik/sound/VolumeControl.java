package java_quik.sound;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import javax.media.j3d.*;

public class VolumeControl extends JPanel implements AdjustmentListener{
  //����Ώۂ̃I�u�W�F�N�g
  private SoundPlayer_db target_v;

  Scrollbar scroll;

  //�R���X�g���N�^
  public VolumeControl(SoundPlayer_db target_v){
    this.target_v = target_v;
    setLayout(new BorderLayout());

    scroll = new Scrollbar(Scrollbar.HORIZONTAL,0,1,0,100);
    add(scroll);
    scroll.addAdjustmentListener(this);
  }

  public void adjustmentValueChanged(AdjustmentEvent e){
      
    float SelectedVolume;
    if(e.getAdjustable().equals(scroll)){
      SelectedVolume = scroll.getValue() * 0.1f;
      try{
        target_v.node.setInitialGain(SelectedVolume);
      }catch(CapabilityNotSetException evt){
      }
    }
    else
      System.out.println("Unexpected Error.");
  }

}

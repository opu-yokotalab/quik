//�T�E���h�Đ��̂��߂̃m�[�h
package java_quik.sound;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.media.j3d.*;

public class BgSoundNode extends BackgroundSound{
  MediaContainer data;

  //�R���X�g���N�^
  public BgSoundNode(String fileName,float volume){
    
    //�m�[�h�̋��r�b�g�̐ݒ�
    setCapability(BackgroundSound.ALLOW_SOUND_DATA_WRITE);
    setCapability(BackgroundSound.ALLOW_INITIAL_GAIN_WRITE);
    setCapability(BackgroundSound.ALLOW_ENABLE_WRITE);
    setCapability(BackgroundSound.ALLOW_RELEASE_WRITE);
    //setCapability(BackgroundSound.ALLOW_IS_PLAYING_READ);
    //setCapability(BackgroundSound.ALLOW_DURATION_READ);

    //�T�E���h�f�[�^�̎擾
    data = new MediaContainer();
    data.setCapability(MediaContainer.ALLOW_URL_WRITE);
    data.setURL(getAbsoluteFileURL(fileName));
    setSoundData(data);
    
    //���ʂ̐ݒ�
    setInitialGain(volume);
    
//  2000/02/17  Earsh
//    setLoop(Sound.INFINITE_LOOPS);

    //�Đ���Ԃ̐ݒ�
    setReleaseEnable(false);
    setEnable(false);
    
  }

  //�t���p�X�̕�����𐶐����邽�߂̃��\�b�h
  public String getAbsoluteFileURL(String fileName){
    String path = null;
    try{
      File dir = new File(".");
      path = dir.getAbsolutePath();
      path = "file:/" + path + File.separator + fileName;
    }
    catch(Exception e){
      System.err.println("File Name Error.");
    }
    return path;
  }
}

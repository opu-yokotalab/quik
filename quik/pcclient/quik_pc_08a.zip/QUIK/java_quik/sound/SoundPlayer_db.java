package java_quik.sound;

import java.awt.*;
import java.io.*;
import javax.media.j3d.*;
import com.sun.j3d.utils.universe.*;

public class SoundPlayer_db{
  public String soundfile;
  float volume;

  Frame frame;
  Panel panel;
  ControlPanel c_panel;
  FileChoice choice;
  VolumeControl volume_c;

  Canvas3D canvas;
  SimpleUniverse universe;

  BranchGroup sceneRoot;
  BgSoundNode_db node;

  public SoundPlayer_db(){
    canvas = new Canvas3D(null);
    universe = new SimpleUniverse(canvas);
    
    AudioDevice ad = universe.getViewer().createAudioDevice();
    volume = 0.5f;
    soundfile = ".\\wav\\bell.wav";

    sceneRoot = new BranchGroup();
    node = new BgSoundNode_db(soundfile,volume);
    
    frame = new Frame("Sound Player");
    panel = new Panel();
    c_panel = new ControlPanel(node);
    choice = new FileChoice(this);
    volume_c = new VolumeControl(this);

    panel.setLayout(new BorderLayout(0,2));
    panel.add(c_panel,"North");
    panel.add(choice,"Center");
    panel.add(volume_c,"South");

    sceneRoot.addChild(node);
    universe.addBranchGraph(sceneRoot);
  }

  public void PlayerShow(){
    canvas.setSize(200,1);

    frame.setLayout(new BorderLayout());
    //frame.add(canvas,"North");
    frame.add(canvas,"Center");
    frame.add(panel,"South");
    //frame.add(choice,"South");
    //frame.add(volume_c,"East");
    frame.pack();
    frame.show();
  }
  
  public static void main(String[] args){
    SoundPlayer_db player;

    player = new SoundPlayer_db();
    player.PlayerShow();
  }

}

package java_quik.sound;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import javax.media.j3d.*;

public class FileChoice extends JPanel{
  //����Ώۂ̃I�u�W�F�N�g
  private SoundPlayer_db target_c;

  Choice choice;
  TextField text1;

  //�R���X�g���N�^
  public FileChoice(SoundPlayer_db target_c){
    this.target_c = target_c;
    setLayout(new GridLayout(2,1));
    ActionAdapter_2 adapter = new ActionAdapter_2();

    choice = new Choice();

    choice.add("bell.wav");
    choice.add("dog.wav");
    choice.add("door.wav");
    choice.add("drip.wav");
    choice.add("fire.wav");
    choice.add("knock.wav");
    choice.add("thunder_1.wav");
    choice.add("thunder_2.wav");
    choice.add("walk.wav");
    choice.add("wave.wav");

    text1 = new TextField(20);
    add(text1);

    choice.addItemListener(adapter);
    add(choice);
  }

  class ActionAdapter_2 implements ItemListener{
    String Serectedfile;
    private MediaContainer data;

    //�C�x���g�����̃��\�b�h
    public void itemStateChanged(ItemEvent evt){
//      Serectedfile = ".\\wav\\" + (String)choice.getSelectedItem();
      Serectedfile = "http://alpha.c.oka-pu.ac.jp/~sugimoto/Quik/";
      Serectedfile += (String)choice.getSelectedItem();
      text1.setText(Serectedfile);

      data = new MediaContainer();
      data.setCapability(MediaContainer.ALLOW_URL_READ);
      data.setCapability(MediaContainer.ALLOW_URL_WRITE);

      try{
//        data.setURL(target_c.node.getAbsoluteFileURL(Serectedfile));
        data.setURL( Serectedfile );
        target_c.node.setSoundData(data);
      }catch(CapabilityNotSetException e){
      }
    }
  }

}

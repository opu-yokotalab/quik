package java_quik;
import java_quik.commgr.*;
import java_quik.gui.*;
import java_quik.viewer.*;
import java_quik.utterance.*;
import java_quik.textwindow.*;

public class Main {
  public PCclient    uiClient;
  public DM_main     dmClient;
  public dummyCommgr commgr;

  public DramaViewer viewer;
  public Utterance   utte;
  public TextWindow  txtwin;

  public static Main mine;

  public void init() {
    mine = this;

    txtwin = new TextWindow();

    uiClient = new PCclient(this);
    uiClient.init();
    uiClient.setTitle("UI Client");
    uiClient.pack();
    uiClient.show();

    commgr = new dummyCommgr();
    viewer = new DramaViewer();
    utte   = new Utterance();

    dmClient = new DM_main(this);
    dmClient.init( QuikStatus.CLIENT );
  }

  public static void main(String args[]) {
    Main program = new Main();
    program.init();
  }
}

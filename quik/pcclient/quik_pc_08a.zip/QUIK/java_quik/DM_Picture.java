package java_quik;

import java.io.*;

public class DM_Picture implements Serializable {
  public String    url   = null;
  public DM_Point  point = null;
  public float     scale = (float)0.5;

  public DM_Picture( OM_Picture picture ) {
    if ( picture == null )
      return;

    this.url   = picture.url;
    this.point = new DM_Point( picture.point );;
    this.scale = picture.scale;
  }

  public DM_Picture() {}

  public static DM_Picture convert( OM_Picture pic ) {
    if ( pic == null )
      return null;

    DM_Picture dpic = new DM_Picture();
    
    dpic.url   = pic.url;
    dpic.scale = pic.scale;
    dpic.point = DM_Point.convert( pic.point );;

    return dpic;
  }
} 

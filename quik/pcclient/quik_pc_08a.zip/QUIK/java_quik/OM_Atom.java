// Dummy OM_Atom
package java_quik;

public class OM_Atom {
  public String name = null;
}

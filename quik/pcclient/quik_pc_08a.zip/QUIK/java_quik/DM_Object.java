package java_quik;

import java.io.*;

public class DM_Object implements Serializable {
  public String    url   = null;
  public DM_Point  point = null;

  public DM_Object( OM_Object obj ) {
    if ( obj == null )
      return;

    this.url   = obj.url;  
    this.point = DM_Point.convert( obj.point );
  }

  public DM_Object() {}

  public static DM_Object convert( OM_Object obj ) {
    if ( obj == null )
      return null;

    DM_Object dobj = new DM_Object();

    dobj.url   = obj.url;  
    dobj.point = DM_Point.convert( obj.point );

    return dobj;
  }
} 

package java_quik.commgr;
import java_quik.*;
import java_quik.gui.*;

public class dummyCommgr {
  public void resumeStatus( int cmid, Object obj) {}
  public void sendCSObject( Object obj ) {}
  public void returnStatus( int stt, Object obj) {}

  public void sendMessage(String Message) {
    int cmd = -1;
    CM_command command = new CM_command();

    cmd = command.selCommand( Message);
    System.out.println("command:" + cmd);
  }
}

package java_quik.utterance;
import  java_quik.*;

import java.io.*;
import java.lang.*;
import java.net.*;

public class Utterance{
  public String dirBase = "jdk122\\Prog\\QUIK\\";
  public String textfile  = "C:\\hello\\read.txt",
                fontfile = "C:\\hello\\hello\\file\\data.dat",
                pitchfile = "C:\\hello\\hello\\file\\speed.dat",
                execfile = "C:\\hello\\hello\\hello";

  public void EngineBoot(){
    // Java���特�����������s
    try{
//      Process proc = Runtime.getRuntime().exec("c:\\hello\\hello\\hello");
      Process proc = Runtime.getRuntime().exec( execfile );
    }catch (IOException ioe){
      System.out.println(ioe.toString());
    }
  }

//  2000/02/17  Earsh
//  public boolean UtteranceStart(DM_Media media,int n){
  public int UtteranceStart(DM_Media media,int n){
    byte b[] = new byte[2048];
    String str;
    FileOutputStream fos;
    OutputStreamWriter osw;
    int pitch = 1, play_time = media.play_time;

    //  2000/02/17  Earsh
    str = loadData( media.utterance.str );
    if ( str == null )
      return -1;

//  2000/02/17  Earsh
/**
    OM_Utterance om_ut1 = new OM_Utterance();

    om_ut1.str = "����ف[�B";
    om_ut1.font = "female";
    om_ut1.pitch = 3;

    media.utterance = om_ut1;
*/

   pitch = (int)(media.utterance.pitch * 10);

    try{
      fos = new FileOutputStream( textfile );
      
      osw = new OutputStreamWriter(fos);
      
      try{
	b = str.getBytes(osw.getEncoding());
      }catch(UnsupportedEncodingException e){
        System.err.println("Not Support String Encoding.");
        return -1;
      }
      
      try{
        fos.write(b);
        if ( !str.endsWith("\n") )
          fos.write('\n');
      } catch(IOException e) {
        System.err.println("IO error.");
        return -1;
      } finally {
        fos.close();
      }
    }catch(IOException e){
      System.err.println("File writing error." + e);
      return -1;
    }

    //data.dat �ւ̏�������
    try {
      PrintStream psData = new PrintStream(new FileOutputStream( fontfile ));
      if(media.utterance.font.equals("male")) {
        psData.print("a");
      } else if(media.utterance.font.equals("female")) {
        psData.print("aa");
      }
      psData.close();
    } catch (IOException e) {
      System.out.println("File writing error: " + e);
      return -1;
    }

    //speed.dat �̏�������
    try{
      PrintStream psSpeed = new PrintStream(new FileOutputStream( pitchfile ));
      if(pitch == 1){
        psSpeed.print("+");
      }else if(pitch == 2){
        psSpeed.print("++");
      }else if(pitch == 3){
        psSpeed.print("+++");
      }else if(pitch == 4){
        psSpeed.print("++++");
      }else if(pitch == 5){
        psSpeed.print("+++++");
      }
      psSpeed.close();
    }catch (IOException e){
      System.out.println("File writing error: " + e);
      return -1;
    }
    //  2000/02/17  Earsh
    EngineBoot();

    if ( play_time < 0 )
      play_time = 0;

    try {
      Thread.sleep(play_time * 1000);
    } catch( InterruptedException ie ) {}

    return 0;
  }

  //  �t�@�C������̃f�[�^�̓ǂݍ���
  public String loadData( String location) {
    URL url;
    URLConnection uc;
    BufferedReader br;
    String msg = "", line = "";
    try {
      url = new URL( location );
      uc  = url.openConnection();
      br = new BufferedReader(new InputStreamReader( uc.getInputStream()));
      while( (line = br.readLine()) != null) {
        msg += line;
      }
      br.close();
    } catch ( Exception e ) {
      System.out.println("Exception: " + e);
      return null;
    }
    return msg;
  }

  public static void main(String args[]){
    Utterance ut = new Utterance();
    DM_Media om_m1 = new DM_Media();

    if( ut.UtteranceStart(om_m1,0) == 0 ){
      ut.EngineBoot();
    }
  }

}

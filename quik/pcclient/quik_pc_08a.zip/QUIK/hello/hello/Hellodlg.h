//------------------------------------------------------------------------------
//
// COPYRIGHT:
// ----------
// Copyright (C) International Business Machines Corp., 1997.
//
// DISCLAIMER OF WARRANTIES:
// -------------------------
// The following [enclosed] code is sample code created by IBM
// Corporation.  This sample code is not part of any standard IBM
// product and is provided to you solely for the purpose of
// assisting you in the development of your applications.  The
// code is provided "AS IS", without warranty of any kind.  IBM
// shall not be liable for any damages arising out of your use of
// the sample code, even if they have been advised of the
// possibility of such damages.
//
//------------------------------------------------------------------------------
//
//  helloDlg.h : �w�b�_�[ �t�@�C��
//
//------------------------------------------------------------------------------

/////////////////////////////////////////////////////////////////////////////
// CHelloDlg dialog

class CHelloDlg : public CDialog
{
// �\�z
public:
	CHelloDlg(CWnd* pParent = NULL);	// �W���̃R���X�g���N�^

// Dialog Data
	//{{AFX_DATA(CHelloDlg)
	enum { IDD = IDD_HELLO_DIALOG };
	CString	m_strText;
	//}}AFX_DATA

	// ClassWizard �͉��z�֐��𐶐����I�[�o�[���C�h���܂��B
	//{{AFX_VIRTUAL(CHelloDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV �̃T�|�[�g
	//}}AFX_VIRTUAL

// �C���v�������e�[�V����
protected:
	HICON m_hIcon;
	PITTSENUM	 m_pITTSEnum;
	PITTSCENTRAL m_pITTSCentral;
	PITTSATTRIBUTES m_pITTSAttributes;
	PITTSBUFNOTIFYSINK m_pITTSBufNotifySink;
	PITTSNOTIFYSINK m_pITTSNotifySink;
	BOOL        m_fTextDataDone;
	BOOL        m_fNotification;
    STDMETHODIMP TextDataDone (QWORD, DWORD);
    DWORD            m_dwRegKey; 

	// �������ꂽ���b�Z�[�W �}�b�v�֐�
	//{{AFX_MSG(CHelloDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnTest();
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


import java.io.*;               
import java.lang.*;

public class Speech{

  public void SpeechPlay(){
    // Java���特�����������s
    try{
      Process proc = Runtime.getRuntime().exec("c:\\speech\\hello\\hello");
    }catch (IOException ioe){
      System.out.println(ioe.toString());
    }
  }

  public boolean FileOutput(String output_file){
    byte b[] = new byte[1024];
    String str;
    FileOutputStream fos;
    OutputStreamWriter osw;

    str = "����ɂ��� HelloWorld ";

    try{
      fos = new FileOutputStream(output_file);
      
      osw = new OutputStreamWriter(fos);
      //System.out.println("code: " + osw.getEncoding());
      
      try{
	b = str.getBytes(osw.getEncoding());
      }catch(UnsupportedEncodingException e){
        System.err.println("Not Support String Encoding.");
        System.exit(1);
      }
      
      try{
        fos.write(b);
        fos.write('\n');
      }catch(IOException e){
        System.err.println("IO error.");
        System.exit(1);
      }finally{
        fos.close();
      }
    }catch(IOException e){
      System.err.println("IO error.");
      System.exit(1);
    }
    return true;
  }

  public static void main(String args[]){
    Speech sp = new Speech();

    if(args.length <= 0){
      System.err.println("No file given.");
      System.exit(1);
    }else{
      if(sp.FileOutput(args[0])){
        // data.dat �ւ̏�������
        try{
          PrintStream psData = new PrintStream(new FileOutputStream("data.dat"));
          if(args[1].equals("male")){
            psData.print("a");
          }else if(args[1].equals("female")){
            psData.print("aa");
          }
          psData.close();
        }catch (IOException e){
           System.out.println("File write error: " + e);
        }

        // speed.dat �̏�������
        try{
          PrintStream psSpeed = new PrintStream(new FileOutputStream("speed.dat"));
          if(args[2].equals("1")){
            psSpeed.print("+");
          }else if(args[2].equals("2")){
            psSpeed.print("++");
          }else if(args[2].equals("3")){
            psSpeed.print("+++");
          }else if(args[2].equals("4")){
            psSpeed.print("++++");
          }else if(args[2].equals("5")){
            psSpeed.print("+++++");
          }
          psSpeed.close();
        }catch (IOException e){
          System.out.println("File write error: " + e);
        }
	sp.SpeechPlay();
      }
    }
  }

}

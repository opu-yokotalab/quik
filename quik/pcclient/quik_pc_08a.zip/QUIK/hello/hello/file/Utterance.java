import java.io.*;               
import java.lang.*;

public class Utterance{

  public void EngineBoot(){
    // Java���特�����������s
    try{
      Process proc = Runtime.getRuntime().exec("c:\\hello\\hello\\hello");
    }catch (IOException ioe){
      System.out.println(ioe.toString());
    }
  }

  public boolean UtteranceStart(OM_Media media,int n){
    byte b[] = new byte[1024];
    String str;
    FileOutputStream fos;
    OutputStreamWriter osw;

    OM_Utterance om_ut1 = new OM_Utterance();

    om_ut1.str = "���肪�Ƃ��������܂��B";
    om_ut1.font = "male";
    om_ut1.pitch = 3;

    media.utterance = om_ut1;

    try{
      fos = new FileOutputStream("..\\..\\read.txt");
      
      osw = new OutputStreamWriter(fos);
      
      try{
	b = media.utterance.str.getBytes(osw.getEncoding());
      }catch(UnsupportedEncodingException e){
        System.err.println("Not Support String Encoding.");
        System.exit(1);
      }
      
      try{
        fos.write(b);
        fos.write('\n');
      }catch(IOException e){
        System.err.println("IO error.");
        System.exit(1);
      }finally{
        fos.close();
      }
    }catch(IOException e){
      System.err.println("File writing error." + e);
      System.exit(1);
    }

    //data.dat �ւ̏�������
    try{
      PrintStream psData = new PrintStream(new FileOutputStream("data.dat"));
      if(media.utterance.font.equals("male")){
        psData.print("a");
      }else if(media.utterance.font.equals("female")){
        psData.print("aa");
      }
      psData.close();
    }catch (IOException e){
       System.out.println("File writing error: " + e);
    }

    //speed.dat �̏�������
    try{
      PrintStream psSpeed = new PrintStream(new FileOutputStream("speed.dat"));
      if(media.utterance.pitch == 1){
        psSpeed.print("+");
      }else if(media.utterance.pitch == 2){
        psSpeed.print("++");
      }else if(media.utterance.pitch == 3){
        psSpeed.print("+++");
      }else if(media.utterance.pitch == 4){
        psSpeed.print("++++");
      }else if(media.utterance.pitch == 5){
        psSpeed.print("+++++");
      }
      psSpeed.close();
    }catch (IOException e){
      System.out.println("File writing error: " + e);
    }

    return true;
  }

  public static void main(String args[]){
    Utterance ut = new Utterance();
    OM_Media om_m1 = new OM_Media();

    if(ut.UtteranceStart(om_m1,0)){
      ut.EngineBoot();
    }
  }

}

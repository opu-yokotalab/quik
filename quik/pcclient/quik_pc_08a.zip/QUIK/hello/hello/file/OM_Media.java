public class OM_Media{
  int type;
  //int play_time = null;
  //int Synchro_time = null;
  //OM_Sound sound = null;
  OM_Utterance utterance = null;
  OM_Media next = null;
}

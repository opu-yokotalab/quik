public class OM_Utterance{
  String str = null;
  String font = null;
  int loudness = 1;
  int pitch = 1;
}

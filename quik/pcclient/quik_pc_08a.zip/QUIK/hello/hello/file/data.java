import java.io.*;               

public class data{
  public static void main(String args[]){
    // data.dat �ւ̏�������
    try{
      PrintStream psData = new PrintStream(new FileOutputStream("data.dat"));
      if(args[0].equals("male")){
        psData.print("a");
      }else if(args[0].equals("female")){
        psData.print("aa");
      }
      psData.close();
    }catch (IOException e){
       System.out.println("File write error: " + e);
    }

    // speed.dat �̏�������
    try{
      PrintStream psSpeed = new PrintStream(new FileOutputStream("speed.dat"));
      if(args[1].equals("1")){
        psSpeed.print("+");
      }else if(args[1].equals("2")){
        psSpeed.print("++");
      }else if(args[1].equals("3")){
        psSpeed.print("+++");
      }else if(args[1].equals("4")){
        psSpeed.print("++++");
      }else if(args[1].equals("5")){
        psSpeed.print("+++++");
      }
      psSpeed.close();
    }catch (IOException e){
      System.out.println("File write error: " + e);
    }

    // ���������A�v���P�[�V�����̎��s
    try{
      Process proc = Runtime.getRuntime ().exec("c:\\hello\\hello\\Release\\Hello");
    }catch(IOException ioe){
      System.out.println (ioe.toString());
    }
    try{
      String line_str;
      int line_number;
      FileInputStream is = new FileInputStream("c:\\hello\\read.txt");

      BufferedReader ids = new BufferedReader(new InputStreamReader(is, "SJIS"));

      while ((line_str = ids.readLine()) != null){
        System.out.println(line_str);
      }
      ids.close();
    }catch (IOException e){
      System.out.println("File write error: " + e);
    }
  }

}


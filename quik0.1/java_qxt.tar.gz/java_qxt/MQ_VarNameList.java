package java_qxt;

public class MQ_VarNameList  {

public MQ_VarNameList(){
	this.vterm = new MQ_PP();
}


public static MQ_VarNameList get_all_variables ()
{
  int i;
  MQT_Var tv;
  MQ_VarNameList current = null;
  MQ_VTerm name_var;

  if (MQT_Var.variable_pool == null)
    return null;

  for (tv = MQT_Var.variable_pool; tv!=null; tv=tv.next_bucket)
    {
      if((int)tv.name.charAt(0) > 57 || (int)tv.name.charAt(0) < 49){
          name_var = MQ_VTerm.make_name_var  (0, tv.name);
          current = make_var_name_list (tv.var, name_var, current);
      }
    }
  
  return current;
}

public static MQ_VarNameList make_var_name_list (MQ_VTerm  var,
                                                 MQ_VTerm name_var,
                                                 MQ_VarNameList  next)
{
  MQ_VarNameList new_obj;

  new_obj = new MQ_VarNameList();
  new_obj.name_var = name_var;
  new_obj.next = next;

  if (var!=null)                      /* executing == 1 here */
    var.vterm_addr_list
      = new MQ_VTermAddrList(new_obj.vterm, var.vterm_addr_list);

  new_obj.vterm.vterm = var;  // (1)

  return new_obj;
}



public MQ_VarNameList  next;
public MQ_VTerm      name_var;
//$B#2=E%]%$%s%?$r<B8=$9$k$?$a$N%/%i%9(BMQ_PP$B$r:n$C$?(B
public MQ_PP           vterm;
}

package java_qxt;
import java_cup.runtime.*;

/** MQT_Term($B6&MQBN(B)$B$KBP1~(B */

public class MQT_Term extends MQT_VTerm {

  public MQT_Term(int term_num)
    {
      super(term_num);
    }

}

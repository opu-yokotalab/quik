package java_qxt;

// $B#C8@8l$N#2=E%]%$%s%?$r#J#a#v#a$G<B8=$9$k$?$a$N%/%i%9!#(B

public class MQ_Cons_PP {
	public MQ_Cons_PP(){}
	public MQ_Constraints cs;
}

package java_qxt;
import java_cup.runtime.*;

public class MQT_Dot extends MQT_Term {

  public MQT_Dot(int term_num, MQT_VTerm term, MQ_Atom label)
// makeT_dot (term, label)$B$KBP1~(B    
  {
    this(term_num);
    MQT_Var var;
    
    this.type = TermType.TT_Dot; 

    if (term.type == TermType.TT_Dot) {
      var = new MQT_Var(sym_num.VARIABLE);
      var.name = String.valueOf(MQT_Var.inter_number);
      MQT_Var.inter_number++;
      var.next_bucket = MQT_Var.variable_pool;//$B%j%9%H$K$D$J$0(B
      MQT_Var.variable_pool = var;
      MQT_Constraints.current_cnstrs = new MQT_Constraints(Rel.Congruent, (MQT_VTerm)var,term, null, MQT_Constraints.current_cnstrs);
      this.vterm = (MQT_VTerm)var;
    }
    else
      this.vterm = term;
    this.label = label;
  }

  public MQT_Dot(MQT_VTerm term, MQ_Atom label)
  {
    this(5);//dummy$B$rEO$9(B
    MQT_Var var;
    
    this.type = TermType.TT_Dot; 

    if (term.type == TermType.TT_Dot) {
      var = new MQT_Var(sym_num.VARIABLE);
      var.name = String.valueOf(MQT_Var.inter_number);
      MQT_Var.inter_number++;
      var.next_bucket = MQT_Var.variable_pool;//$B%j%9%H$K$D$J$0(B
      MQT_Var.variable_pool = var;
      MQT_Constraints.current_cnstrs = new MQT_Constraints(Rel.Congruent, (MQT_VTerm)var,term, null, MQT_Constraints.current_cnstrs);
      this.vterm = (MQT_VTerm)var;
    }
    else
      this.vterm = (MQT_VTerm)term;
    this.label = label;
  }

  public MQT_Dot(int term_num)
    {
      super(term_num);
    }
}

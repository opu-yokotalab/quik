package java_qxt;
import java_cup.runtime.*;

public class Rel extends token {

  public Rel(int term_num, int integer)
    {
      super(term_num);
      sr = integer;
    }

  public int sr;// Rel$BNs5s7?(B
  public static final int Supersumes = -1;   // 
  public static final int Congruent  = 0;    // $BF1CM4X78(B
  public static final int Subsumes   = 1;
  public static final int ExternalExpr = 2; 
  public static final int ExternalCnstr = 3; // $B30It@)Ls(B
  public static final int DotCongruent  = 4;
  public static final int DotCongruentVar =5; 
  public static final int DotCongruentObj =6;
  public static final int SubsumesVarVar  =7; 
  public static final int SubsumesVarObj  =8;
  public static final int SubsumesObjVar  =9;

};

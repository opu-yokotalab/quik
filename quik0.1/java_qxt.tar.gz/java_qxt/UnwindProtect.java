package java_qxt;

public class UnwindProtect {

public UnwindProtect(){}

  public UnwindProtect next;
  public MQ_VTerm var;
  public MQ_VTermAddrList vterm_addr_list;

}

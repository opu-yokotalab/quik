package java_qxt;
import java_cup.runtime.*;

public class MQT_AttrList extends symbol{

public static MQT_AttrList makeT_attr_list (int attr_rel,MQ_Atom label,
				     MQT_VTerm vterm, MQT_AttrList atl)
{
  MQT_Var var;
  MQT_AttrList new_obj, top;

  new_obj = new MQT_AttrList(10);//dummy$B$NCM$rEO$9(B
  new_obj.label = label;
  if ((attr_rel != AttrRel.Equal) || (vterm.type == TermType.TT_Dot))
    {
      var = MQT_Var.makeT_new_variable ();
      var.name = String.valueOf(MQT_Var.inter_number);
      MQT_Var.inter_number++;
      var.next_bucket = MQT_Var.variable_pool;//$B%j%9%H$K$D$J$0(B
      MQT_Var.variable_pool = var;
//    System.out.println("varT.name is ....." + var.name);/*$B%G%P%C%0(B*/
      MQT_Constraints.current_cnstrs = new MQT_Constraints(attr_rel,
							   (MQT_Term)var,
							   (MQT_Term)vterm, 
							   null,
					      MQT_Constraints.current_cnstrs);
      new_obj.vterm = (MQT_VTerm)var;
    }
  else
    new_obj.vterm = vterm;

  if ((atl == null) || ((label.name.compareTo(atl.label.name)>0)))
//$BK\Ev$O%]%$%s%?$,JL(B
    {
      top = new_obj;
      new_obj.next = atl;
    }
  else
    {
      top = atl; // $B>o$KB0@-$N@hF,$r;X$9$h$&$K$9$k$?$a!#(B
      while (true)
        {
          if ((atl.next == null)
              || ((label.name.compareTo(atl.label.name)<0)))
            {
              new_obj.next = atl.next;
              atl.next = new_obj;
              break;
            }
          else if (label.name.equals(atl.label))
            {
              MQ_Error.mq_error ("same label in attribute. (ignored)\n");
              return atl;
            }
          atl = atl.next;
        }
    }
  return top;
}


  public MQT_AttrList(int term_num)
    {
      super(term_num);
    }
  
  public MQ_Atom        label;
  public MQT_VTerm      vterm;
  public MQT_AttrList   next;

}

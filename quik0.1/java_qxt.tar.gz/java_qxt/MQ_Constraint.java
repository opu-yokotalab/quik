package java_qxt;
//import 

public class MQ_Constraint {

public MQ_Constraint()
{
	this.vterm = new MQ_PP();
	this.term = new MQ_PP();
	this.rel = 0;
}

public static MQ_Constraint make_cnstr (int rel,MQ_VTerm term,MQ_VTerm vterm)
{
	MQ_Constraint new_obj;

	new_obj = new MQ_Constraint();
	new_obj.rel = rel;
	new_obj.term.vterm   = term;
	new_obj.vterm.vterm = vterm;
	if ((term!=null) &&(Extern_h.executing!=0) && (term.type == TermType.TT_Var)){
		term.vterm_addr_list
			= new MQ_VTermAddrList(new_obj.term,
						term.vterm_addr_list);
}
	if ((vterm!=null)&&(Extern_h.executing!=0)&&(vterm.type == TermType.TT_Var)){
		vterm.vterm_addr_list
			= new MQ_VTermAddrList(new_obj.vterm,
						vterm.vterm_addr_list);
}
  if (cs.mm_current == cs.mm_cnstrs){
    new_obj.mark = 1;
  }
  else{
    new_obj.mark = 0;
  }
  return new_obj;
}

	public int rel;
	//$B#2=E%]%$%s%?$r<B8=$9$k$?$a$N%/%i%9(BMQ_PP$B$r:n$C$?!#(B
	public MQ_PP term;
	public MQ_PP vterm;

	/* for garbage collection */
	public int mark;  //mm_* $B$O:o$C$?(B

};




package java_qxt;

public class MQ_VTermAddrList {

public MQ_VTermAddrList(MQ_PP vterm_p,MQ_VTermAddrList next)
//make_vterm_addr_list (vterm_p, next)$B$KBP1~(B;
//make_vterm_addr_list$B$O(Binternal.c$B$NCf$K$"$k!#(B
{
	this.vterm_addr = vterm_p;
	this.next = next;
}

public static void var_vterm_addr_list (MQ_VTerm var,MQ_PP vterm)
{
	var.vterm_addr_list
             = new MQ_VTermAddrList(vterm, var.vterm_addr_list);
}
  MQ_VTermAddrList  next;
  MQ_PP             vterm_addr;

}

package java_qxt;

public class MQ_Query  {

public MQ_Query()//make_query ()$B$KBP1~(B
  {
    this.goal = null;
    this.body = null;
    this.var_list = null;
    this.var_name_list = null;
  }

public MQ_Goal          goal;
public MQ_VTermList     body;
public MQ_VarList       var_list;
public MQ_VarNameList   var_name_list;

}

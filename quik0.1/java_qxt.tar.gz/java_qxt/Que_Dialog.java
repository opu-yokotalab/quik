package java_qxt;

import java.awt.*;

class Que_Dialog extends Dialog {

	Button bt1, bt2, bt3, bt4, bt5, bt6, bt7, bt8, bt9, bt10, bt11, bt12;
	public static TextField tf;
	Label type;
	Panel panel1, panel2, panel3;
	timeLabel label;
	boolean start=true;
	public static String number="0";
	

	public Que_Dialog(Frame parent) {
		super(parent, "About Dialog", true);

		//setBackground(Color.pink);

		bt7 = new Button("7");
		bt8 = new Button("8");
		bt9 = new Button("9");
		bt4 = new Button("4");
		bt5 = new Button("5");
		bt6 = new Button("6");
		bt1 = new Button("1");
		bt2 = new Button("2");
		bt3 = new Button("3");
		bt10 = new Button("0");
		bt11 = new Button("OK");
		bt12 = new Button("Clear");
		tf = new TextField("0", 13);
		tf.setEditable(false);
		type = new Label("NUMBER : ");
		panel1 = new Panel();
		panel2 = new Panel();
		panel3 = new Panel();
		label = new timeLabel();
		label.resize(220, 30);

		setLayout(new BorderLayout());

		add("North", label);
		panel1.add(type);
		panel1.add(tf);
		panel2.setLayout(new GridLayout(4, 3));
		panel2.add(bt7);
		panel2.add(bt8);
		panel2.add(bt9);
		panel2.add(bt4);
		panel2.add(bt5);
		panel2.add(bt6);
		panel2.add(bt1);
		panel2.add(bt2);
		panel2.add(bt3);
		panel2.add(bt10);
		panel2.add(bt11);
		panel2.add(bt12);
		
		panel3.setLayout(new BorderLayout());
		panel3.add("North", panel1);
		panel3.add("Center", panel2);

		add("Center", panel3);

		resize(220, 300);
	}

	public boolean action(Event ev, Object arg) {
		if (ev.target == bt1) {
			if(start) {
				tf.setText("1");
				start = false;
			} else {
				tf.setText(tf.getText() + "1");
			}
			return true;
		}else if (ev.target == bt2) {
			if(start) {
				tf.setText("2");
				start = false;
			} else {
				tf.setText(tf.getText() + "2");
			}
			return true;
		}else if (ev.target == bt3) {
			if(start) {
				tf.setText("3");
				start = false;
			} else {
				tf.setText(tf.getText() + "3");
			}
			return true;
		}else if (ev.target == bt4) {
			if(start) {
				tf.setText("4");
				start = false;
			} else {
				tf.setText(tf.getText() + "4");
			}
			return true;
		}else if (ev.target == bt5) {
			if(start) {
				tf.setText("5");
				start = false;
			} else {
				tf.setText(tf.getText() + "5");
			}
			return true;
		}else if (ev.target == bt6) {
			if(start) {
				tf.setText("6");
				start = false;
			} else {
				tf.setText(tf.getText() + "6");
			}
			return true;
		}else if (ev.target == bt7) {
			if(start) {
				tf.setText("7");
				start = false;
			} else {
				tf.setText(tf.getText() + "7");
			}
			return true;
		}else if (ev.target == bt8) {
			if(start) {
				tf.setText("8");
				start = false;
			} else {
				tf.setText(tf.getText() + "8");
			}
			return true;
		}else if (ev.target == bt9) {
			if(start) {
				tf.setText("9");
				start = false;
			} else {
				tf.setText(tf.getText() + "9");
			}
			return true;
		}else if (ev.target == bt10) {
			if(start) {
				tf.setText("0");
			} else {
				tf.setText(tf.getText() + "0");
			}
			return true;
		}else if (ev.target == bt11) {
			latapp.th.dia_num = tf.getText();
			dispose();
			return true;
		}else if (ev.target == bt12) {
			tf.setText("0");
			start = true;
			return true;
		}
		return false;
	}

	public boolean handleEvent(Event evt) {
			if(evt.id == Event.WINDOW_DESTROY && evt.target == this)
			dispose();
			else return super.handleEvent(evt);
			return true;
		}
}

class timeLabel extends Canvas {    /* Label$B@_Dj(B */

	public void paint(Graphics g) {
		g.setFont(new Font("Dialog", Font.ITALIC, 15));
		g.drawString("Please imput number ?", 20,20);
	}
}


class Access {
	String access_num = "0";
}
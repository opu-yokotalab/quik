package java_qxt;
import java_cup.runtime.*;

public class MQT_AtomList extends token {

  public MQT_AtomList(int term_num,MQ_Atom atom,MQT_AtomList next)
    {
      super(term_num);
      this.atom = atom;
      this.next = next;
    }

  public MQT_AtomList(int term_num)
    {
      this(term_num, null, null);
    }

  public MQT_AtomList next;
  public MQ_Atom     atom;

}

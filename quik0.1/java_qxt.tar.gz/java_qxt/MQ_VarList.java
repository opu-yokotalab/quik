package java_qxt;
//import 

public class MQ_VarList {

	public MQ_VarList(MQ_VTerm var,MQ_VarList next)
	//make_var_list (var, next)$B$KBP1~(B    
	{
		this.next = next;
		this.var = var;
	}

	public MQ_VarList next;
	public MQ_VTerm var;
	public static MQ_VarList var_list_p;
};

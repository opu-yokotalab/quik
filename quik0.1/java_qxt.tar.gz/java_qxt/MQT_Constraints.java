package java_qxt;
import java_cup.runtime.*;

public class MQT_Constraints {

  public MQT_Constraints(int rel,MQT_VTerm t1,MQT_VTerm t2,MQ_Atom op,MQT_Constraints next)
// makeT_constraints (rel, t1, t2, op, next)$B$KBP1~(B    
  {
    this.rel = rel;
    this.term1 = t1;
    this.term2 = t2;
    this.op = op;
    this.next = next;
  }

  public int rel;
  public MQT_VTerm term1;
  public MQT_VTerm term2;
  public MQ_Atom op;
  public MQT_Constraints next;
  public static MQT_Constraints current_cnstrs;
  public static MQT_Constraints head_cnstrs;

}

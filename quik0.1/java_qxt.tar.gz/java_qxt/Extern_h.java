package java_qxt;

public class Extern_h {

/* extern declarations */
static String mq_version;
static int interactive;
static int interactive_orig;
static int force_interactive;

static int temporary;

/* atom.c */
static String atom_first_obj;


/* cs.c */
public static MQ_CnstrsAsmpts cnstrs_asmpts;
public static MQ_Constraint mQ_void_cnstr = new MQ_Constraint();
public static MQ_Constraints mQ_void_cnstrs = new MQ_Constraints();
public static MQ_CnstrsAsmpts mQ_void_cnstrs_asmpts = new MQ_CnstrsAsmpts();
public static int constrain_failed;


/* exec.c */
public static int executing;
static MQ_Goal mq_goal_true = new MQ_Goal();


/* lex.c */
static int last_char_is_newline;
static int lineno;
static MQ_Atom external_cnstr_op = new MQ_Atom(1);


/* option.c */
static int debug;
static int debug_memory;
static int mq_opt_constrain;


/* parse.y */
static int mq_mode;
static boolean error_recovering;
static boolean reading_object;


/* rule.c */
static MQ_Atom mqA_True = new MQ_Atom(1);
public static MQ_VTerm mqO_True = MQ_VTerm.make_MQ_Obj();
static MQ_VTerm mq_name = MQ_VTerm.make_MQ_NameVar();
static MQ_Rule mQ_void_rule = new MQ_Rule();
static MQ_Rule mQ_void = new MQ_Rule();
static MQ_RuleList mQ_void_rule_list = new MQ_RuleList(null);
public static MQ_RuleList rule_list,rule_list_last;


/* subsump.c */
   static MQ_Atom mqA_Bottom = MQ_Atom.intern_atom("&bottom");
   static MQ_Atom mqA_Top = MQ_Atom.intern_atom("&top");
   static MQ_VTerm mqO_Bottom = MQ_VTerm.make_object(Extern_h.mqA_Bottom, 0);
   static MQ_VTerm mqO_Top = MQ_VTerm.make_object(Extern_h.mqA_Top, 0);

/* unify.c */
static int binding_changed;
static UnwindProtect up = new UnwindProtect();

}

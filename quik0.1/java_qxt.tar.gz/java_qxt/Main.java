package java_qxt;
import java.io.*;
import java.awt.*;
import java_cup.runtime.*;

public class Main {

  public static void main(String argv[])
    {

	Extern_h.error_recovering = false;

	FileList.init_scanner();
	Commands.init_command();
        Commands.init_options ();
	cs.init_constraints();
	rule.init_rule();		/* 1997/12/16 ogata */

	//        Commands.show_version();
	//        FileList.output_prompt();

        Fquik F = new Fquik();
	F.start();

    }
}



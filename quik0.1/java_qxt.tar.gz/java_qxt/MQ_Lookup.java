package java_qxt;
public class MQ_Lookup {

public MQ_Lookup(){
  this.entry = 0;

  this.head = new MQ_PP();
  this.body = null;
  this.head_cnstrs = this.body_cnstrs = Extern_h.mQ_void_cnstrs;
}

public  int entry;

public  MQ_PP head;
public  MQ_VTermList body;
public  MQ_Constraints head_cnstrs, body_cnstrs;

}

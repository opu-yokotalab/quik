package java_qxt;
//import 

public class MQ_Rule {
	/** Full constructor. */
	public MQ_Rule()
	//make_rule ()$B$KBP1~(B    
	{
		this.next = null;
		this.is_temp = temp_alloc_rule;
//		this.head = null;
		this.head = new MQ_PP();
		this.body = null;
		this.head_cnstrs = this.body_cnstrs = Extern_h.mQ_void_cnstrs;
		this.var_list = null;
	}

	public MQ_Rule next;
	public int is_temp;
//	public MQ_VTerm head;
	public MQ_PP head;
	public MQ_Constraints head_cnstrs;
	public MQ_VTermList body;
	public MQ_Constraints body_cnstrs;
	public MQ_VarList var_list;
	public static int temp_alloc_rule;
};

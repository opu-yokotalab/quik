package java_qxt;
import java_cup.runtime.*;

public class TermType_token extends MQT_Term{
 
  public TermType_token(int term_num,int integer)
    {
      super(term_num);
      this.type = integer;
    }


  public static final int TT_Var =0;
  public static final int TT_Dot =1;
  public static final int TT_Obj =2;
  public static final int TT_NameVar=3; 
}

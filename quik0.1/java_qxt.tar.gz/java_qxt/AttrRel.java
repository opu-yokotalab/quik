package java_qxt;
import java_cup.runtime.*;

public class AttrRel extends token {

  public AttrRel(int term_num, int integer)
    {
      super(term_num);
      ar = integer;
    }

  public int ar;// AttrRel$BNs5s7?(B
  
  public static final int InstanceOf = -1;
  public static final int Equal = 0;
  public static final int AbstractOf = 1;
};

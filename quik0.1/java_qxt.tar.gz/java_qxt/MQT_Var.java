package java_qxt;
import java.lang.System;
import java_cup.runtime.*;

public class MQT_Var extends MQT_Term {

  public MQT_Var(int term_num)
// MQT_Var makeT_new_variable ()$B$KBP1~(B($B%@%_!<$N@5?t$rEO$9I,MW$,$"$k(B)    
    {
      super(term_num);
      this.type = TermType.TT_Var;
//      this.name = "";
      this.var = null;
      this.next = null;
      this.next_bucket = null;
    }

  public static MQT_Var makeT_var(int term_num,String string)
// MQT_Var makeT_variable (string)$B$KBP1~(B
  {
    MQT_Var new_obj,p;
    int val;

    new_obj = new MQT_Var(term_num);
//$B>/$7>J$$$?(B
     for (p = variable_pool; p!=null ; p = p.next_bucket)
       if (string.equals(p.name)){   //$BF1$8$N$,$"$C$?(B
	 return p;                   //$B%j%9%H$K$D$J$,$J$$(B
	//($B$3$3$G2?$bJV$5$:$K=*N;$9$k$N$@$,!"$[$s$H$O(Bmicro-Quixote$B$HF1$8$/(Bvari-
	//able_pool$B$N3:Ev$9$k$H$3$m(B($BJQ?tL>$,0lCW$7$?$H$3$m(B)$B$rJV$9$h$&$K$9$k!#(B)
	}

     new_obj.next_bucket = variable_pool;//$B%j%9%H$K$D$J$0(B
     new_obj.name = string;
     variable_pool = new_obj;

     return new_obj;     
   }

  public static MQT_Var makeT_new_variable() {
    MQT_Var new_var;
    new_var = new MQT_Var(sym_num.VARIABLE);
    return new_var;
  }


  public static MQT_Var   variable_pool=null;
}

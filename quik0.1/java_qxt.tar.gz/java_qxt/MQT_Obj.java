package java_qxt;
import java_cup.runtime.*;

public class MQT_Obj extends MQT_Term {

  public MQT_Obj(MQ_Atom atom, MQT_AttrList attr_list)
    // makeT_object (atom, attr_list)$B$KBP1~(B    
    {
      this(10);//dummy$B$rEO$9(B

      this.type = TermType.TT_Obj;
      this.atom = atom;
      this.attr_list = attr_list;
    }
 
  public MQT_Obj(int term_num)
    {
      super(term_num);
    }

  
}

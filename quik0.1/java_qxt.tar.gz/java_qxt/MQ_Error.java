package java_qxt;

public class MQ_Error {

public static void mq_error (String message)
{
  if (Extern_h.interactive == macro.TRUE)
    System.err.println(message);
  else
     System.err.println(FileList.scanner_obj.yyline+": "+ message);
  number_of_errors++;
}

public static void mq_exec_error (String message)
{
  if (Extern_h.interactive == macro.TRUE)
     System.err.println(message);
  else
     System.err.println(FileList.scanner_obj.yyline+": "+ message);
//  interrupt_handler ();
}

public static void mq_warning (String message)
{
  if (Extern_h.interactive == macro.TRUE)
     System.err.println(message);
  else
     System.err.println(FileList.scanner_obj.yyline+": "+ message);
}

public static void mq_fatal (String message)
{
   System.err.println("fatal error: "+ message);
  System.exit(0);
  /* DON'T RETURN */
}

public static int number_of_errors;

}

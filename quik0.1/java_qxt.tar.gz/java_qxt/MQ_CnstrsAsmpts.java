package java_qxt;

public class MQ_CnstrsAsmpts {

public MQ_CnstrsAsmpts(){}

  public  MQ_Constraints dot_cnstrs, dot_asmpts, dot_cnstrs_h;
  public  MQ_Constraints sub_cnstrs, sub_asmpts, sub_cnstrs_h;
  public  MQ_Constraints ext_cnstrs, ext_asmpts, ext_cnstrs_h;

}

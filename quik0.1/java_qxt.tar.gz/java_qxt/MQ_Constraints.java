package java_qxt;
//import 

public class MQ_Constraints {

public MQ_Constraints(){
	this.next = null;
	this.cnstr = null;
	this.prev = null;
	this.l_var_list = null;
	r_var_list = null;
	}

public static MQ_Constraints make_cnstrs_prev(MQ_Constraint cnstr,MQ_Constraints prev)
//make_cnstrs (cnstr, next)$B$KBP1~(B    
{
	MQ_Constraints new_obj = new MQ_Constraints();

	new_obj.prev = prev;
	new_obj.next = Extern_h.mQ_void_cnstrs;
//  $B$3$3$O%W%m%0%i%^$N4V0c$$$H;W$o$l$k!#:G=i$O(B next == null $B$K$J$C$F$$$?$N$G=$@5!#$C$H;W$C$?$1$I!"@)Ls$N=g=x$r5U$K$9$k$?$a$K:F$S85$KLa$7$?!#(B
	if ((prev != null) && (prev != Extern_h.mQ_void_cnstrs))
		prev.next = new_obj;
	new_obj.cnstr = cnstr;
	new_obj.l_var_list = new_obj.r_var_list = null;
	return new_obj;
}

public static MQ_Constraints make_cnstrs_after(MQ_Constraint cnstr,MQ_Constraints next)
//make_cnstrs (cnstr, next)$B$KBP1~(B    
{
	MQ_Constraints new_obj = new MQ_Constraints();

	new_obj.prev = null;
	new_obj.next = next;
//  $B$3$3$O%W%m%0%i%^$N4V0c$$$H;W$o$l$k!#:G=i$O(B next == null $B$K$J$C$F$$$?$N$G=$@5!#$C$H;W$C$?$1$I!"@)Ls$N=g=x$r5U$K$9$k$?$a$K:F$S85$KLa$7$?!#(B
	if ((next != null) && (next != Extern_h.mQ_void_cnstrs))
		next.prev = new_obj;
	new_obj.cnstr = cnstr;
	new_obj.l_var_list = new_obj.r_var_list = null;
	return new_obj;
}

	public MQ_Constraints next;
	public MQ_Constraint cnstr;
	public MQ_Constraints prev;
	public MQ_VarList l_var_list, r_var_list;
  
};

package java_qxt;

public class VariableProtect {



  public VariableProtect next;
  public MQ_VTerm var;
  public MQ_VTermAddrList vterm_addr_list;
}

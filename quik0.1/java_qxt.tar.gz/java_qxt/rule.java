package java_qxt;

public class rule {


static void init_rule ()
{

  MQ_RuleList rl;
  MQ_Rule r;
  MQ_VTerm o;

  Extern_h.mqA_True = MQ_Atom.make_atom ("&true");
  Extern_h.mqO_True = MQ_VTerm.make_object (Extern_h.mqA_True, 0);
  temp_alloc_rule = macro.FALSE;
  Extern_h.mQ_void_rule = make_rule ();
  Extern_h.mQ_void_rule_list = new MQ_RuleList(Extern_h.mQ_void_rule);
  Extern_h.mQ_void_rule.head.vterm = Extern_h.mqO_True; /* 1997/12/16 ogata */

// $B$3$l$O(BRuleList$B$N:G=i$K$D$J$0$?$a$N%*%V%8%'%/%H(B
  o = MQ_VTerm.make_MQ_Obj();
  o.atom = Extern_h.mqA_True;
  r = new MQ_Rule();
  r.head.vterm = o;
  rl = new MQ_RuleList(r);

  Extern_h.mqA_True.rule_list = rl; //$B$A$g$C$HJQ99(B..Extern_h.mQ_void_rule_list;
  Extern_h.mq_name = MQ_VTerm.make_name_var (1, null);

  Extern_h.rule_list = rl; //$B$A$g$C$HJQ99(B.. Extern_h.mQ_void_rule_list;
  Extern_h.rule_list_last = Extern_h.rule_list;
  Extern_h.mq_goal_true = new MQ_Goal();
  Extern_h.mq_goal_true.goal_vterm.vterm = (MQ_VTerm)Extern_h.mqO_True;

}

static void begin_temp_alloc_rule ()
{
  temp_alloc_rule = macro.TRUE;
  rule_list_last_last = Extern_h.rule_list_last;
}

static void end_temp_alloc_rule ()
{
  temp_alloc_rule = macro.FALSE;
  Extern_h.rule_list_last = rule_list_last_last;
  remove_temp_rule ();
}

static void free_rule ()
{
  Extern_h.mQ_void_rule_list.next = null;
  Extern_h.rule_list = Extern_h.rule_list_last = Extern_h.mQ_void_rule_list;
}

static MQ_Rule make_rule ()
{
  MQ_Rule new_obj;

  new_obj = new MQ_Rule();
  new_obj.next = null;
  new_obj.is_temp = temp_alloc_rule;
  new_obj.head = new MQ_PP();
  new_obj.body = null;
  new_obj.head_cnstrs = new_obj.body_cnstrs = Extern_h.mQ_void_cnstrs;
  new_obj.var_list = null;
  return new_obj;
}


static void remove_temp_rule ()
{
  int i;
  MQ_Atom at;
  MQ_RuleList rl, rl1;

    for (at = MQ_Atom.atom_pool; at!=null; at=at.next_bucket)
      {
        rl = at.rule_list;
        while (rl!=null)
          if (rl.is_temp == macro.TRUE)
            rl = rl.next;
          else
            {
              remove_temp_rule_sub (rl);
              break;
            }
        at.rule_list = rl;
        if (rl!=null)
          while (rl!=null)
            {
              if (rl.next!=null)
                {
                  for (rl1=rl.next; rl1!=null; rl1=rl1.next)
                    if (rl1.is_temp == macro.FALSE)
                      {
                        remove_temp_rule_sub (rl);
                        break;
                      }
                  rl.next = rl1;
                }
              rl = rl.next;
            }
      }
}

static void remove_temp_rule_sub (MQ_RuleList rule_list)
{
  MQ_Rule r, prev;

  prev = null;
  for (r=rule_list.rule; r!=null; r=r.next)
    {
      if (r.is_temp == macro.TRUE)
        break;
      prev = r;
    }
  if (prev == null)
    MQ_Error.mq_fatal ("something wrong in remove_temp_rule_sub");
  prev.next = null;
  rule_list.last_rule = prev;
}



static MQ_RuleList rule_list_last_last;
static int temp_alloc_rule;


} 

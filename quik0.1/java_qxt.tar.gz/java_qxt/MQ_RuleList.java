package java_qxt;
//import 

public class MQ_RuleList {

/*  atom$B$+$i$?$I$k$?$a$N%3%s%9%H%i%/%?(B 
public MQ_RuleList(MQ_Rule rule,int arity,MQ_RuleList next)
//make_rule_list (rule, next, arity)$B$KBP1~(B    
{
	this.next = next;
	this.next_bucket = null;
	this.is_temp = rule.temp_alloc_rule;
	this.arity = arity;
	this.rule = this.last_rule = rule;
} */

/* Extern_h$B$+$i$?$I$k$?$a$N%3%s%9%H%i%/%?(B */
public MQ_RuleList(MQ_Rule rule, MQ_RuleList next, int arity)
//make_rule_list (rule, next, arity)$B$KBP1~(B    
{
	this.next = next; //$B$A$g$C$HJQ99(B..Extern_h.mQ_void_rule_list;
	this.next_bucket = null;
	this.is_temp = rule.temp_alloc_rule;
	this.arity = arity;
	this.rule = this.last_rule = rule;
//	Extern_h.rule_list_last.next = this;
}

// mQ_void_rule_list$B$N$?$a$N%3%s%9%H%i%/%?(B
public MQ_RuleList(MQ_Rule rule)
{
	this.next = null;
	this.next_bucket = null;
	this.is_temp = rule.temp_alloc_rule;
	this.arity = 0;
	this.rule = this.last_rule = rule;
}

	public MQ_RuleList next; //$B$[$s$H$O$3$l$,(Bstatic$B$K$J$C$F$?!#(B
	public MQ_RuleList next_bucket; //$B$3$l$O(BExtern_h.rule_list$B$+$i$?$I$k$?$a$N$b$N!#(B
	public int arity;
	public int is_temp;
	public MQ_Rule rule, last_rule;
};

package java_qxt;

public class GoalType {

public static final int GT_General    =0;
public static final int GT_Through    =1;
public static final int GT_Once       =2;
public static final int GT_Done       =3;
public static final int GT_Attribute  =4;

}

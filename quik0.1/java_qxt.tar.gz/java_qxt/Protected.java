package java_qxt;

public class Protected extends MQ_VTerm {

boolean flag;

}

package java_qxt;

public class MQ_VTermList {

public MQ_VTermList(MQ_VTermList next)
//make_vterm_list (next)$B$KBP1~(B 
{
	this.vterm = new MQ_PP();
	this.next = next;
}

static MQ_VTermList generate_variables (MQ_VarList var_list)
{
  MQ_VTerm new_var;
  MQ_VTermList new_obj, next;

  if (var_list == null)
    return null;
  
  next = generate_variables (var_list.next);
  new_obj = new MQ_VTermList(next);

  new_var = MQ_VTerm.make_MQ_Var();
  new_obj.vterm.vterm = new_var;
  /* executing == 1 here */
  new_var.vterm_addr_list = new MQ_VTermAddrList(new_obj.vterm, null);
  var_list.var.vterm_addr_list = new_var.vterm_addr_list;

  return new_obj;
}

public MQ_VTermList next;
//$B#2=E%]%$%s%?$r<B8=$9$k$?$a$N%/%i%9(BMQ_PP$B$r:n$C$?!#(B
public MQ_PP   vterm;
public static MQ_VTermList vterm_list_p;

}

package java_qxt;
import java.util.*;

public class MQ_AtomList extends Vector {

static MQ_AtomList sort_atom_list_sub (MQ_AtomList al_elm,MQ_AtomList al)
{
  MQ_AtomList new_obj, a, next, prev;

  prev = null;
  for (a=al; a!=null; a=a.next)
    {
      //      if ((int)al_elm.atom < (int)a.atom);
      if (al_elm.atom.name.compareTo(a.atom.name)<0)
	break;
      prev = a;
    }

  if (prev == null)
    {
      new_obj = al_elm;
      al_elm.next = al;
    }
  else
    {
      new_obj = al;
      next = prev.next;
      prev.next = al_elm;
      al_elm.next = next;
    }

  return new_obj;
}

public static MQ_AtomList sort_atom_list (MQ_AtomList al)
{
  MQ_AtomList next;

//  System.out.println(al.atom.name); /*$B%G%P%C%0(B*/
  if (al == null)
    return null;

  next = sort_atom_list (al.next);
  return sort_atom_list_sub (al, next);
}

public static int atom_list_cmp (MQ_AtomList al1, MQ_AtomList al2)
{
  MQ_AtomList al, al_;

  for (al=al1, al_=al2; al!=null; al=al.next, al_=al_.next)
    if (al_ == null)
      return macro.FALSE;
    else if (al.atom != al_.atom)
      return macro.FALSE;

  if (al_!=null)
    return macro.FALSE;
  return macro.TRUE;
}

public static MQ_AtomList make_atom_list (MQ_Atom atom,MQ_AtomList next)
{
  MQ_AtomList new_obj;

  new_obj = new MQ_AtomList();
  new_obj.atom = atom;
  new_obj.next = next;
  return new_obj;
}

public MQ_AtomList next;
public MQ_Atom atom;

}

package java_qxt;

public class IJ_List {

public static IJ_List make_ij_list (int i, int j, IJ_List next)
{
  IJ_List new_obj;

  new_obj = new IJ_List();
  new_obj.next = next;
  new_obj.i = i;
  new_obj.j = j;
  return new_obj;
}





  public IJ_List next;
  public int i, j;
}

package java_qxt;

public class subrel {

static void init_subrel ()
{
//  mm_subrel = &subrel_obstack;
//  obstack_begin (mm_subrel, 0);
//  subrel_first_obj = (unsigned char *)obstack_alloc (mm_subrel, 0);
  MQ_SubRel.subrel_list = null;
}

static void begin_temp_alloc_subrel ()
{
  subrel_list_last = MQ_SubRel.subrel_list;
//  subrel_last_obj = (unsigned char *)obstack_alloc (mm_subrel, 0);
}

static void end_temp_alloc_subrel ()
{
//  obstack_free (mm_subrel, subrel_last_obj);
  MQ_SubRel.subrel_list = subrel_list_last;
}

static void free_subrel ()
{
//  obstack_free (mm_subrel, subrel_first_obj);
//  subrel_first_obj = (unsigned char *)obstack_alloc (mm_subrel, 0);
  MQ_SubRel.subrel_list = null;
}



//static unsigned char *subrel_first_obj;
//static unsigned char *subrel_last_obj;
static MQ_SubRel subrel_list_last;


}

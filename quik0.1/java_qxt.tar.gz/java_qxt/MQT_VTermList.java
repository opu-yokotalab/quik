package java_qxt;
import java_cup.runtime.*;

public class MQT_VTermList extends token {

  public MQT_VTermList(int term_num,MQT_VTerm vterm,MQT_VTermList next)
//makeT_vterm_list (vterm, next)$B$KBP1~(B
  {
    super(term_num);
    this.next = next;
    this.vterm = vterm;
  }
  
  public MQT_VTermList(int term_num)
    {
      this(term_num, null, null);
    }

  public MQT_VTermList next;
  public MQT_VTerm  vterm;

}

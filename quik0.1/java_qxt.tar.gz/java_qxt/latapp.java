/* LATTICE WINDOW  --1997-- */
package java_qxt;

import java.applet.Applet;
import java.awt.*;
import java.io.*;

public class latapp extends Frame {

	paintth pth;
    	public static thesa th;

	LatLabel latlabel;
	Button button;

	public latapp() {
		//setBackground(Color.pink);
		setLayout(new BorderLayout(5,5));

		latlabel = new LatLabel();
		latlabel.resize(400, 30);
		pth = new paintth(398, 398);
		button = new Button("show lattice");

		add("North", latlabel);
		add("Center", pth);
		add("South", button);
	
		th = null;
		resize(410,510);
	}

	public void start() {
		show();
	}

   	//public void paint() {
    	//}

    	public boolean action(Event ev, Object arg) {
	    	th = new thesa(16);

		try {
                      //String str = "a >= b b >= c";
                        String str = "a >= b b >= c";
			Dataread dr = new Dataread(str);
			dr.load(th);
		} catch(NullPointerException ex) {
			//MainWin.Message("NO PROGRAM DATA.");
		}
	    
	    	th.solve();
	    	pth.setth(th);
	    	pth.start();
	    	return true;
    	}
}

class LatLabel extends Canvas {    /* Label$B@_Dj(B */

	public void paint(Graphics g) {
		g.setFont(new Font("Dialog", Font.ITALIC, 21));
		g.drawString("This is Lattice Window", 100,25);
	}
}

/* PROGRAM WINDOW  -1997-  */
package java_qxt;

import java.applet.Applet;
import java.awt.*;

public class progapp extends Applet {

	Panel panel;
	TextArea ta;
	Label label1, label2;
	Button button1, button2;
	ProgLabel proglabel;
	public static String progst;

   	/* BUTTON $B$N@_Dj(B */
	public void init() {
		//setBackground(Color.pink);

		proglabel = new ProgLabel();
		proglabel.resize(500,50);
		ta = new TextArea(15,30);

		panel = new Panel();
		label1 = new Label("DATA SET : ");
		button1 = new Button("SAVE");
		label2 = new Label("DATE CLEAR : ");
		button2 = new Button("DELETE");
		panel.setLayout(new GridLayout(1, 4));
		//panel.add(label1);
		panel.add(button1);
		//panel.add(label2);
		panel.add(button2);
		
		setLayout(new BorderLayout(0,0));
		add("North", proglabel);
		add("Center", ta);
		add("South", panel);

		/* progst $B$N=i4|2=(B */
		progst = "NO DATA";
    	}

    	public boolean action(Event ev, Object o) {
		if (ev.target == button1) {
			progst = ta.getText();
			if ( 0 == progst.length() ) {
				progst = "NO DATA";
			}
//			MainWin.Message("PROGRAM DATA SAVE OK!");
		} else if (ev.target == button2) {
			String clear = "";
			ta.replaceText(clear, 0, ta.getText().length());
		}
		return true;
	}
}

class ProgLabel extends Canvas {    /* Label$B@_Dj(B */

	public void paint(Graphics g) {
		g.setFont(new Font("Dialog", Font.ITALIC, 21));
		g.drawString("This is Program Window", 60,25);
	}
}
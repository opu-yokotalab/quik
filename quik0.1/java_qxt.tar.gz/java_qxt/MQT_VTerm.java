package java_qxt;
import java_cup.runtime.*;

/** MQT_VTerm($B6&MQBN(B)$B$KBP1~(B */

public class MQT_VTerm extends token {

  public MQT_VTerm(int term_num)
    {
      super(term_num);
//      System.out.println("here is MQT_VTerm");
      
    }

  public int type;

  public MQT_Var   next_bucket;  //MQT_Var
  public MQT_Var   next;
  public MQ_VTerm  var;
  public String    name;
  public static int inter_number = 1; //$BFbItI=8=@lMQ$NJQ?t$NHV9f(B

  public MQT_VTerm vterm;        //MQT_Dot
  public MQ_Atom   label;
 
  public MQ_Atom atom;           //MQT_Obj
  public MQT_AttrList attr_list;

}

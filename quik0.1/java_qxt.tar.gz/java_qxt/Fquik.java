package java_qxt;

import java.awt.*;
import java.io.*;
//import AppletFrame;

public class Fquik extends Frame {

	public static TextArea text1, text2, text3;
	public static String rule, query;
	String clear = "";
	Label label1, label2, label3;
	TextField text4;
	public static int lat=0;
	latapp lataf;
        public static String lattice = " ";

	public Fquik() {
		super("QUIK");

		Menu exMenu = new Menu("Frame Bar");
		exMenu.add(new MenuItem("Quit"));

		Menu latMenu = new Menu("Lattice Bar");
		latMenu.add(new MenuItem("Open Lattice"));

		MenuBar mb = new MenuBar();
		mb.add(exMenu);
		mb.add(latMenu);
		setMenuBar(mb);

		Button but1 = new Button("SET PROGRAM");
		Button but2 = new Button("CLEAR PROGRAM");
		Button but3 = new Button("SET QUERY");
		Button but4 = new Button("CLEAR QUERY");
		text1 = new TextArea(13,20);		/* SIZE DATA */
		text2 = new TextArea(13,20);		/* SIZE DATA */
		text3 = new TextArea(15,43);		/* SIZE DATA */
		text3.setEditable(false);
		QuikLabel lab = new QuikLabel();
		lab.resize(500,50);			/* SIZE DATA */

		Panel square = new Panel();
		Panel pan = new Panel();

		Panel area1 = new Panel();
		area1.setLayout(new GridLayout(1, 4));
		area1.add(but1);
		area1.add(but2);
		area1.add(but3);
		area1.add(but4);

		Panel area2 = new Panel();
		Panel block1 = new Panel();
		Panel block2 = new Panel();

		block1.setLayout(new GridLayout(1, 2));
		label1 = new Label("PROGRAM WINDOW");
		label2 = new Label("QUERY WINDOW");
		block1.add(label1);
		block1.add(label2);

		block2.setLayout(new GridLayout(1, 2));
		block2.add(text1);
		block2.add(text2);

		area2.setLayout(new BorderLayout(0,0));
		area2.add("North",block1);
		area2.add("Center",block2);

		Panel area4 = new Panel();
		Label load = new Label("File Name");
		text4 = new TextField(30);
		area4.add(load);
		area4.add(text4);

		pan.setLayout(new BorderLayout(0,0));
		pan.add("North",area4);
		pan.add("Center",area2);
		pan.add("South",area1);

		square.setLayout(new BorderLayout(0,0));
		square.add("North",lab);
		square.add("Center",pan);

		Panel area3 = new Panel();
		label3 = new Label("ANSWER WINDOW");
		area3.setLayout(new BorderLayout(0,0));
		area3.add("North",label3);
		area3.add("Center",text3);
		
		setLayout(new BorderLayout(0,0));
		add("North",square);
		add("Center",area3);
	}

	public void start() {
		resize(600,500);
		show();
	}

	public boolean handleEvent(Event e){
		if(e.id==Event.WINDOW_DESTROY){
			dispose();
			System.exit(0);
			return true;
		}
		else {
			return super.handleEvent(e);
		}
	}

	public boolean action(Event ev, Object o) {
		if(ev.target instanceof MenuItem) {
			MenuItem mi = (MenuItem)ev.target;
			if("Quit".equals(mi.getLabel())){
				//System.out.println("Exit...");
				dispose();
				System.exit(0);
				return true;
			}else if("Open Lattice".equals(mi.getLabel())){
				if(lat == 0) {
                                        disp_lattice();
//					lataf = new latapp();
//					lataf.start();
					lat = 1;
				} else {
					if(lataf.isShowing()) lataf.hide();
					else lataf.show();
				}
				return true;
			}
		}else if (ev.target  == text4) {
         		Filereader(text4.getText().toString().trim());
         		return true;
       		}
		if(ev.target instanceof Button) {
			String menu = o.toString();
			if(0 == menu.compareTo("SET PROGRAM")) {
				rule = text1.getText();
                                inputProc(rule);
				return true;
			}
			else if(0 == menu.compareTo("SET QUERY")) {
				query = text2.getText();
                                inputProc(query);
				return true;
			}
			else if(0 == menu.compareTo("CLEAR PROGRAM")) {
				text1.replaceText(clear, 0, text1.getText().length());
				return true;
			}
			else if(0 == menu.compareTo("CLEAR QUERY")) {
				text2.replaceText(clear, 0, text2.getText().length());
				return true;
			}
		}
		return false;
	}
    
      void disp_lattice(){

           Commands.show_subsumption_lattice();
           lataf = new latapp();
	   lataf.start();

       }

       public static void messageLattice(String mess) {
	  lattice = lattice + mess;
       }

       void Filereader(String file){
         FileReader fis;   

         try{
             fis = new FileReader(file);
             char ch[] = new char[100000];
             try{
	       while((fis.read(ch))>=0){  
                 appendText1(String.valueOf(ch));
	       }
             }catch(FileNotFoundException e){
             }catch(IOException e){
             }
         }catch(FileNotFoundException e){
         }catch(IOException e){
         }
       }

    public void inputProc(String str) {

      int b;

      try{

          StringBufferInputStream is = new StringBufferInputStream(str);
          FileOutputStream os = new FileOutputStream("_program.quik");
      
          while ((b = is.read()) != -1) {
             os.write((char)b);
          }
          os.close();
      }catch (IOException e) {
          System.out.println("File error: " + e);
      }
       
      try{

           parser parse_obj = new parser();
           FileList.init_scanner_2("_program.quik");
           parse_obj.parse();
          
      } catch (java.lang.Exception ex) {
         System.err.println("Exception: " + ex.getMessage());
         ex.printStackTrace();
         System.exit(-1);
      }

    }

    public void appendText1(String str) {
         text1.appendText( str + "\r\n");
    }

    public static void messagePrint(String mess) {
	text3.appendText( mess );
    }

    public static void progprint(String prog) {
	text1.appendText(prog);
    }
}

class QuikLabel extends Canvas {    /* Label$B@_Dj(B */

	public void paint(Graphics g) {
		g.drawString("QUIK version Ver.0.1.  CopyRight (C) 1997 Yokota Lab.", 150,40);
		//g.setColor(Color.blue);
		g.setFont(new Font("Dialog", Font.ITALIC, 21));
		g.drawString("QUIK", 200,20);
	}


}

package java_qxt;
public class MQ_AtomAtomSet {

public MQ_AtomAtomSet (MQ_Atom atom,MQ_AtomList atom_list,
		       MQ_AtomAtomSet next)
//make_atom_atomset$B$KBP1~(B
{
  this.atom = atom;
  this.atom_list = atom_list;
  this.next = next;
}

public MQ_AtomAtomSet next;
public MQ_Atom atom;
public MQ_AtomList atom_list;

}

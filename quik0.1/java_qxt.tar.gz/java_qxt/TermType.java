package java_qxt;

public class TermType {

  public TermType(int integer)
    {
      type = integer;
    }

  public int type;

  public static final int TT_Var =0;
  public static final int TT_Dot =1;
  public static final int TT_Obj =2;
  public static final int TT_NameVar=3; 
}

package java_qxt;
import java.util.*;

public class MQ_Attr  {
// $B$[$s$H$O%3%s%9%H%i%/%?$O$J$+$C$?$N$@$,!"$D$$$G$J$N$GA^F~$7$?!#(B

  public MQ_Attr(){
	this.label = null;
	this.vterm = new MQ_PP();
  }

public MQ_Atom label;
//$B#2=E%]%$%s%?$r<B8=$9$k$?$a$N%/%i%9(BMQ_PP$B$r:n$C$?!#(B
public MQ_PP vterm;

}
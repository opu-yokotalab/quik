package java_qxt;

public class macro {

  static final int FAILURE  =   0;
  static final int SUCCESS  =   1;
  static final int DONE     =   2;
	
  static final int FALSE    =   0;
  static final int TRUE     =   1;

  static final int EXEC_SIZE        = 32752;
  static final int CONSTRAINTS_SIZE =  8176;

  static final int INHERIT_NO       =   0;
  static final int INHERIT_DOWNWARD =   1;
  static final int INHERIT_UPWARD   =   2;
  static final int INHERIT_BOTH     =   3;

  static final int EXCEPT_ABORT = 1;

  public static final int  MODE_PROGRAM            = 0;
  public static final int MODE_PROGRAM_RULE        = 1;
  public static final int MODE_PROGRAM_SUBSUMPTION = 2;
  public static final int MODE_QUERY               = 3;
  public static final int MODE_COMMAND             = 4;
  public static final int PS_EXPECT_PRD            =10;
  public static final int PS_EXPECT_Q_PRD          =11;
  public static final int PS_EXPECT_TERM           =12;

  public static final int  DOWN = 0;
  public static final int  UP   = 1;

  public static MQ_Atom external_cnstr_op;
  public static MQT_Obj mqTO_True;

//internal.h:#define PROTECTED ((union MQ_VTerm_Rec *)-1)
  public static final MQ_VTerm PROTECTED = new Protected();

}

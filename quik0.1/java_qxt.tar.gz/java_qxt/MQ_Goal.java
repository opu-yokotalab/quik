package java_qxt;

public class MQ_Goal {
  
  public MQ_Goal()//make_goal()$B$KBP1~(B;
  {
    this.type = GoalType.GT_General;
    this.prev = this.next = this.subgoal = this.parent = null;
    this.keep_clean = null;
    this.up = null;
    this.cnstrs_asmpts = null;
    this.lookup = null;
    this.goal_vterm = new MQ_PP();
    this.rule = null;
    this.rule_list = null;
    this.head = new MQ_PP();
    this.head_cnstrs = this.body_cnstrs = Extern_h.mQ_void_cnstrs;
    this.var_list = null;
  }
  


  int type;
  MQ_Goal prev, next, subgoal, parent;
  String keep_clean;
  UnwindProtect up;
  MQ_CnstrsAsmpts cnstrs_asmpts;
  MQ_Lookup lookup;
  //$B#2=E%]%$%s%?$r<B8=$9$k$?$a$N%/%i%9(BMQ_PP$B$r:n$C$?(B
  MQ_PP goal_vterm;
  MQ_Rule rule;
  MQ_RuleList rule_list;
  //$B#2=E%]%$%s%?$r<B8=$9$k$?$a$N%/%i%9(BMQ_PP$B$r:n$C$?(B
  MQ_PP head;
  MQ_Constraints head_cnstrs, body_cnstrs;
  MQ_VTermList var_list;

}

package java_qxt;
public class MQ_AtomSet {


public static MQ_AtomSet intern_atom_set (MQ_AtomList al)
{
  MQ_AtomList al1;
  MQ_AtomSet p, new_obj;
  int val;

//  System.out.println("***" + al.atom.name); /*$B%G%P%C%0(B*/
  al1 = MQ_AtomList.sort_atom_list (al);
  for (p=atom_set_pool; p!=null; p=p.next_bucket)
    if (MQ_AtomList.atom_list_cmp (al1, p.atom_list) == macro.TRUE)
      return p;

  new_obj = new MQ_AtomSet();
  new_obj.next_bucket = atom_set_pool;
  atom_set_pool = new_obj;
  new_obj.atom_list = al1;

  return new_obj;
}



public MQ_AtomSet next_bucket;
public MQ_AtomList atom_list;
public static MQ_AtomSet atom_set_pool;

}

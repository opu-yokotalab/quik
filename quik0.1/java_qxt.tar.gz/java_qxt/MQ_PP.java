package java_qxt;

// $B#C8@8l$N#2=E%]%$%s%?$r#J#a#v#a$G<B8=$9$k$?$a$N%/%i%9!#(B

public class MQ_PP {
	public MQ_PP(){}
	public MQ_VTerm vterm;
//	public MQ_Term term;
//	public MQ_VTerm goal_vterm;
//	public MQ_VTerm head;
}

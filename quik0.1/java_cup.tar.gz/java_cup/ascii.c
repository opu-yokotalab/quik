#include <stdio.h>

void main(void)
{
  printf("%d \n",'[');
}
